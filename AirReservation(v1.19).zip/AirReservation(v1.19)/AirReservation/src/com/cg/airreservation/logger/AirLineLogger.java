package com.cg.airreservation.logger;

import java.io.IOException;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;


public class AirLineLogger {
static Logger logger= Logger.getLogger(AirLineLogger.class);
	
	static
	{
		Layout layout = new SimpleLayout();
		//Layout layout = new HTMLLayout();
		//Layout layout = new XMLLayout();
		Appender appender= null;
		
		try {
			
			appender = new FileAppender(layout,"log.txt");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.addAppender(appender);
	}
	
	public static Logger getLoggerInstance()
	{
		return logger;
	}

}
