package com.loanapplication.service;

import com.loanapplication.entities.CustomerDetail;
import com.loanapplication.entities.Loanapplication;
import com.loanapplication.entities.Loanprogramsoffered;
import com.loanapplication.exception.LoanException;

public interface CustomerService {
	public Loanprogramsoffered getLoanProgramDescription(long prgmId)throws LoanException;
	public long insertLoanApp(Loanapplication loanApp)throws LoanException;
	public boolean insertCustDetails(CustomerDetail cust)throws LoanException;
	public Loanapplication getStatus(long id)throws LoanException;
}
