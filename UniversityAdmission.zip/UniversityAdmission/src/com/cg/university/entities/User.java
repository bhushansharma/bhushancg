package com.cg.university.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;


/**
 * The persistent class for the USERS database table.
 * 
 */
@Component
@Entity
@Table(name="USERS")
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LOGIN_ID", updatable=false, unique=true, nullable=false, length=5)
	private String loginId;

	@Column(length=10)
	private String password;

	public User() {
	}

	public String getLoginId() {
		return this.loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}