package com.loanprocessing.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.loanprocessing.bean.CustomerDetails;
import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.dao.LoanDAO;
import com.loanprocessing.dao.LoanDAOImpl;
import com.loanprocessing.exception.LoanProgramException;
import com.loanprocessing.service.LoanServiceImpl;

public class LoanDAOTest {
	
	LoanServiceImpl service;
	LoanDAO dao;

	@Before
	public void init()
	{
		service = new LoanServiceImpl();
		dao = new LoanDAOImpl();
		service.setDao(dao);
	}

	@Test
	public void testGetLoanProgram() throws LoanProgramException {
		assertNotNull(service.getLoanProgram());
		
	}
	
	@Test
	public void testWrongGetLoanProgram() throws LoanProgramException{
		assertNull(service.getLoanProgram());
	}

	@Test
	public void testGetLoanDescription() throws LoanProgramException{
		LoanPrograms bean = new LoanPrograms();
		
		bean.setProgramId(104);
		assertNotNull(service.getLoanDescription(bean.getProgramId()));
	}
	
	@Test
	public void testWrongGetLoanDescription() throws LoanProgramException{
		LoanPrograms bean = new LoanPrograms();
		
		bean.setProgramId(112);
		assertNotNull(service.getLoanDescription(bean.getProgramId()));
	}

	@Test
	public void testInsertLoanApplictaion() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		
		bean.setLoanProgm("Home");
		bean.setAmount(500000.00);
		bean.setAddress("Pune");
		bean.setIncome(1000000.00);
		bean.setProof("Aadhar Card");
		bean.setCover("Home");
		bean.setMarketValue(200000);
		bean.setStatus("Applied");
		bean.setInterviewDate(LocalDate.now());
		
		assertEquals(true,service.insertLoanApplictaion(bean));
		
	}

	@Test
	public void testInsertCustomerDetails() throws LoanProgramException {
		CustomerDetails bean =new CustomerDetails();
		
		bean.setAppName("Formy");
		bean.setCount(3);
		bean.setDob(LocalDate.parse("1988-08-12"));
		bean.setEmail("formy@gmail.com");
		bean.setLoanAppId(10001);
		bean.setMaritalStatus("Single");
		bean.setMobileNo("9632587410");
		bean.setPhoneNo("02517894561");
		
		assertEquals(true,service.insertCustomerDetails(bean));
	}

	
	
	@Test
	public void testCheckStatus() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		bean.setLoanAppId(10005);
		
	
		assertEquals("Applied", bean.getStatus());
	}
	
	@Test
	public void testWrongCheckStatus() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		bean.setLoanAppId(10001);
		bean.setStatus("Applied");
	
		assertEquals("Approved", bean.getStatus());
	}

}
