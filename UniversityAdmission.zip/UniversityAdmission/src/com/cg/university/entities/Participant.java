package com.cg.university.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;


/**
 * The persistent class for the PARTICIPANT database table.
 * 
 */
@Component
@Entity
@Table(name="PARTICIPANT")
@NamedQuery(name="Participant.findAll", query="SELECT p FROM Participant p")
public class Participant implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTICIPANT_ROLLNO_GENERATOR", sequenceName="APP_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTICIPANT_ROLLNO_GENERATOR")
	@Column(name="ROLL_NO", unique=true, nullable=false, length=5)
	private int rollNo;

	@Column(name="APPLICATION_ID")
	private int applicationId;

	@Column(name="EMAIL_ID", length=20)
	private String emailId;

	//bi-directional many-to-one association to ProgramsScheduled
	@ManyToOne
	@JoinColumn(name="SCHEDULED_PROGRAM_ID")
	private ProgramsScheduled programsScheduled;

	public Participant() {
	}

	

	public int getRollNo() {
		return rollNo;
	}



	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}



	public int getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public ProgramsScheduled getProgramsScheduled() {
		return this.programsScheduled;
	}

	public void setProgramsScheduled(ProgramsScheduled programsScheduled) {
		this.programsScheduled = programsScheduled;
	}

}