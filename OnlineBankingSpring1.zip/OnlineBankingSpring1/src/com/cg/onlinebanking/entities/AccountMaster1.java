package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ACCOUNT_MASTER1 database table.
 * 
 */
@Component
@Entity
@Table(name="ACCOUNT_MASTER1")
@NamedQuery(name="AccountMaster1.findAll", query="SELECT a FROM AccountMaster1 a")
public class AccountMaster1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ACCOUNT_MASTER1_ACCOUNTID_GENERATOR", sequenceName="ACCOUNT_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ACCOUNT_MASTER1_ACCOUNTID_GENERATOR")
	@Column(name="ACCOUNT_ID")
	private long accountId;

	@NotNull(message="Account Balance Should Be greater than 500")
	@Range(min=500, message="Account Balance should be greater than 500")
	@Column(name="ACCOUNT_BALANCE")
	private double accountBalance;

	@Column(name="ACCOUNT_TYPE")
	private String accountType;

	@Column(name="OPEN_DT")
	private Timestamp openDt;

	//bi-directional many-to-one association to FundTransfer1
	@OneToMany(mappedBy="accountMaster11")
	private List<FundTransfer1> fundTransfer1s1;

	//bi-directional many-to-one association to FundTransfer1
	@OneToMany(mappedBy="accountMaster12")
	private List<FundTransfer1> fundTransfer1s2;

	//bi-directional many-to-one association to Payee1
	@OneToMany(mappedBy="accountMaster11")
	private List<Payee1> payee1s1;

	//bi-directional many-to-one association to Payee1
	@OneToMany(mappedBy="accountMaster12")
	private List<Payee1> payee1s2;

	//bi-directional many-to-one association to ServiceTracker1
	@OneToMany(mappedBy="accountMaster1")
	private List<ServiceTracker1> serviceTracker1s;

	//bi-directional many-to-one association to Transactions1
	@OneToMany(mappedBy="accountMaster1")
	private List<Transactions1> transactions1s;

	//bi-directional many-to-one association to Users1
	@OneToMany(mappedBy="accountMaster1")
	private List<Users1> users1s;

	//bi-directional one-to-one association to Customer1
	@OneToOne
	@JoinColumn(name="ACCOUNT_ID")
	private Customer1 customer1;

	public AccountMaster1() {
	}

	public long getAccountId() {
		return this.accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public double getAccountBalance() {
		return this.accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getAccountType() {
		return this.accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Timestamp getOpenDt() {
		return this.openDt;
	}

	public void setOpenDt(Timestamp openDt) {
		this.openDt = openDt;
	}

	public List<FundTransfer1> getFundTransfer1s1() {
		return this.fundTransfer1s1;
	}

	public void setFundTransfer1s1(List<FundTransfer1> fundTransfer1s1) {
		this.fundTransfer1s1 = fundTransfer1s1;
	}

	public FundTransfer1 addFundTransfer1s1(FundTransfer1 fundTransfer1s1) {
		getFundTransfer1s1().add(fundTransfer1s1);
		fundTransfer1s1.setAccountMaster11(this);

		return fundTransfer1s1;
	}

	public FundTransfer1 removeFundTransfer1s1(FundTransfer1 fundTransfer1s1) {
		getFundTransfer1s1().remove(fundTransfer1s1);
		fundTransfer1s1.setAccountMaster11(null);

		return fundTransfer1s1;
	}

	public List<FundTransfer1> getFundTransfer1s2() {
		return this.fundTransfer1s2;
	}

	public void setFundTransfer1s2(List<FundTransfer1> fundTransfer1s2) {
		this.fundTransfer1s2 = fundTransfer1s2;
	}

	public FundTransfer1 addFundTransfer1s2(FundTransfer1 fundTransfer1s2) {
		getFundTransfer1s2().add(fundTransfer1s2);
		fundTransfer1s2.setAccountMaster12(this);

		return fundTransfer1s2;
	}

	public FundTransfer1 removeFundTransfer1s2(FundTransfer1 fundTransfer1s2) {
		getFundTransfer1s2().remove(fundTransfer1s2);
		fundTransfer1s2.setAccountMaster12(null);

		return fundTransfer1s2;
	}

	public List<Payee1> getPayee1s1() {
		return this.payee1s1;
	}

	public void setPayee1s1(List<Payee1> payee1s1) {
		this.payee1s1 = payee1s1;
	}

	public Payee1 addPayee1s1(Payee1 payee1s1) {
		getPayee1s1().add(payee1s1);
		payee1s1.setAccountMaster11(this);

		return payee1s1;
	}

	public Payee1 removePayee1s1(Payee1 payee1s1) {
		getPayee1s1().remove(payee1s1);
		payee1s1.setAccountMaster11(null);

		return payee1s1;
	}

	public List<Payee1> getPayee1s2() {
		return this.payee1s2;
	}

	public void setPayee1s2(List<Payee1> payee1s2) {
		this.payee1s2 = payee1s2;
	}

	public Payee1 addPayee1s2(Payee1 payee1s2) {
		getPayee1s2().add(payee1s2);
		payee1s2.setAccountMaster12(this);

		return payee1s2;
	}

	public Payee1 removePayee1s2(Payee1 payee1s2) {
		getPayee1s2().remove(payee1s2);
		payee1s2.setAccountMaster12(null);

		return payee1s2;
	}

	public List<ServiceTracker1> getServiceTracker1s() {
		return this.serviceTracker1s;
	}

	public void setServiceTracker1s(List<ServiceTracker1> serviceTracker1s) {
		this.serviceTracker1s = serviceTracker1s;
	}

	public ServiceTracker1 addServiceTracker1(ServiceTracker1 serviceTracker1) {
		getServiceTracker1s().add(serviceTracker1);
		serviceTracker1.setAccountMaster1(this);

		return serviceTracker1;
	}

	public ServiceTracker1 removeServiceTracker1(ServiceTracker1 serviceTracker1) {
		getServiceTracker1s().remove(serviceTracker1);
		serviceTracker1.setAccountMaster1(null);

		return serviceTracker1;
	}

	public List<Transactions1> getTransactions1s() {
		return this.transactions1s;
	}

	public void setTransactions1s(List<Transactions1> transactions1s) {
		this.transactions1s = transactions1s;
	}

	public Transactions1 addTransactions1(Transactions1 transactions1) {
		getTransactions1s().add(transactions1);
		transactions1.setAccountMaster1(this);

		return transactions1;
	}

	public Transactions1 removeTransactions1(Transactions1 transactions1) {
		getTransactions1s().remove(transactions1);
		transactions1.setAccountMaster1(null);

		return transactions1;
	}

	public List<Users1> getUsers1s() {
		return this.users1s;
	}

	public void setUsers1s(List<Users1> users1s) {
		this.users1s = users1s;
	}

	public Users1 addUsers1(Users1 users1) {
		getUsers1s().add(users1);
		users1.setAccountMaster1(this);

		return users1;
	}

	public Users1 removeUsers1(Users1 users1) {
		getUsers1s().remove(users1);
		users1.setAccountMaster1(null);

		return users1;
	}

	public Customer1 getCustomer1() {
		return this.customer1;
	}

	public void setCustomer1(Customer1 customer1) {
		this.customer1 = customer1;
	}

}