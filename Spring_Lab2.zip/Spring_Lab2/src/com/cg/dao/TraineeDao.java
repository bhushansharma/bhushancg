package com.cg.dao;

import com.cg.bean.Trainee;
import com.cg.exception.TraineeException;

public interface TraineeDao {
	public boolean insertTrainee(Trainee traineeBean)throws TraineeException;
	public Trainee fetchTraincee(int traineeId)throws TraineeException;
	public boolean deleteTrainee(int traineeId)throws TraineeException;
	public boolean modifyTrainee(Trainee bean)throws TraineeException;
}
