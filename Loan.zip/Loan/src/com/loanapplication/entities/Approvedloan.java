package com.loanapplication.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;


/**
 * The persistent class for the APPROVEDLOANS database table.
 * 
 */
@Component
@Entity
@Table(name="APPROVEDLOANS")
@NamedQuery(name="Approvedloan.findAll", query="SELECT a FROM Approvedloan a")
public class Approvedloan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="APPROVEDLOANS_APPROVELOANID_GENERATOR", sequenceName="APPROVE_LOAN_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="APPROVEDLOANS_APPROVELOANID_GENERATOR")
	@Column(name="APPROVE_LOAN_ID")
	private long approveLoanId;

	@Column(name="AMOUNT_OF_LOAN")
	private long amountOfLoan;

	@Column(name="MONTHLY_INSTALLMENT")
	private long monthlyInstallment;

	private long premium;

	private double roi;

	@Column(name="TIME_PERIOD")
	private int timePeriod;

	//bi-directional many-to-one association to CustomerDetail
	@ManyToOne
	@JoinColumn(name="CUSTOMER_ID")
	private CustomerDetail customerDetail;

	public Approvedloan() {
	}

	public long getApproveLoanId() {
		return this.approveLoanId;
	}

	public void setApproveLoanId(long approveLoanId) {
		this.approveLoanId = approveLoanId;
	}

	public long getAmountOfLoan() {
		return this.amountOfLoan;
	}

	public void setAmountOfLoan(long amountOfLoan) {
		this.amountOfLoan = amountOfLoan;
	}

	public long getMonthlyInstallment() {
		return this.monthlyInstallment;
	}

	public void setMonthlyInstallment(long monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}

	public long getPremium() {
		return this.premium;
	}

	public void setPremium(long premium) {
		this.premium = premium;
	}

	public double getRoi() {
		return this.roi;
	}

	public void setRoi(double roi) {
		this.roi = roi;
	}

	public int getTimePeriod() {
		return this.timePeriod;
	}

	public void setTimePeriod(int timePeriod) {
		this.timePeriod = timePeriod;
	}

	public CustomerDetail getCustomerDetail() {
		return this.customerDetail;
	}

	public void setCustomerDetail(CustomerDetail customerDetail) {
		this.customerDetail = customerDetail;
	}

}