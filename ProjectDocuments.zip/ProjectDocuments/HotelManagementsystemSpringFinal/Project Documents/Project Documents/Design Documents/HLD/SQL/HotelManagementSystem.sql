CREATE TABLE users(user_id number, password varchar2(10), role varchar2(10), username varchar2(20), user_mobile_no number(10), phn_no number(11), address varchar2(25), email varchar2(20),primary key (user_id));

 CREATE TABLE hotel(hotel_id number, hotel_city varchar2(10), hotel_name varchar2(20), hotel_address varchar2(25), hotel_desc varchar2(50), avg_rate number(8,2), hotel_phn_no1 number(11),hotel_phn_no2 number(11),rating number(4),email varchar2(15),fax number(15),primary key (hotel_id));

 CREATE TABLE room_details(hotel_id number, room_id number, room_no number(3), room_type varchar2(20), per_night_rt number(6,2), availability varchar2(1), photo BLOB , PRIMARY KEY(room_id), constraint fk_hotelid Foreign Key(hotel_id) References hotel(hotel_id));
 
CREATE TABLE booking_details(booking_id number, room_id number,  user_id number, booked_from date, booked_to date, no_of_adlts number, no_of_children number, total_amount number(8,2),Primary key(booking_id), constraint fk_roomid Foreign key(room_id) references room_details(room_id), constraint fk_userid Foreign key(user_id) references users(user_id));

CREATE TABLE admin(admin_id number, hotel_id number, room_id number, splc_offer varchar2(10), booking_id number, primary key(admin_id), constraint ad_fk_hotelid Foreign Key(hotel_id) References hotel(hotel_id), constraint ad_fk_roomid Foreign key(room_id) references room_details(room_id), constraint ad_fk_bookingid FOREIGN key (booking_id) REFERENCES booking_details(booking_id));


 alter table hotel add discount_percent number(5);
 
  alter table hotel modify email varchar2(30);
  
  alter table  hotel modify hotel_address varchar(50);