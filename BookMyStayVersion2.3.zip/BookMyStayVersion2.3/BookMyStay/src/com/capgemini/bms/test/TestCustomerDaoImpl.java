package com.capgemini.bms.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.User;
import com.capgemini.bms.dao.CustomerDao;
import com.capgemini.bms.dao.CustomerDaoImpl;
import com.capgemini.bms.exception.HotelException;
import com.capgemini.bms.service.CustomerServiceImpl;

public class TestCustomerDaoImpl {


	CustomerServiceImpl service;
	CustomerDao dao;

	@Before
	public void init() {
		service = new CustomerServiceImpl();
		dao = new CustomerDaoImpl();
		service.setDao(dao);
		
	}
	
	@Test
	public void testregisterUser() {
		int phnno= 1234567891;
		BigDecimal phnnoBD = new BigDecimal(phnno);
		int mob = 789854652;
		BigDecimal mobBD = new BigDecimal(mob);
		
		User bean = new User();
		bean.setUserId(113);
		bean.setUsername("bharat");
		bean.setPassword("dubey");
		bean.setAddress("abc");
		bean.setRole("Customer");	
		bean.setEmail("bshs@gmail.com");
		bean.setPhnNo(phnnoBD);
		bean.setUserMobileNo(mobBD);
		
		try
		{
			assertEquals(true, service.registerUser(bean));
		}
		catch(HotelException e)
		{
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testValidate() {
		User bean = new User();
		bean.setUsername("bharat");
		bean.setPassword("dubey");
		
		try
		{
			assertNotEquals(true, service.validate(bean.getUsername(), bean.getPassword()));
		}
		catch(HotelException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testValidate1() {
		User bean = new User();
		bean.setUsername("bharat123");
		bean.setPassword("dubey");
		
		try
		{
			assertEquals(true, service.validate(bean.getUsername(), bean.getPassword()));
		}
		catch(HotelException e)
		{
			System.out.println(e.getMessage());
		}
	}


	@Test
	public void testGetHotelList() {	
		try {
			assertEquals(0, service.getHotelList("pune").size());
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testGetHotelList1() {
		try {
			assertNotNull(service.getHotelList("pune").size());
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testSearchRooms() {

		try {
			assertNotNull(service.searchRooms("delux", 1000, 5000, 1001));
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testSearchRooms1() {

		try {
			assertNull(service.searchRooms("semi-delux", 1000, 5000, 1001));
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testBookRoom() throws ParseException {
		
		BookingDetail bean = new BookingDetail();
		
		int noOfAdults = 2;
		int noOfChildrens = 3;
		BigDecimal noOfAdultsBD = new BigDecimal(noOfAdults);
		BigDecimal noOfChildrensBD = new BigDecimal(noOfChildrens);
		
		bean.setBookingId(1003);
		//DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
		Date fDate = sd.parse("12/12/2017");
		bean.setBookedFrom((java.sql.Date) fDate);
		Date lDate = sd.parse("17/12/2017");
		bean.setBookedTo((java.sql.Date) lDate);
		bean.setNoOfAdlts(noOfAdultsBD);
		bean.setNoOfChildren(noOfChildrensBD);
		bean.setTotalAmount(2300);
		
		try {
			assertNotNull(service.bookRoom(bean));
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	@Test
	public void testBookRoom1() throws ParseException {
		
		BookingDetail bean = new BookingDetail();
		
		
		int noOfAdults = 2;
		int noOfChildrens = 3;
		BigDecimal noOfAdultsBD = new BigDecimal(noOfAdults);
		BigDecimal noOfChildrensBD = new BigDecimal(noOfChildrens);
		
		bean.setBookingId(1005);
		//DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
		Date fDate = sd.parse("20/12/2017");
		bean.setBookedFrom((java.sql.Date) fDate);
		Date lDate = sd.parse("17/12/2017");
		bean.setBookedTo((java.sql.Date) lDate);
		bean.setNoOfAdlts(noOfAdultsBD);
		bean.setNoOfChildren(noOfChildrensBD);
		bean.setTotalAmount(2300);
		
		try {
			assertNull(service.bookRoom(bean));
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Test
	public void testGetUser() {

		User bean = new User();
		bean.setUsername("bharat");
		bean.setPassword("dubey");
		
		try {
			assertEquals(true, service.getUser(bean.getUsername(), bean.getPassword()));
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testGetUser1() {

		User bean = new User();
		
		int phnno= 1234567891;
		BigDecimal phnnoBD = new BigDecimal(phnno);
		int mob = 789854652;
		BigDecimal mobBD = new BigDecimal(mob);
		
		bean.setUsername("bharat");
		bean.setPassword("dubey");
		bean.setRole("Customer");
		bean.setUserMobileNo(mobBD);
		bean.setPhnNo(phnnoBD);
		bean.setAddress("Bhopal");
		bean.setEmail("abc@gmail.com");
		
		try {
			assertNotEquals(true, service.getUser(bean.getUsername(), bean.getPassword()));
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetBookings() {

	try {
		assertNotEquals(0, service.getBookings(153));
	} catch (HotelException e) {
		System.out.println(e.getMessage());
	}
	}
	
	@Test
	public void testGetBookings1() {

	try {
		assertNull(service.getBookings(999));
	} catch (HotelException e) {
		System.out.println(e.getMessage());
	}
	}

//	@Test
//	public void testCancelBooking() {
//
//	BookingDetail bean = new BookingDetail();
//	
//	try {
//		assertNotNull(service.cancelBooking(bean.getBookingId()));
//	} catch (HotelException e) {
//		System.out.println(e.getMessage());
//	}
//	}
//	
//	@Test
//	public void testCancelBooking1() {
//
//	BookingDetail bean = new BookingDetail();
//	
//	try {
//		assertNull(service.cancelBooking(bean.getBookingId()));
//	} catch (HotelException e) {
//		System.out.println(e.getMessage());
//	}
//	}


	@Test
	public void testGetAllBookings() {
	try {
		assertNotNull(service.getAllBookings(1003));
	} catch (HotelException e) {
		System.out.println(e.getMessage());
	}
	}

	
	@Test
	public void testGetAllBookings1() {
	try {
		assertNull(service.getAllBookings(1004));
	} catch (HotelException e) {
		System.out.println(e.getMessage());
	}
	}
	
	@Test
	public void testGetHotelByID() {
	try {
		assertNotNull(service.getHotelById(1003, "pune"));
	} catch (HotelException e) {
		System.out.println(e.getMessage());
	}
	}
	
	@Test
	public void testGetHotelByID1() {
	try {
		assertNotNull(service.getHotelById(1006, "pune"));
	} catch (HotelException e) {
		System.out.println(e.getMessage());
	}
	}
	
	@After
	public void destroy() {
		
		service = null;
		dao = null;
	}

}
