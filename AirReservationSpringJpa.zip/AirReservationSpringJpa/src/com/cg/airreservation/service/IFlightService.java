package com.cg.airreservation.service;

import java.util.ArrayList;

import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;

public interface IFlightService {

	public ArrayList<Flightinfo> searchFlight(Flightinfo flight)
			throws AirlineException;

	public boolean addNewFlight(Flightinfo flightinfo) throws AirlineException;

	public ArrayList<Flightinfo> getListOfFlight(Bookinginfo bookingInfo,
			String classType) throws AirlineException;
	
	public Flightinfo fetchFlightDetails(long id) throws AirlineException;
	
	public ArrayList<String> fetchSourceCity() throws AirlineException;

	public ArrayList<String> fetchDestinationCity() throws AirlineException;

public int updateFlightSeats(Bookinginfo bookingDetail) throws AirlineException;

public int modifyFlightAfterCancel(Bookinginfo bookingDetail) throws AirlineException;

public int modifyFlightAfterUpdate(Bookinginfo newBookingDetail,
		Bookinginfo oldBookingDetail) throws AirlineException;

public ArrayList<String> fetchAirlineList() throws AirlineException;

}
