package com.loanapplication.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.List;


/**
 * The persistent class for the LOANPROGRAMSOFFERED database table.
 * 
 */
@Component
@Entity
@NamedQuery(name="Loanprogramsoffered.findAll", query="SELECT l FROM Loanprogramsoffered l")
public class Loanprogramsoffered implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long prgmid;

	private String descriptn;

	@Column(name="DURATION_IN_YRS")
	private long durationInYrs;

	@Column(name="MAX_LOAN_AMT")
	private long maxLoanAmt;

	@Column(name="MIN_LOAN_AMT")
	private long minLoanAmt;

	private String prgmname;

	@Column(name="PROOFS_REQ")
	private String proofsReq;

	private double roi;

	@Column(name="\"TYPE\"")
	private String type;

	//bi-directional many-to-one association to Loanapplication
	@OneToMany(mappedBy="loanprogramsoffered")
	private List<Loanapplication> loanapplications;

	public Loanprogramsoffered() {
	}

	public long getPrgmid() {
		return this.prgmid;
	}

	public void setPrgmid(long prgmid) {
		this.prgmid = prgmid;
	}

	public String getDescriptn() {
		return this.descriptn;
	}

	public void setDescriptn(String descriptn) {
		this.descriptn = descriptn;
	}

	public long getDurationInYrs() {
		return this.durationInYrs;
	}

	public void setDurationInYrs(long durationInYrs) {
		this.durationInYrs = durationInYrs;
	}

	public long getMaxLoanAmt() {
		return this.maxLoanAmt;
	}

	public void setMaxLoanAmt(long maxLoanAmt) {
		this.maxLoanAmt = maxLoanAmt;
	}

	public long getMinLoanAmt() {
		return this.minLoanAmt;
	}

	public void setMinLoanAmt(long minLoanAmt) {
		this.minLoanAmt = minLoanAmt;
	}

	public String getPrgmname() {
		return this.prgmname;
	}

	public void setPrgmname(String prgmname) {
		this.prgmname = prgmname;
	}

	public String getProofsReq() {
		return this.proofsReq;
	}

	public void setProofsReq(String proofsReq) {
		this.proofsReq = proofsReq;
	}

	public double getRoi() {
		return this.roi;
	}

	public void setRoi(double roi) {
		this.roi = roi;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Loanapplication> getLoanapplications() {
		return this.loanapplications;
	}

	public void setLoanapplications(List<Loanapplication> loanapplications) {
		this.loanapplications = loanapplications;
	}

	public Loanapplication addLoanapplication(Loanapplication loanapplication) {
		getLoanapplications().add(loanapplication);
		loanapplication.setLoanprogramsoffered(this);

		return loanapplication;
	}

	public Loanapplication removeLoanapplication(Loanapplication loanapplication) {
		getLoanapplications().remove(loanapplication);
		loanapplication.setLoanprogramsoffered(null);

		return loanapplication;
	}

}