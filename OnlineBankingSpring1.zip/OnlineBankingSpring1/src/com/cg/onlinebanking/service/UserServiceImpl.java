package com.cg.onlinebanking.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinebanking.dao.UserDao;
import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.Payee1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.exception.BankException;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	UserDao userDao;

	@Override
	public List<Transactions1> showAllData(long accountNo) throws BankException {
		return userDao.showAllData(accountNo);
	}

	@Override
	public int validateUser(long userid, String pass) throws BankException {
		return userDao.validateUser(userid, pass);
	}

	@Override
	public long getAccountId(long userid) throws BankException {
		return userDao.getAccountId(userid);
	}

	@Override
	public long checkbookRequest(long accountNo) throws BankException {
		return userDao.checkbookRequest(accountNo);
	}

	@Override
	public ServiceTracker1 getTrackDetail(long serviceId, long accountId)
			throws BankException {
		return userDao.getTrackDetail(serviceId, accountId);
	}

	@Override
	public double getAccountBalance(long userId) throws BankException {
		return userDao.getAccountBalance(userId);
	}

	@Override
	public void lockAccount(long userId) throws BankException {

	}

	@Override
	public ArrayList<Payee1> getPayee(long accountId) throws BankException {
		return userDao.getPayee(accountId);
	}

	@Override
	public boolean checkBalance(long accountId, double amount)
			throws BankException {
		return userDao.checkBalance(accountId, amount);
	}

	@Override
	public long transferFund(Transactions1 transaction, long payeeAccountId)
			throws BankException {
		return userDao.transferFund(transaction, payeeAccountId);
	}

	@Override
	public String getTransactionPassword(long accountId) throws BankException {
		// TODO Auto-generated method stub
		return userDao.getTransactionPassword(accountId);
	}

	@Override
	public AccountMaster1 findAccount(long accountId) throws BankException {
		// TODO Auto-generated method stub
		return userDao.findAccount(accountId);
	}

}
