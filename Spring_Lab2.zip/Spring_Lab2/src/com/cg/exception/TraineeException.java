package com.cg.exception;

public class TraineeException extends Exception{
	String message;
	public TraineeException(String message)
	{
		this.message= message;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}
	
}
