package com.loanprocessing.mapper;

public interface LoanApprovalMapper {
	
	public static final String validLad="SELECT * FROM loanuser WHERE role='lad'";
	
	public static final String insertAprrovedLoan = "INSERT INTO approvedloans VALUES(?,?,?,?,?,?,?,?)";
	
	public static final String setInterviewDate = "UPDATE loanapplication SET date_of_interview=? WHERE application_id=?";
	
	public static final String updateStatus = "UPDATE loanapplication SET status=? WHERE application_id =?";
	
	public static final String getPeriod = "SELECT  duration_in_yrs FROM loanprogramsoffered WHERE prgmName=?";
	
	public static final String getRoi = "SELECT roi FROM loanprogramsoffered WHERE prgmName=?";
	
	public static final String getCustName = "SELECT customer_name FROM customer_details WHERE application_id =?";
	
	public static final String getLoanPrg = "SELECT loan.application_Id,cust.customer_name FROM loanapplication loan,"
			+ "customer_details cust WHERE (loan.application_id=cust.application_id) AND (application_date like ?)";

	public static final String viewLoanApp = "SELECT * FROM loanapplication WHERE application_id=?";
	
	public static final String reject = "UPDATE loanapplication SET status=? WHERE application_id =?";
}
