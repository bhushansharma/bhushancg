package com.loanprocessing.bean;

import java.time.LocalDate;


public class LoanApplication {
	
	private int loanAppId;
	private String loanProgm;
	private LocalDate appDate;
	private double amount;
	private String address;
	private double income;
	private String proof;
	private String cover;
	private int marketValue;
	private String status="Applied";
	private LocalDate interviewDate;
	
	public int getLoanAppId() {
		return loanAppId;
	}
	public void setLoanAppId(int loanAppId) {
		this.loanAppId = loanAppId;
	}
	public String getLoanProgm() {
		return loanProgm;
	}
	public void setLoanProgm(String loanProgm) {
		this.loanProgm = loanProgm;
	}
	public LocalDate getAppDate() {
		return appDate;
	}
	public void setAppDate(LocalDate appDate) {
		this.appDate = appDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getIncome() {
		return income;
	}
	public void setIncome(double income) {
		this.income = income;
	}
	public String getProof() {
		return proof;
	}
	public void setProof(String proof) {
		this.proof = proof;
	}
	public String getCover() {
		return cover;
	}
	public void setCover(String cover) {
		this.cover = cover;
	}
	public int getMarketValue() {
		return marketValue;
	}
	public void setMarketValue(int marketValue) {
		this.marketValue = marketValue;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getInterviewDate() {
		return interviewDate;
	}
	public void setInterviewDate(LocalDate interviewDate) {
		this.interviewDate = interviewDate;
	}
	
	
	
	
		
	

}
