package com.cg.university.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;





import com.cg.university.entities.Application;
import com.cg.university.entities.ProgramsOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;
import com.cg.university.logger.MyLogger;


@Repository
public class StudentDaoImpl implements StudentDao {
	
	Logger logger=MyLogger.getLoggerInstance();
	
	private static final String Class_Name=StudentDaoImpl.class.getName();


	
	@PersistenceContext
	private EntityManager entityManager;
	
	/* (non-Javadoc)
	 * @see com.cg.university.dao.StudentDao#insertApplication(com.cg.university.entities.Application)
	 */
	
	/************************************************************************************
	 * File:       	StudentDaoImpl
	 * Package:     com.cg.university.dao
	 * Desc:        insert details about applicants into database 
	 * Version:     1.0
	 * Modifications:NA
	 * Author:     Tushar Patil       Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	
	@Override
	public void insertApplication(Application bean) throws UniversityException {
		// TODO Auto-generated method stub
		
		bean.setStatus("PENDING");
		entityManager.persist(bean);
		entityManager.flush();
		
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME:int insertApplication(Application bean),SUCCESSFULY INSERTED CANDIDATES INFORMATION:"+bean);
	
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.StudentDao#getScheduledPrograms()
	 */
	
	/************************************************************************************
	 * File:    	StudentDaoImpl  
	 * Package:     com.cg.university.dao
	 * Desc:       	Fetch the list of scheduled programs offered by university
	 * Version:     1.0
	 * Modifications:NA
	 * Author:        Amit Kumar    Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	
	@Override
	public ArrayList<ProgramsScheduled> getScheduledPrograms()
			throws UniversityException {
		ArrayList<ProgramsScheduled> list = new ArrayList<ProgramsScheduled>();
		String qStr = "SELECT scprograms FROM ProgramsScheduled scprograms";
		TypedQuery<ProgramsScheduled> query = entityManager.createQuery(qStr, ProgramsScheduled.class);
		list = (ArrayList<ProgramsScheduled>) query.getResultList();
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME:ArrayList<ProgramsScheduled> getScheduledPrograms(),SCHEDULED PROGRAMS ARE INSERTED");
		
		if(list.size()==0)
		{	
			logger.error("ERROR OCCURED IN CLASS:"+Class_Name+"Method name:ArrayList<ProgramsScheduled> getScheduledPrograms(),scheduled programs are not avaliable");
			throw new UniversityException("University will soon declare the scheduled programs for upcoming academic year");
		}
		
		return list;
	}

	/* (non-Javadoc)
	 * @see com.cg.university.dao.StudentDao#getAllPrograms()
	 */
	/************************************************************************************
	 * File:    	StudentDaoImpl  
	 * Package:     com.cg.university.dao
	 * Desc:       	Fetch the list of programs offered by university
	 * Version:     1.0
	 * Modifications:NA
	 * Author:     Amit Kumar       Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public ArrayList<ProgramsOffered> getAllPrograms()
			throws UniversityException {
		// TODO Auto-generated method stub
		ArrayList<ProgramsOffered> list = new ArrayList<ProgramsOffered>();
		String qStr = "SELECT programs FROM ProgramsOffered programs";
		TypedQuery<ProgramsOffered> query = entityManager.createQuery(qStr, ProgramsOffered.class);
		list = (ArrayList<ProgramsOffered>) query.getResultList();
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME: ArrayList<ProgramsOffered> getAllPrograms(),Get information about all program");
		if(list.size()==0)
		{	
			logger.error("ERROR OCCURED IN CLASS:"+Class_Name+"Method name:ArrayList<ProgramsOffered> getAllPrograms(),program information is not avaliable");
			throw new UniversityException("University will soon declare the programs for upcoming academic year");
		}
		
		return list;
	}

	Application applicationbean = null;
	/* (non-Javadoc)
	 * @see com.cg.university.dao.StudentDao#getApplicationStatus(int)
	 */
	/************************************************************************************
	 * File:    	StudentDaoImpl  
	 * Package:     com.cg.university.dao
	 * Desc:       	Fetch the applicants status
	 * Version:     1.0
	 * Modifications:NA
	 * Author:        Shubham Sonar    Date:7/12/2017          Change Description:
	 * Author_Initials          Initial Version
	 ************************************************************************************/
	
	@Override
	public Application getApplicationStatus(int applicationId)
			throws UniversityException {
		Application applicationbean = entityManager.find(Application.class, applicationId);
		logger.info("INFORMATION IS OCCURRED IN CLASS:"+Class_Name+"METHOD NAME: Application getApplicationStatus(int applicationId),GET INFORMATION ABOUT STATUS OF CANDIDATE WHOS APPLICATION ID IS:"+applicationId);
		if(applicationbean == null)
		{
			logger.error("ERROR OCCURED IN CLASS:"+Class_Name+"METHOD NAME:Application getApplicationStatus(int applicationId),APPLICATION ID:"+applicationId+" IS NOT AVALIABLE");
			throw new UniversityException("Records Are not available");
		}
		
		return applicationbean;
	}

	

}
