package com.loanprocessing.dbutil;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import com.loanprocessing.exception.LoanProgramException;

import oracle.jdbc.pool.OracleDataSource;

//import javax.imageio.stream.FileImageInputStream;

public class DBUtil {
	private static Connection con = null;
	private static DBUtil instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;

	// static Properties prop = new Properties();

	private DBUtil() throws LoanProgramException {
		try {
			props = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {
			throw new LoanProgramException(
					" Could not read the database details from properties file ");
		} catch (SQLException e) {
			throw new LoanProgramException(e.getMessage());
		}

	}

	public static DBUtil getInstance() throws LoanProgramException {
		synchronized (DBUtil.class) {
			if (instance == null) {
				instance = new DBUtil();
			}
		}
		return instance;
	}

	public Connection getConnection() throws LoanProgramException {
		try {

			con = dataSource.getConnection();

		} catch (SQLException e) {
			throw new LoanProgramException(" Database connection problem");
		}
		return con;
	}

	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}

	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("url");
				String username = props.getProperty("user");
				String password = props.getProperty("pass");

				dataSource = new OracleDataSource();

				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}
}
