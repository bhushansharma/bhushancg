package com.cg.university.logger;
import java.io.IOException;

import org.apache.log4j.*;
public class MyLogger {
	
	static Logger  logger=Logger.getLogger(MyLogger.class);
	static
	{
		Layout layout=new SimpleLayout();
		Appender appender=null;
		try
		{
			appender=new FileAppender(layout,"P:/Users/shsonar/Desktop/Shubham Sonar/SPRING Workspace/UniversityAdmission/plog.txt");
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		logger.addAppender(appender);
		
	}
		
	public static Logger getLoggerInstance()
	{
		
		return logger;
	}
	
	
}
