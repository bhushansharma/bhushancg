package com.capgemini.ams.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ams.bean.UserMaster;
import com.capgemini.ams.dao.AuthenticationDAOImpl;
import com.capgemini.ams.dao.IAuthenticationDAO;
import com.capgemini.ams.exception.AssetException;

@Service
@Transactional
public class AuthenticationServiceImpl implements IAuthenticationService
{
	@Autowired
	IAuthenticationDAO loginDao;
	
	public void setDao(AuthenticationDAOImpl authDao) 
	{
		loginDao = authDao;
	}

	public AuthenticationServiceImpl()
	{
		loginDao=new AuthenticationDAOImpl(); 		
	}
	
	@Override
	public String getUserType(String userName, String password) throws AssetException
	{
		return loginDao.getUserType(userName,password);
	}

	@Override
	public boolean validateUser(UserMaster user) throws AssetException 
	{
		return loginDao.validateUser(user);
	}
}
