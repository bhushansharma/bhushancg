package com.cg.onlinebanking.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.entities.Users1;
import com.cg.onlinebanking.exception.BankException;
import com.cg.onlinebanking.service.IUserService;

@Controller
public class UserController {

	static long userId;
	@Autowired
	IUserService userService;
	
	@Autowired
	Users1 user;
	
	static long accountId;
	
	@RequestMapping(value = "/showCustomerLogin")
	public String showLoginForm(@RequestParam("role") String role, Model model) {
		model.addAttribute("role", role);
		model.addAttribute("user", user);


		return "login";
	}
	@RequestMapping(value="/validateUserlogin.obj")
	public String validateLogin(@ModelAttribute("user1") Users1 user,
			@RequestParam("role")String role,
			BindingResult result, Model model, HttpServletRequest request)
	{
		userId=user.getUserId();
		String password=user.getLoginPassword();
		
			try {
				if(userService.validateUser(userId, password)==1){
					model.addAttribute("userId", userId);
					HttpSession session=request.getSession(true);
					session.setAttribute("login", userId);
					session.setMaxInactiveInterval(180);
					
				}
				
			} catch (BankException e) {
				model.addAttribute("role",role);
				model.addAttribute("user1",user);
				model.addAttribute("message",e.getMessage());
				return "login";
			}
			return "userHome";
	}
	
	
	
	@RequestMapping(value="/transferFund")
	public String transferFund(Model model)
	{
		long accountId;
		try {
			accountId=userService.getAccountId(userId);
			model.addAttribute("accountId", accountId);
			model.addAttribute("payeeList",userService.getPayee(accountId));
		} catch (BankException e) {
			model.addAttribute("message", e.getMessage());
			return "myError";
		}
		return "fundTransfer";
	}
	
	
	
	/**
	 * Description : process the fund Transfer
	 */
	@RequestMapping(value="/processFundTransfer")
	public String processFundTransfer(@RequestParam("payeeId")long payeeAccountId,
			@RequestParam("accountId")long accountId,Model model){
		model.addAttribute("accountId",accountId);
		model.addAttribute("payeeAccountId",payeeAccountId);
		model.addAttribute("transaction",new Transactions1());
		return "fundTransfer";
		
	}
	
	
	
	/**
	 *  Description : Validate and complete the fund  Transfer
	 */
	@RequestMapping(value = "/completeFundTransfer")
	public String completeFundtansfer(
			@ModelAttribute("transaction") Transactions1 transaction,
			@RequestParam("transactionPassword") String transactionPassword,
			@RequestParam("accountId") long accountId,
			@RequestParam("payeeId") long payeeAccountId, Model model) {
		
		long fundTransferId;
	

		try {
			AccountMaster1 account = userService.findAccount(accountId);
			transaction.setAccountMaster1(account);
			if (userService.getTransactionPassword(accountId).equals(
					transactionPassword))
				fundTransferId = userService.transferFund(transaction, payeeAccountId);
			else 
			{
				model.addAttribute("accountId",accountId);
				model.addAttribute("payeeAccountId",payeeAccountId);
				model.addAttribute("transaction",new Transactions1());
				model.addAttribute("wrongPassword","Wrong Transaction Password");
				return "fundTransfer";
			}
		} catch (BankException e) {
			model.addAttribute("message", e.getMessage());
			return "myError";
		}
		model.addAttribute("fundTransferId", fundTransferId);
		return "successTransaction";
	}
	
	/**
	 *  Description : Request for checkBook
	 */
	@RequestMapping(value="/chequeBookRequest")
	public String requestChequeBook(Model model)
	{
		try {
			long accountId=userService.getAccountId(userId);
			long serviceId= userService.checkbookRequest(accountId);
			model.addAttribute("serviceId", serviceId);
		} catch (BankException e) {
			model.addAttribute("message",e.getMessage());
			return "requestCheckBook";
		}
		
		return "requestCheckBook";
		
	}

	
	@RequestMapping(value="/checkStatus")
	public String checkStatus(Model model)
	{
		try {
			long accountId=userService.getAccountId(userId);
			model.addAttribute("accountId",accountId);
		} catch (BankException e) {
			model.addAttribute("message",e.getMessage());
			return "myError";
		}
		return "serviceRequestForm";
		
	}
	
	@RequestMapping(value="/processCheckService")
	public String processCheckService(@RequestParam("accountId")long accountId,
			@RequestParam("serviceId")long serviceId, Model model) {
				
		try {
			ServiceTracker1 request = userService.getTrackDetail(serviceId, accountId);
			model.addAttribute("request",request);
			model.addAttribute("accountId",accountId);
		} catch (BankException e) {
			model.addAttribute("message",e.getMessage());
			return "myError";
		}
		
		return "serviceRequestForm";
		
	}
	
	
	/*@RequestMapping(value = "/viewMiniStatement")
	public String showMiniStatement(@RequestParam("userId") long userId,Model model) {
		System.out.println(userId);
		ArrayList<Transaction> list = new ArrayList<Transaction>();
		try {
			 Fetching records from service layer 
			accountId = userService.getAccountId(userId);
			System.out.println(accountId);
			list = (ArrayList<Transaction>) userService.showAllData(accountId,userId);
			System.out.println(list);
			model.addAttribute("miniStmt", list);
			
		} catch (BankException e) {
			System.out.println(e.getMessage());
			model.addAttribute("msg", e.getMessage());
		}
		 Checking size of list 
		if (list.size() == 0) {
			return "myError";
		} else {
			
			return "miniStatement";
		}

	}
*/
}
