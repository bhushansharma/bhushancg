package com.loanapplication.service;

import java.util.ArrayList;

import com.loanapplication.entities.CustomerDetail;
import com.loanapplication.entities.Loanapplication;
import com.loanapplication.exception.LoanException;

public interface LADService {
	public ArrayList<CustomerDetail> getCustomerDetails(String loanDate)throws LoanException;

	public Loanapplication getLoanApplication(long custid)throws LoanException;
	
	public boolean approveLoan(long id) throws LoanException;

}
