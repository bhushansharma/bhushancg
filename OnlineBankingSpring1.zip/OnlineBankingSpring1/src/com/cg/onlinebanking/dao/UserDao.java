package com.cg.onlinebanking.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.Payee1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.exception.BankException;

public interface UserDao {
	public List<Transactions1> showAllData(long accountNo) throws BankException;

	public int validateUser(long userid, String pass) throws BankException;

	public long getAccountId(long userid) throws BankException;

	public long checkbookRequest(long accountNo) throws BankException;

	public ServiceTracker1 getTrackDetail(long serviceId, long accountId)
			throws BankException;

	public double getAccountBalance(long userId) throws BankException;

	public ArrayList<Payee1> getPayee(long accountId) throws BankException;

	public boolean checkBalance(long accountId, double amount)
			throws BankException;

	public long transferFund(Transactions1 transaction, long payeeAccountId)
			throws BankException;

	public String getTransactionPassword(long accountId) throws BankException;

	public AccountMaster1 findAccount(long accountId) throws BankException;

	void lockAccount(long userId) throws BankException;

}