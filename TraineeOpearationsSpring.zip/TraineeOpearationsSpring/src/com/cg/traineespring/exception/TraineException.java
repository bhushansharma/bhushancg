package com.cg.traineespring.exception;

public class TraineException extends Exception{
String message;
	
	public TraineException(String message)
	{
		this.message = message;
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}
}
