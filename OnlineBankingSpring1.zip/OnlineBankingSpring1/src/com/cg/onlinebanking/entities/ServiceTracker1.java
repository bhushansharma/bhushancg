package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;


/**
 * The persistent class for the SERVICE_TRACKER1 database table.
 * 
 */
@Component
@Entity
@Table(name="SERVICE_TRACKER1")
@NamedQuery(name="ServiceTracker1.findAll", query="SELECT s FROM ServiceTracker1 s")
public class ServiceTracker1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SERVICE_TRACKER1_SERVICEID_GENERATOR", sequenceName="SERVICE_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SERVICE_TRACKER1_SERVICEID_GENERATOR")
	@Column(name="SERVICE_ID")
	private long serviceId;

	@Column(name="SERVICE_DESCRIPTION")
	private String serviceDescription;

	@Column(name="SERVICE_RAISED_DT")
	private Timestamp serviceRaisedDt;

	@Column(name="SERVICE_STATUS")
	private String serviceStatus;

	//bi-directional many-to-one association to AccountMaster1
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private AccountMaster1 accountMaster1;

	public ServiceTracker1() {
	}

	public long getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(long serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceDescription() {
		return this.serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public Timestamp getServiceRaisedDt() {
		return this.serviceRaisedDt;
	}

	public void setServiceRaisedDt(Timestamp serviceRaisedDt) {
		this.serviceRaisedDt = serviceRaisedDt;
	}

	public String getServiceStatus() {
		return this.serviceStatus;
	}

	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public AccountMaster1 getAccountMaster1() {
		return this.accountMaster1;
	}

	public void setAccountMaster1(AccountMaster1 accountMaster1) {
		this.accountMaster1 = accountMaster1;
	}

}