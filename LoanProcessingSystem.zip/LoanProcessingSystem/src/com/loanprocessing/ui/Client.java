package com.loanprocessing.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.loanprocessing.bean.ApplicationDetails;
import com.loanprocessing.bean.CustomerDetails;
import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.exception.LoanProgramException;
import com.loanprocessing.service.LoanAdminService;
import com.loanprocessing.service.LoanAdminServiceImpl;
import com.loanprocessing.service.LoanApprovalService;
import com.loanprocessing.service.LoanApprovalServiceImpl;
import com.loanprocessing.service.LoanService;
import com.loanprocessing.service.LoanServiceImpl;

public class Client {

	static LoanService service = new LoanServiceImpl();
	static LoanApprovalService ladService = new LoanApprovalServiceImpl();
	static LoanAdminService adminService = new LoanAdminServiceImpl();

	static BufferedReader br = new BufferedReader(new BufferedReader(
			new InputStreamReader(System.in)));
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		showMainMenu();
	}

	private static void showMainMenu() {
		int choice = 0;
		boolean choiceflag = false;

		try {
			do {

				do {
					System.out
							.println("--------------------------------------------");
					System.out
							.println("___________Welcome to CapG Bank____________");
					System.out.println("	 HOMELOAN PROGRAM APPLICATION");
					System.out
							.println("-------------------------------------------");

					System.out.println("1. Are you a User?");
					System.out.println("2. Are you a Admin?");
					System.out.println("3. Are you a LAD?");
					System.out.println("4. Exit");
					System.out.println("Enter your choice.");
					try {
						choiceflag = false;
						choice = Integer.parseInt(br.readLine());
					} catch (Exception e) {
						choiceflag = true;
						System.err
								.println("Invalid Choice Please Select Valid Option... ");

					}
				} while (choiceflag);
				switch (choice) {

				case 1:
					isUser();
					break;

				case 2:
					isAdmin();
					break;

				case 3:
					isLad();
					break;

				case 4:
					System.out.println("Thank You for visiting!!");
					System.exit(0);

				default:
					System.err
							.println("Enter Invalid Choice Please Enter valid choice.....");
				}
			} while (choice != 3);
		} catch (LoanProgramException e) {
			System.out.println(e.getMessage());
		}

	}

	private static void isLad() throws LoanProgramException {
		try {
			boolean choiceflag = false;
			int choice = 0;
			do {
				do {
					System.out
							.println("---------------------------------------------");
					System.out
							.println("______________Welcome LAD __________________");
					System.out.println("        LOAN APPROVAL DEPARTMENT");
					System.out
							.println("--------------------------------------------");
					System.out.println("1.Login");
					System.out.println("2.Back");
					System.out.println("Enter Your Choice...");
					try {
						choiceflag = false;
						choice = Integer.parseInt(br.readLine());
					} catch (Exception e) {
						choiceflag = true;
						System.out
								.println("Invalid Choice Please Select Valid Option... ");

					}
				} while (choiceflag);
				switch (choice) {
				case 1:
					System.out.println("Enter Username:");
					String username = br.readLine();
					System.out.println("Enter Password:");
					String password = br.readLine();

					if (ladService.isValidLad(username, password)) {
						int ladChoice = 0;
						choiceflag = false;
						do {
							System.out.println("1.Loan Approval");
							System.out.println("2.Back");

							System.out.println("Enter your choice");

							try {
								choiceflag = false;
								ladChoice = Integer.parseInt(br.readLine());
							} catch (Exception e) {
								choiceflag = true;
								System.out
										.println("Invalid Choice Please Select Valid Option... ");

							}
						} while (choiceflag);

						switch (ladChoice) {

						case 1:
							approvalOfLoan();
							break;
						case 2:
							System.out.println("Thank You for visiting!!");
							isLad();
						default:
							System.out
									.println("Invalid Choice Please Select Valid Option... ");
							isLad();
						}

					} else {
						System.out.println("Invalid Username Password");
						showMainMenu();
					}

				case 2:
					showMainMenu();
					break;

				default:
					System.out
							.println("Invalid Choice Please Select Valid Option... ");

				}
			} while (choice != 2);
		} catch (IOException e) {
			throw new LoanProgramException(e.getMessage());
		}

	}

	private static void approvalOfLoan() throws LoanProgramException {
		// TODO Auto-generated method stub
		try(Scanner sc = new Scanner(System.in)) {
			
			System.out
					.println("Enter the Date for which you want to view the Loan Applications(dd/mm/yyyy)");
			DateTimeFormatter format = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			String date = sc.next();
			LocalDate loanDate = LocalDate.parse(date, format);

			HashMap<Integer, String> application = ladService
					.getLoanApplication(loanDate);
			if (application.size() != 0) {
				System.out.println("Applicant Id \t" + "Applicant Name");
				for (int loanAppId : application.keySet()) {
					System.out.println(loanAppId + "\t\t"
							+ application.get(loanAppId));

				}
				System.out
						.println("Enter the Application Id you want to view ");
				int appId = scan.nextInt();
				LoanApplication loanApp = new LoanApplication();
				loanApp = ladService.viewLoanApplicationLAD(appId);

				System.out
						.println("Application Id		:" + loanApp.getLoanAppId());
				System.out.println("Application Date	:" + loanApp.getAppDate());
				System.out.println("Name Of Loan Program	:"
						+ loanApp.getLoanProgm());
				System.out.println("Amount of Loan		:" + loanApp.getAmount());
				System.out.println("Address Of Property 	:"
						+ loanApp.getAddress());
				System.out.println("Annual Family Income	:"
						+ loanApp.getIncome());
				System.out.println("Document Proofs 	:" + loanApp.getProof());
				System.out.println("Guarantee Cover		:" + loanApp.getCover());
				System.out.println("Market Value Of Guarntee Cover:"
						+ loanApp.getMarketValue());
				System.out.println("Status Of Loan Application:"
						+ loanApp.getStatus());
				System.out.println("Date Of Interview	:"
						+ loanApp.getInterviewDate());

				System.out.println("1.Approve");
				System.out.println("2.Reject");
				System.out.println("3.Back");
				int choice = scan.nextInt();
				switch (choice) {
				case 1:
					if (loanApp.getStatus().equals("APPROVED")
							|| loanApp.getStatus().equals("REJECT"))
						System.out
								.println("Approval of the loan has already been done for this loan application "
										+ loanApp.getLoanAppId());
					else if (loanApp.getStatus().equals("Applied"))
						if (ladService.approvedLoans(loanApp)) {
							System.out
									.println("You have approved the loan application of "
											+ loanApp.getLoanAppId());
							System.out.println("Thank You !!");
							isLad();
						}

					break;
				case 2:
					if (loanApp.getStatus().equals("APPROVED")
							|| loanApp.getStatus().equals("REJECT"))
						System.out
								.println("Approval of the loan has already been done for this loan application "
										+ loanApp.getLoanAppId());
					else if (loanApp.getStatus().equals("Applied"))
						if (ladService.rejectLoans(loanApp)) {
							System.out
									.println("You have rejected the loan application of "
											+ loanApp.getLoanAppId());
							System.out.println("Thank You !!");
							isLad();
						}
					break;
				case 3:
					
					System.out.println("Thank you for visiting !!");
					isLad();
					
				}
			} else {
				System.err.println("No Records are available for this Date "
						+ loanDate);
				isLad();
			}

		} catch (Exception e) {
			throw new LoanProgramException(e.getMessage());
		}
	}

	public static void isUser() throws LoanProgramException {
		boolean choiceFlag = false;
		int userchoice = 0;

		do {
			System.out.println("---------------------------------------------");
			System.out.println("______________Welcome User __________________");
			System.out.println("---------------------------------------------");
			System.out.println("1.View HomeLoan Programs");
			System.out.println("2.Check Loan Status");
			System.out.println("3.Back");

			System.out.println("Enter your choice.");
			try {
				choiceFlag = false;
				userchoice = Integer.parseInt(br.readLine());
			} catch (Exception e) {
				choiceFlag = true;
				System.err
						.println("Invalid Choice Please Select Valid Option... ");

			}
		} while (choiceFlag);
		switch (userchoice) {
		case 1:
			viewLoan();
			break;
		case 2:
			checkStatus();
			break;
		case 3:
			showMainMenu();
			break;
		default:
			System.err.println("Please Enter valid choice..");
			isUser();

		}

	}

	private static void checkStatus() throws LoanProgramException {
		boolean choiceFlag = false;
		int loanAppId = 0;
		do {
			System.out.println("---------------------------------------------");
			System.out.println("_____________Check Loan Status_______________");
			System.out.println("---------------------------------------------");
			System.out.println("Enter Loan Application Id ");
			try {
				choiceFlag = false;
				loanAppId = Integer.parseInt(br.readLine());
			} catch (Exception e) {
				choiceFlag = true;
				System.err
						.println("Invalid Choice Please Select Valid Option... ");

			}
		} while (choiceFlag);

		LoanApplication loanAppBean = service.checkStatus(loanAppId);
		if (loanAppBean != null) {
			System.out.println("--------------------------------------------");
			System.out.println("\nApplication Id 		:" + loanAppId);
			System.out
					.println("Application Date 	:" + loanAppBean.getAppDate());
			System.out.println("Application Status 	:"
					+ loanAppBean.getStatus());

			if (loanAppBean.getInterviewDate() == null)
				System.out.println("Date of Interview 	: NA");
			else
				System.out.println("Date of Interview 	:"
						+ loanAppBean.getInterviewDate());

			isUser();
		} else {
			System.err.println(loanAppId + " not available.");
			isUser();
		}
	}

	public static void viewLoan() throws LoanProgramException {
		boolean choiceFlag = false;
		int loanChoice = 0;
		HashMap<Integer, String> loanPrograms = null;
		LoanPrograms loanProgram = null;
		try {
			do {
				loanPrograms = service.getLoanProgram();
				System.out.println("----------------------------------------");
				System.out.println("____Home Loan Programs offered_____");
				System.out.println("Loan Id \t" + "Loan Program Type");
				System.out.println("----------------------------------------");
				for (int loanId : loanPrograms.keySet()) {
					System.out.println(loanId + "\t\t"
							+ loanPrograms.get(loanId));

				}
				int loanId = 0;
				do {
					System.out
							.println("-------------------------------------------------------");
					System.out
							.println("Enter Loan Program Id that you want to show");

					try {
						choiceFlag = false;
						loanId = Integer.parseInt(br.readLine());
					} catch (Exception e) {
						choiceFlag = true;
						System.err
								.println("Invalid Choice Please Select Valid Option... ");
					}
				} while (choiceFlag);
				loanProgram = service.getLoanDescription(loanId);
				System.out
						.println("-------------------------------------------------------");

				if (loanProgram != null) {
					System.out.println("\nDescription	: "
							+ loanProgram.getDescriptn());
					System.out.println("Type           	: "
							+ loanProgram.getType());
					System.out.println("Duration Year   : "
							+ loanProgram.getDuration());
					System.out.println("Min Loan Amount : "
							+ loanProgram.getMinAmount());
					System.out.println("Max Loan Amount : "
							+ loanProgram.getMaxAmount());
					System.out.println("Rate of Interest: "
							+ loanProgram.getRate() + "%");
					System.out.println("Proofs Required for Loan : "
							+ loanProgram.getProof());
				} else {
					System.out
							.println("Invalid Loan Program Id Please enter Valid loan program id..");
					viewLoan();
				}
				System.out
						.println("-------------------------------------------------------");
				System.out.println("1.Apply ");
				System.out.println("2.Back");
				System.out.println("3.Exit");
				System.out.println("Enter your choice ");

				try {
					choiceFlag = false;
					loanChoice = Integer.parseInt(br.readLine());
				} catch (Exception e) {
					choiceFlag = true;
					System.out
							.println("Invalid Choice Please Select Valid Option... ");

				}
			} while (choiceFlag);
			switch (loanChoice) {
			case 1:

				applyLoan(loanProgram);
				break;
			case 2:

				isUser();
				break;
			case 3:
				System.out.println("Thank You for visiting!!");
				System.exit(0);
			default:
				System.out
						.println("Invalid Choice Please Select Valid Option... ");
				viewLoan();
			}
		} catch (NumberFormatException e) {
			throw new LoanProgramException(e.getMessage());

		}

	}

	public static void applyLoan(LoanPrograms loanProgram)
			throws LoanProgramException {
		try {
			LoanApplication loanApplication = new LoanApplication();
			boolean flag = true;
			LocalDate applicationDate = LocalDate.now();
			loanApplication.setAppDate(applicationDate);
			loanApplication.setLoanProgm(loanProgram.getProgramName());
			while (flag) {
				System.out.println("Enter the Loan Amount");
				
				double loanAmount = scan.nextDouble();
				if (service.isValidateLoanAmount(loanAmount,
						loanProgram.getMinAmount(), loanProgram.getMaxAmount())) {
					flag = false;
					loanApplication.setAmount(loanAmount);
				} else
					System.err
							.println("Invalid Loan amount Please Enter loan Amount Between "
									+ loanProgram.getMinAmount()
									+ " and "
									+ loanProgram.getMaxAmount());
			}
			System.out.println("Address of Property ");
			String addOfProperty = br.readLine();
			loanApplication.setAddress(addOfProperty);
			System.out.println("Enter Anuual Family Income");
			long annualFamilyIncome = scan.nextLong();
			if (service.isValidateAnnualIncome(annualFamilyIncome,
					loanApplication.getAmount())) {
				System.err
						.println("Sorry we can not grant you the loan as your annual income does not match our requirements ");
				isUser();

			} else {
				loanApplication.setIncome(annualFamilyIncome);

				String docChoice;
				do {
					System.out
							.println("Documents Proof Available\n1.Adhar Card\n2.Pancard\n3.Pay Slip\n");

					System.out
							.println("Do you have all these documents? Enter Yes or No");
					docChoice = br.readLine();
					if (docChoice.equalsIgnoreCase("Yes")) {
						ArrayList<String> docProofAvailable = new ArrayList<>();
						docProofAvailable.add("Adhar Card");
						docProofAvailable.add("Pancard");
						docProofAvailable.add("Pay Slip");
						loanApplication.setProof(docProofAvailable.toString());
					} else if (docChoice.equalsIgnoreCase("No")) {
						System.err
								.println("Sorry you should have all these mandatory documents");
						System.err
								.println("We can not process your further request");
						isUser();

					} else
						System.err.println("Please enter yes or no");
				} while (!docChoice.equalsIgnoreCase("yes"));

				System.out.println("Do you have Guarantee Cover ? yes/no");
				String guaranteeChoice = br.readLine();
				if (guaranteeChoice.equalsIgnoreCase("yes")) {
					System.out.println("Enter Guarantee cover ");
					String guaranteeCover = br.readLine();
					loanApplication.setCover(guaranteeCover);
					System.out.println("Market Value of Guarantee Cover");
					int marketVal = scan.nextInt();
					loanApplication.setMarketValue(marketVal);
				}

				if (service.insertLoanApplictaion(loanApplication)) {
					CustomerDetails custBean = new CustomerDetails();
					custBean.setLoanAppId(loanApplication.getLoanAppId());
					flag = true;
					while (flag) {
						System.out.println("Enter Customer Name ");
						String custName = br.readLine();
						if (service.isValidateCustName(custName)) {
							flag = false;
							custBean.setAppName(custName);
						} else {
							System.out
									.println("Enter Name properly,name should have first alphabet as capital");
						}
					}
					flag = true;
					while (flag) {
						System.out.println("Enter Date Of Birth(dd/MM/yyyy) ");
						DateTimeFormatter format = DateTimeFormatter
								.ofPattern("dd/MM/yyyy");
						String dob = br.readLine();
						LocalDate custDob = LocalDate.parse(dob, format);

						if (service.validateDob(custDob)) {
							flag = false;

							custBean.setDob(custDob);
						} else {
							System.err
									.println("Your age is not eligible for applying loan\n"
											+ "Your age should be greater than 25");
							isUser();
						}
					}
					flag = true;
					while (flag) {
						System.out.println("Enter Marital Status ");
						String maritalStatus = br.readLine();
						if (service.isValidateCustMaritalStatus(maritalStatus)) {
							flag = false;
							custBean.setMaritalStatus(maritalStatus);
						} else {
							System.err
									.println("Enter Marital Status as Single ,Married or Divorced only");
						}

					}
					flag = true;
					while (flag) {
						System.out.println("Enter Mobile Number");
						String mobNum = br.readLine();
						if (service.isValidateCustMobNo(mobNum)) {
							flag = false;
							custBean.setMobileNo(mobNum);
						} else {
							System.err
									.println("Mobile number should contain 10 digits only");
						}
					}

					flag = true;
					while (flag) {

						System.out.println("Enter Alternate Number");
						String phoneNum = br.readLine();
						if (service.isValidateCustPhNo(phoneNum)) {
							flag = false;
							custBean.setPhoneNo(phoneNum);
						} else {
							System.err.println("Enter Phone No properly");
						}
					}
					flag = true;
					while (flag) {
						System.out.println("Enter Count of Dependents ");
						// int counOfDept = Integer.parseInt(br.readLine());
						int counOfDept = scan.nextInt();
						if (service.isValidateCustCountOfDependents(counOfDept)) {
							flag = false;
							custBean.setCount(counOfDept);
						} else {
							System.err
									.println("Count of Dependants should be in Digits only ");
						}
					}
					flag = true;
					while (flag) {
						System.out.println("Enter Email Id ");
						String custEmailId = br.readLine();
						if (service.isValidateCustEmailId(custEmailId)) {
							flag = false;
							custBean.setEmail(custEmailId);
						} else {
							System.err
									.println("Enter Email id properly in abc@gmail.com format");
						}
					}
					if (service.insertCustomerDetails(custBean)) {
						System.out
								.println("Thank you for Applying Home Loan!! Your Application ID "
										+ custBean.getLoanAppId());
						isUser();
					}
				}
			}

		} catch (IOException e) {
			throw new LoanProgramException(e.getMessage());

		}
	}

	public static void isAdmin() throws LoanProgramException {
		try {
			Scanner sc = new Scanner(System.in);
			String username = null;
			String password = null;
			boolean choiceFlag = false;
			int adminChoice = 0;

			do {
				System.out
						.println("---------------------------------------------");
				System.out
						.println("______________Welcome Admin__________________");
				System.out
						.println("---------------------------------------------");
				System.out.println("1.Login");
				System.out.println("2.Back");

				try {
					choiceFlag = false;
					adminChoice = Integer.parseInt(br.readLine());
				} catch (Exception e) {
					choiceFlag = true;
					System.out
							.println("Invalid Choice Please Select Valid Option... ");

				}
			} while (choiceFlag);
			switch (adminChoice) {
			case 1:
				System.out.println("Enter the username:");
				username = sc.next();
				System.out.println("Enter the password");
				password = sc.next();

				if (adminService.isValidAdmin(username, password)) {

					displayMenu();
				} else {
					System.out.println("Invalid Username Password");
					isAdmin();
				}
				sc.close();
			case 2:
				showMainMenu();
				break;

			default:
				System.out.println("Pleace enter valid choice");
				isAdmin();
			}
		} catch (NumberFormatException | InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("Please enter valid choice");
		}
	}

	private static void displayMenu() throws LoanProgramException {
		boolean choiceFlag = false;
		int userchoice = 0;
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("---------------------------------------------");
			System.out.println("1.View Loan Programs Offered");
			System.out.println("2.Add Loan Programs");
			System.out.println("3.Modify Loan Programs");
			System.out.println("4.Delete Loan Programs");
			System.out.println("5.View Loan Application");
			System.out.println("6.Back");
			System.out.println("7.Exit");
			System.out.println("---------------------------------------------");

			System.out.println("Enter your choice.");

			try {
				choiceFlag = false;
				userchoice = Integer.parseInt(br.readLine());
			} catch (Exception e) {
				choiceFlag = true;
				System.out
						.println("Invalid Choice Please Select Valid Option... ");

			}
			while (choiceFlag)
				;
			switch (userchoice) {
			case 1:

				viewLoanPrograms();
				break;

			case 2:
				addLoanPrograms();
				break;
			case 3:
				updateMenu();
				break;
			case 4:
				deleteLoanProgram();
				break;
			case 5:
				getLoanApplication();
				break;
			case 6:
				showMainMenu();
				System.out.println("Thank you for visiting");

			case 7:
				System.out.println("Thank you for visiting");
				System.exit(0);

			default:
				System.out.println("Please enter valid choice");
				displayMenu();
				break;
			}
			sc.close();
		} catch (NumberFormatException | InputMismatchException e) {
			System.out.println("Enter Valid Choice");
			displayMenu();
		}
	}

	private static void updateMenu() throws LoanProgramException {
		boolean choiceFlag = false;
		int choice = 0;
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the field you want to update");
			System.out.println("1.Rate Of Interest(ROI)");
			System.out.println("2.Minimum Amount");
			System.out.println("3.Maximum Amount");
			System.out.println("4.Back");
			System.out.println("Enter your Choice");

			try {
				choiceFlag = false;
				choice = Integer.parseInt(br.readLine());
			} catch (Exception e) {
				choiceFlag = true;
				System.out
						.println("Invalid Choice Please Select Valid Option... ");

			}
			while (choiceFlag)
				;
			switch (choice) {
			case 1:
				updateROI();
				break;
			case 2:
				updateMinimumAmnt();
				break;
			case 3:
				updateMaximumAmnt();
				break;
			case 4:
				displayMenu();
				break;
			default:
				System.out.println("Please enter valid choice");
				updateMenu();
				break;
			}
			sc.close();
		} catch (NumberFormatException | InputMismatchException e) {
			System.out.println("Enter Valid Choice");
			updateMenu();
		}
	}

	private static void updateMaximumAmnt() throws LoanProgramException {
		// TODO Auto-generated method stub
		try {
			Scanner sc = new Scanner(System.in);
			boolean flag = false;
			System.out
					.println("-------------------------------------------------");
			System.out
					.println("_______Modification of Home Loan programs________");
			System.out
					.println("-------------------------------------------------");
			System.out.println("Enter the Loan Program Id to be updated");
			int id = sc.nextInt();
			LoanPrograms loanProgram = service.getLoanDescription(id);
			if (loanProgram != null) {
				System.out.println("Enter the new Maximum Amount");
				int maxAmt = sc.nextInt();
				if (maxAmt > loanProgram.getMinAmount()) {
					flag = adminService.updateMaxAmt(id, maxAmt);
					if (flag == true) {
						System.out
								.println("Maximum Amount Updated Sucessfully for Loan Program"
										+ id);
						System.out.println("1.Back");
						System.out.println("2.Exit");
						System.out.println("Enter your choice  ");
						int menu = Integer.parseInt(br.readLine());
						switch (menu) {
						case 1:
							displayMenu();
							break;
						case 2:
							System.exit(0);

						default:
							System.out.println("Please Enter Correct choice");
							updateMenu();
							break;
						}
					}
				} else {
					System.out
							.println("Maximum Loan Amount should be greater than minimum loan amount");
					updateMenu();
				}
			} else {
				System.out.println("The Id entered do not exist");
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int menu = Integer.parseInt(br.readLine());
				switch (menu) {
				case 1:
					updateMenu();
					break;
				case 2:
					System.exit(0);
				default:
					System.out.println("Please enter valid choice");
					updateMenu();
					break;
				}
				sc.close();
			}

		} catch (NumberFormatException | IOException | InputMismatchException e) {
			System.out.println("Enter Valid Choice");
			updateMaximumAmnt();
		}

	}

	private static void updateMinimumAmnt() throws LoanProgramException {
		try {
			Scanner sc = new Scanner(System.in);
			boolean flag = false;
			System.out
					.println("-------------------------------------------------");
			System.out
					.println("_______Modification of Home Loan programs________");
			System.out
					.println("-------------------------------------------------");
			System.out.println("Enter the Loan Program Id to be updated");
			int id = sc.nextInt();
			LoanPrograms loanProgram = service.getLoanDescription(id);
			if (loanProgram != null) {
				System.out.println("Enter the new Minimum Amount");
				int minAmt = sc.nextInt();
				if (minAmt > 0) {
					flag = adminService.updateMinAmt(id, minAmt);
					if (flag == true) {
						System.out
								.println("Minimum Amount Updated Sucessfully for Loan Program"
										+ id);
						System.out.println("1.Back");
						System.out.println("2.Exit");
						System.out.println("Enter your choice  ");
						int menu = Integer.parseInt(br.readLine());
						switch (menu) {
						case 1:
							displayMenu();
							break;
						case 2:
							System.exit(0);
						default:
							System.out.println("Please Enter Correct choice");
							updateMenu();
							break;
						}
					}
				} else {
					System.out
							.println("Please Enter Minimum Loan Amount Greater Than Zero");
					updateMenu();
				}
			} else {
				System.out.println("The Id entered do not exist");
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int menu = Integer.parseInt(br.readLine());
				switch (menu) {
				case 1:
					updateMenu();
					break;
				case 2:
					System.exit(0);

				default:
					System.out.println("Please enter valid choice");
					updateMenu();
					break;
				}
				sc.close();
			}
		} catch (NumberFormatException | IOException | InputMismatchException e) {
			System.out.println("Enter Valid Choice");
			updateMinimumAmnt();
		}
	}

	private static void updateROI() throws LoanProgramException {
		// TODO Auto-generated method stub
		try {
			Scanner sc = new Scanner(System.in);
			boolean flag = false;
			System.out
					.println("-------------------------------------------------");
			System.out
					.println("_______Modification of Home Loan programs________");
			System.out
					.println("-------------------------------------------------");
			System.out.println("Enter the Loan Program Id to be updated");
			int id = sc.nextInt();
			LoanPrograms loanProgram = service.getLoanDescription(id);
			if (loanProgram != null) {
				System.out.println("Enter the new Rate of Interest");
				double rate = sc.nextDouble();
				if (rate > 0) {
					flag = adminService.updateROI(id, rate);
					if (flag == true) {
						System.out
								.println("Rate of interest Updated Sucessfully for Loan Program"
										+ id);
					}
				} else {
					System.out.println("Please Enter ROI Greater Than Zero");
					updateMenu();
				}
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int menu = Integer.parseInt(br.readLine());
				switch (menu) {
				case 1:
					displayMenu();
					break;
				case 2:
					System.exit(0);
				default:
					System.out.println("Please Enter Correct choice");
					updateMenu();
					break;
				}
			}

			else {
				System.out.println("The Id entered do not exist");
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int menu = Integer.parseInt(br.readLine());
				switch (menu) {
				case 1:
					updateMenu();
					break;
				case 2:
					System.exit(0);

				default:
					System.out.println("Please enter valid choice");
					updateMenu();
					break;
				}
				sc.close();
			}
		} catch (NumberFormatException | IOException | InputMismatchException e) {
			System.out.println("Please enter valid choice");
			updateROI();
		}
	}

	private static void getLoanApplication() throws LoanProgramException {
		// TODO Auto-generated method stub
		try {
			Scanner sc = new Scanner(System.in);
			System.out
					.println("Enter the Date for which you want to view the Loan Applications(dd/mm/yyyy)");
			DateTimeFormatter format = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			String date = sc.next();
			LocalDate loanDate = LocalDate.parse(date, format);

			ArrayList<ApplicationDetails> loan = new ArrayList<>();
			loan = adminService.viewLoanApplication(loanDate);
			if (loan.size() != 0) {
				for (ApplicationDetails app : loan) {
					System.out
							.println("----------------------------------------------------------");
					System.out.println("Application Id		:"
							+ app.getApplicationId());
					System.out.println("Applicant Name		:" + app.getName());
					System.out.println("Application Date	:" + app.getAppDate());
					System.out.println("Name Of Loan Program	:"
							+ app.getLoanProgm());
					System.out.println("Amount of Loan		:" + app.getAmount());
					System.out.println("Address Of Property	:"
							+ app.getAddress());
					System.out.println("Annual Family Income	:"
							+ app.getIncome());
					System.out.println("Document Proofs 	:" + app.getProof());
					System.out.println("Guarantee Cover		:" + app.getCover());
					System.out.println("Market Value Of Guarntee Cover:"
							+ app.getMarketValue());
					System.out.println("Status Of Loan Application:"
							+ app.getStatus());
					System.out.println("Date Of Interview	:"
							+ app.getInterviewDate());
					System.out
							.println("----------------------------------------------------------");
				}
			} else {
				System.out.println("No Records are available for this Date "
						+ date);
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int admin = Integer.parseInt(br.readLine());
				switch (admin) {
				case 1:
					displayMenu();
					break;
				case 2:
					System.exit(0);

				default:
					System.out.println("Please enter valid choice");
					break;
				}
			}
			System.out.println("1.Back");
			System.out.println("2.Exit");
			System.out.println("Enter your choice  ");
			int admin = Integer.parseInt(br.readLine());
			switch (admin) {
			case 1:
				displayMenu();
				break;
			case 2:
				System.exit(0);

			default:
				System.out.println("Please enter valid choice");
				break;
			}
			sc.close();
		} catch (NumberFormatException | IOException | InputMismatchException e) {
			System.out.println("Please enter valid choice");
			displayMenu();
		}
	}

	private static void deleteLoanProgram() throws LoanProgramException {
		// TODO Auto-generated method stub
		int prgId = 0;
		boolean flag = false;
		try {
			Scanner sc = new Scanner(System.in);
			System.out
					.println("-------------------------------------------------");
			System.out
					.println("_________Deletion of Home Loan programs__________");
			System.out
					.println("-------------------------------------------------");
			System.out.println("Enter the Program Id you want to delete");
			prgId = sc.nextInt();
			flag = adminService.deleteLoanProgram(prgId);
			if (flag == true) {
				System.out
						.println("Loan program successfully deleted with Program Id:"
								+ prgId);
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int admin = Integer.parseInt(br.readLine());
				switch (admin) {
				case 1:
					displayMenu();
					break;
				case 2:
					System.exit(0);

				default:
					System.out.println("Please enter valid choice");
					break;
				}
			} else {
				System.out.println("Loan Program Could not be deleted");
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int admin = Integer.parseInt(br.readLine());
				switch (admin) {
				case 1:
					displayMenu();
					break;
				case 2:
					System.exit(0);
					break;
				default:
					System.out.println("Please enter valid choice");
					displayMenu();
					break;
				}
			}
			sc.close();
		} catch (NumberFormatException | IOException | InputMismatchException e) {
			System.out.println("Please enter valid choice");
			displayMenu();
		}

	}

	private static void addLoanPrograms() throws LoanProgramException {
		LoanPrograms prg = new LoanPrograms();

		boolean flag;

		int prgId = 0;
		String prgName = null;
		String prgType = null;
		String description = null;
		int duration = 0;
		int maxAmount = 0;
		int minAmount = 0;
		Double prgROI = 0.0;
		String proofs = null;

		try {
			Scanner sc = new Scanner(System.in);
			flag = true;
			while (flag) {
				System.out.println("Enter the Program Id");
				prgId = sc.nextInt();
				if ((adminService.isValidateProgramId(prgId))) {
					flag = false;
					prg.setProgramId(prgId);
				} else {
					System.out
							.println("Enter Program ID properly..It should not Start with Zero & be a Five Digit number at Maximum");
				}
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the Program Name");
				prgName = br.readLine();
				if (adminService.isValidateProgramName(prgName)) {
					flag = false;
					prg.setProgramName(prgName);
				} else {
					System.out
							.println("Enter Program Name properly,First Alphabet should be capital and it should have minimum length 2  and maximum length 10");
				}
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the Program Type");
				prgType = br.readLine();
				if (adminService.isValidateProgramType(prgType)) {
					flag = false;
					prg.setType(prgType);
				} else {
					System.out
							.println("Enter Program Type properly,First Alphabet should be capital and it should have minimum length 2 and maximum length 15");

				}
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the Program Description ");
				description = br.readLine();
				if (adminService.isValidateProgramDescription(description)) {
					flag = false;
					prg.setDescriptn(description);
				} else {
					System.out
							.println("Enter Program Description properly,First Alphabet should be capital and it should have minimum 2 alphabets and maximum 40 alphabet");
				}
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the Program Duration");
				duration = sc.nextInt();
				if (adminService.isValidateProgramDuration(duration)) {
					flag = false;
					prg.setDuration(duration);
				} else {
					System.out
							.println("Enter Program Duration properly,Duration should not be zero and should be a 2 digit number at maximum");
				}
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the minimum loan amount");
				minAmount = sc.nextInt();
				if (adminService.isValidateProgramMinAmt(minAmount)) {
					flag = false;
					prg.setMinAmount(minAmount);
				} else {
					System.out
							.println("Enter Minimum Amount properly,It should not should not be zero and should be a 10 digit number at maximum");
				}
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the Maximum loan amount");
				maxAmount = sc.nextInt();
				if (prg.getMinAmount() < maxAmount) {
					if (adminService.isValidateProgramMaxAmt(maxAmount)) {
						flag = false;
						prg.setMaxAmount(maxAmount);
					} else {
						System.out
								.println("Enter Maximum Amount properly,it should not be zero and should be a 10 digit number at maximum");
					}
				} else {
					System.out
							.println("Maximum Loan Amount should be greater than Minimum Loan Amount");
				}
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the rate of interest");
				prgROI = sc.nextDouble();
				if (prgROI > 0) {
					if (adminService.isValidateProgramRoi(prgROI)) {
						flag = false;
						prg.setRate(prgROI);
					} else {
						System.out
								.println("Enter Rate of Interest Properly,it should not be zero and should contain only 2 digits before and after decimal e.g.12.25");
					}
				} else
					System.out
							.println("Rate of interest should be greater than 0.");
			}

			flag = true;
			while (flag) {
				System.out.println("Enter the proofs required for giving loan");
				proofs = br.readLine();
				if (adminService.isValidateProgramProofs(proofs)) {
					flag = false;
					prg.setProof(proofs);
				} else {
					System.out
							.println("Enter Valid Proofs,First Alphabet should be capital and it should have minimum length 2 and maximum length 50");
				}
			}

			boolean flag1 = false;
			flag1 = adminService.addLoanProgram(prg);
			if (flag1) {
				System.out
						.println("Loan Program added successfully with program ID: "
								+ prgId);
				System.out.println("1-Back");
				System.out.println("2-Exit");
				System.out.println("Enter your choice  ");
				int admin = sc.nextInt();
				switch (admin) {
				case 1:
					displayMenu();
					break;
				case 2:
					System.exit(0);

				default:
					System.out.println("Please enter valid choice");
					displayMenu();
					break;

				}
			} else {
				System.out.println("Loan Program was not added successfully");
				System.out.println("1.Back");
				System.out.println("2.Exit");
				System.out.println("Enter your choice  ");
				int admin = Integer.parseInt(br.readLine());
				switch (admin) {
				case 1:
					displayMenu();
					break;
				case 2:
					System.exit(0);

				default:
					System.out.println("Please enter valid choice");
					displayMenu();
					break;
				}
			}
			sc.close();
		} catch (NumberFormatException | IOException | InputMismatchException e) {
			System.out.println("Enter Valid Input");
			System.out.println("1.Add Loan Program");
			System.out.println("2.Exit");
			System.out.println("Enter your choice");
			Scanner sc = new Scanner(System.in);
			int admin = sc.nextInt();
			switch (admin) {
			case 1:
				addLoanPrograms();
				break;
			case 2:
				System.exit(0);
				break;
			default:
				System.out.println("Please enter valid choice");
				displayMenu();
				break;

			}
			sc.close();
		}

	}

	private static void viewLoanPrograms() throws LoanProgramException {
		// TODO Auto-generated method stub

		try {
			Scanner sc = new Scanner(System.in);
			ArrayList<LoanPrograms> loanPrograms = adminService
					.getLoanProgramsAdmin();
			System.out.println("------------------------------------");
			System.out.println("_____Home Loan Programs offered_____");
			System.out.println("------------------------------------");
			for (LoanPrograms var : loanPrograms) {
				System.out.println("Loan Id		:" + var.getProgramId());
				System.out.println("Description	:" + var.getDescriptn());
				System.out.println("Type		:" + var.getType());
				System.out.println("Duration Year	:" + var.getDuration());
				System.out.println("Min Loan Amount	:" + var.getMinAmount());
				System.out.println("Max Loan Amount	:" + var.getMaxAmount());
				System.out.println("Rate of Interest:" + var.getRate());
				System.out.println("Proofs Required : " + var.getProof());
				System.out
						.println("------------------------------------------");
			}
			System.out.println("1.Back");
			System.out.println("2.Exit");
			System.out.println("Enter your choice  ");
			int admin = sc.nextInt();
			switch (admin) {
			case 1:

				displayMenu();
				break;
			case 2:

				System.exit(0);

			default:
				System.out.println("Please enter valid choice");
				displayMenu();
				break;
			}
			sc.close();
		} catch (NumberFormatException | InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("There are no programs to display");
			System.out.println("1.Back");
			System.out.println("2.Exit");
			System.out.println("Enter your choice  ");
			Scanner sc = new Scanner(System.in);
			int admin = sc.nextInt();
			switch (admin) {
			case 1:
				displayMenu();
				break;
			case 2:
				System.exit(0);

			default:
				System.out.println("Please enter valid choice");
				displayMenu();
				break;
			}
			sc.close();
		}
	}

}
