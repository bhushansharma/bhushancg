package com.loanprocessing.service;


import java.time.LocalDate;
import java.time.Period;
import java.util.HashMap;
import java.util.regex.Pattern;



import com.loanprocessing.bean.CustomerDetails;
import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.dao.LoanDAO;
import com.loanprocessing.dao.LoanDAOImpl;
import com.loanprocessing.exception.LoanProgramException;

public class LoanServiceImpl implements LoanService{

	
	LoanDAO dao;
	
	public void setDao(LoanDAO dao)
	{
		this.dao=dao;
	}
	
	
	public LoanServiceImpl() {
		// TODO Auto-generated constructor stub
		dao=new LoanDAOImpl();
		
		
	}	
	
	@Override
	public HashMap<Integer, String> getLoanProgram()
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return dao.getLoanProgram();
	}

	@Override
	public LoanPrograms getLoanDescription(int loanId)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return dao.getLoanDescription(loanId);
	}

	@Override
	public boolean isValidateLoanAmount(double loanAmount,double minAmt,double maxAmt)
			throws LoanProgramException {
		boolean flag=false;
		if(loanAmount <= maxAmt && loanAmount >= minAmt )
			flag=true;
		
		return flag;
	}

	@Override
	public boolean insertLoanApplictaion(LoanApplication loanApp)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return dao.insertLoanApplictaion(loanApp);
	}

	@Override
	public boolean insertCustomerDetails(CustomerDetails custBean)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return dao.insertCustomerDetails(custBean);
	}

	@Override
	public boolean isValidateCustName(String name)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		String pattFName="[A-Z]{1}[A-Za-z\\sA-Za-z]{2,20}";
		if(Pattern.matches(pattFName,name))
		{
			flag=true;
		}
		return flag;
		
	}

	@Override
	public boolean isValidateCustDOB(LocalDate date)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		String dob=String.valueOf(date);
		String pattern=("\\d{4}-\\d{2}-\\d{2}");
		if(Pattern.matches(pattern,dob))
			
		{
			flag=true;
		
		}
		return flag;
	}

	@Override
	public boolean isValidateCustMaritalStatus(String status)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(status.equalsIgnoreCase("Single") || status.equalsIgnoreCase("Married") || status.equalsIgnoreCase("Divorced"))
		{
			flag=true;
		}
		return flag;
	}

	@Override
	public boolean isValidateCustPhNo(String phNo)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		String pattDom="\\d{4}\\d{7}";
		String pattPhone="[7-9]{1}[0-9]{9}";
		if(Pattern.matches(pattDom,phNo)||Pattern.matches(pattPhone,phNo))
		{
			flag=true;		
		}
		return flag;
		
	}

	@Override
	public boolean isValidateCustMobNo(String mobileNo)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		String pattPhone="[7-9]{1}[0-9]{9}";
		if(Pattern.matches(pattPhone,mobileNo))
		{
			flag=true;
		}
		return flag;
	
	}

	@Override
	public boolean isValidateCustCountOfDependents(int count)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		String countOfDependents=String.valueOf(count);
		String pattern="[0-9]{1}";
		if(Pattern.matches(pattern, countOfDependents))
		{
			flag=true;
		}
		
		return flag;
	}

	@Override
	public boolean isValidateCustEmailId(String email)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		String pattern="^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		if(Pattern.matches(pattern,email))
		{
			flag=true;
		}
		
		return flag;
	}

	@Override
	public LoanApplication checkStatus(int loanAppId)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return dao.checkStatus(loanAppId);
	}
	

	@Override
	public boolean isValidateAnnualIncome(long annualFamilyIncome, double amount)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		if (annualFamilyIncome * 0.8 < amount) {
			flag = true;
		}
		return flag;
	}

	@Override
	public boolean validateDob(LocalDate dateOfBirth)
			throws LoanProgramException {

		LocalDate date = LocalDate.now();

		LocalDate dateOfBirth1 = LocalDate.of(dateOfBirth.getYear(),
				dateOfBirth.getMonth(), dateOfBirth.getDayOfMonth());

		Period diff = dateOfBirth1.until(date);

		

		if (diff.getYears() >= 23) {
			return true;
		} else {
			return false;
		}
	}
	
}
