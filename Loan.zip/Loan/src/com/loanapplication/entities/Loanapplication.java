package com.loanapplication.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.Date;


/**
 * The persistent class for the LOANAPPLICATION database table.
 * 
 */
@Component
@Entity
@NamedQuery(name="Loanapplication.findAll", query="SELECT l FROM Loanapplication l")
public class Loanapplication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="LOANAPPLICATION_APPLICATIONID_GENERATOR", sequenceName="APP_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="LOANAPPLICATION_APPLICATIONID_GENERATOR")
	@Column(name="APPLICATION_ID")
	private long applicationId;

	@Column(name="ADDR_OF_PROPERTY")
	private String addrOfProperty;

	@Column(name="AMT_OF_LOAN")
	private long amtOfLoan;

	@Column(name="ANNUAL_FAMILY_INCOME")
	private long annualFamilyIncome;

	@Temporal(TemporalType.DATE)
	@Column(name="APPLICATION_DATE")
	private Date applicationDate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_INTERVIEW")
	private Date dateOfInterview;

	private String prgmname;

	@Column(name="PROOFS_AVAILABLE")
	private String proofsAvailable;

	private String status;

	//bi-directional many-to-one association to CustomerDetail
	@ManyToOne
	@JoinColumn(name="CUSTOMER_ID")
	private CustomerDetail customerDetail;

	//bi-directional many-to-one association to Loanprogramsoffered
	@ManyToOne
	@JoinColumn(name="PRGMID")
	private Loanprogramsoffered loanprogramsoffered;

	public Loanapplication() {
	}

	public long getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public String getAddrOfProperty() {
		return this.addrOfProperty;
	}

	public void setAddrOfProperty(String addrOfProperty) {
		this.addrOfProperty = addrOfProperty;
	}

	public long getAmtOfLoan() {
		return this.amtOfLoan;
	}

	public void setAmtOfLoan(long amtOfLoan) {
		this.amtOfLoan = amtOfLoan;
	}

	public long getAnnualFamilyIncome() {
		return this.annualFamilyIncome;
	}

	public void setAnnualFamilyIncome(long annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}

	public Date getApplicationDate() {
		return this.applicationDate;
	}

	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	public Date getDateOfInterview() {
		return this.dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	public String getPrgmname() {
		return this.prgmname;
	}

	public void setPrgmname(String prgmname) {
		this.prgmname = prgmname;
	}

	public String getProofsAvailable() {
		return this.proofsAvailable;
	}

	public void setProofsAvailable(String proofsAvailable) {
		this.proofsAvailable = proofsAvailable;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public CustomerDetail getCustomerDetail() {
		return this.customerDetail;
	}

	public void setCustomerDetail(CustomerDetail customerDetail) {
		this.customerDetail = customerDetail;
	}

	public Loanprogramsoffered getLoanprogramsoffered() {
		return this.loanprogramsoffered;
	}

	public void setLoanprogramsoffered(Loanprogramsoffered loanprogramsoffered) {
		this.loanprogramsoffered = loanprogramsoffered;
	}

}