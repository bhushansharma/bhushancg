package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Trainee;
import com.cg.bean.UserLogin;
import com.cg.exception.TraineeException;

import com.cg.service.TraineeService;

import sun.misc.Contended;

@Controller
public class MyController {

	@Autowired
	UserLogin userBean;
	
	@Autowired
	TraineeService service;

	
	@Autowired
	Trainee traineeBean = new Trainee();
	
	@RequestMapping(value="/login")
	public String loginUser(Model model)
	{
		model.addAttribute("userBean", userBean);
		
		return "login";
	}
	
	@RequestMapping(value="/traineeprg")
	public String showTraineePrg(@ModelAttribute("userBean")@Valid UserLogin userBean,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			model.addAttribute("userBean",userBean);
			return "login";
		}
		else
			return "traineeprglist";
		/*System.out.println("User Name "+userBean.getUserName());
		if(userBean.getPass().equals("admin")&&userBean.getUserName().equals("admin"))
		{
			return "traineeprglist";
		}
		else
		{
			model.addAttribute("msg", "Incorrect Usrname or Password");
			return "login";
		}*/
	}
	
	@RequestMapping(value="/addtrainee")
	public String addTrainee(Model model)
	{
		model.addAttribute("traineeBean", traineeBean);
		return "addtrainee";
	}
	
	@RequestMapping(value="/newtrainee")
	public String insertTrainee(Trainee traineeBean,Model model)
	{
		try {
			service.insertTrainee(traineeBean);
		} catch (TraineeException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		return "traineeprglist";
	}
	@RequestMapping(value="/fetchdelete")
	public String fetchDeletePage()
	{
		return "deletetrainee";
	}
	
	@RequestMapping(value="/deletetrainee")
	public String deleteTrainee(@RequestParam("traineeId")int traineeId,Trainee traineeBean,Model model)
	{
		try {
			Trainee deleteBean=service.fetchTraincee(traineeId);
			
			model.addAttribute("deleteBean", deleteBean);
			return "deletetrainee";
			
		} catch (TraineeException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
	}
	
	@RequestMapping(value="/deletepage")
	public String deleteRecord(@RequestParam("id") int id,Model model)
	{
		System.out.println("in delete Record");
		//System.out.println(bean.getTraineeId());
		System.out.println(id);
		try {
			if(service.deleteTrainee(id))
			{
				System.out.println("Record Deleted ");
			}
			else
				throw new TraineeException("Record Cannot be Deleted "+id);
		} catch (TraineeException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		return "traineeprglist";
	}
	
	@RequestMapping("/modifytrainee")
	public String modifyPage(Model model)
	{
		model.addAttribute("traineeBean", traineeBean);
		return "modifyfetch";
	}
	
	@RequestMapping("/modifyrecord")
	public String modifyRecord(Trainee traineeBean,Model model)
	{
		try {
			System.out.println("in ModifyRecord "+traineeBean.getTraineeId());
			Trainee modfyBean = service.fetchTraincee(traineeBean.getTraineeId());
//			System.out.println("MOdify Bean"+modfyBean.getTraineeName());
			if(modfyBean==null)
			{
				throw new TraineeException("Record Not Found "+traineeBean.getTraineeId());
			}
			else
			{
				model.addAttribute("traineeBean",traineeBean);
				model.addAttribute("modifyBean", modfyBean);
				return "modifyfetch";
			}
		} catch (TraineeException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
	}
	
	@RequestMapping("/modifytable")
	public String modifyTable(Trainee modifyBean) throws TraineeException
	{
		if(service.modifyTrainee(modifyBean))
		{
			return "traineeprglist";
		}
		else
			return "error";
		
	}
	
}
