package com.loanprocessing.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoanApprovalDaoTest {

	@Test
	public void testLoanApprovalDAOImpl() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsValidLad() {
		fail("Not yet implemented");
	}

	@Test
	public void testApprovedLoans() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLoanApplication() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewLoanApplicationLAD() {
		fail("Not yet implemented");
	}

	@Test
	public void testRejectLoans() {
		fail("Not yet implemented");
	}

}
