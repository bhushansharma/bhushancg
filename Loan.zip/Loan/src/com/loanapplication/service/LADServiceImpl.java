package com.loanapplication.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loanapplication.dao.CustomerDAO;
import com.loanapplication.dao.LADDao;
import com.loanapplication.entities.CustomerDetail;
import com.loanapplication.entities.Loanapplication;
import com.loanapplication.exception.LoanException;

@Transactional
@Service
public class LADServiceImpl implements LADService {

	@Autowired
	LADDao ladDao;
	
	public void setDao(LADDao dao)
	{
		this.ladDao=dao;
	}
	
	@Override
	public ArrayList<CustomerDetail> getCustomerDetails(String loanDate)
			throws LoanException {
		// TODO Auto-generated method stub
		return ladDao.getCustomerDetails(loanDate);
	}
	@Override
	public Loanapplication getLoanApplication(long custid)
			throws LoanException {
		// TODO Auto-generated method stub
		return ladDao.getLoanApplication(custid);
	}
	@Override
	public boolean approveLoan(long id) throws LoanException {
		// TODO Auto-generated method stub
		return ladDao.approveLoan(id);
	}

	

}
