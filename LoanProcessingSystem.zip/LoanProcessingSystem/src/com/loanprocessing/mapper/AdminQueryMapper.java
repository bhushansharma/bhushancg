package com.loanprocessing.mapper;

public interface AdminQueryMapper {

	public static final String getLoanPrgs = "SELECT * FROM loanprogramsoffered";

	public static final String validAdmin = "SELECT * FROM loanuser WHERE role='admin'";

	public static final String addLoanPrg = "INSERT INTO loanprogramsoffered VALUES(?,?,?,?,?,?,?,?,?)";

	public static final String deleteLoanProg = "DELETE FROM loanprogramsoffered WHERE prgmId=?";

	public static final String viewLoanApp = "select loan.application_Id,loan.application_date,loan.loan_progrm,"
			+ "loan.amt_of_loan,loan.addr_of_property,loan.annual_family_income,loan.proofs_available,loan.guarantee_cover,"
			+ "loan.market_value_of_GC,loan.Status,loan.date_of_interview,cust.customer_name "
			+ "FROM loanapplication loan,customer_details cust "
			+ "WHERE (loan.application_id=cust.application_id) AND (application_date like ?)";

	public static final String updateROI="UPDATE loanprogramsoffered set ROI=? WHERE prgmId=?";
	
	public static final String updateMinAmt="UPDATE loanprogramsoffered set min_loan_amt=? WHERE prgmId=?";
	
	public static final String updateMaxAmt="UPDATE loanprogramsoffered set max_loan_amt=? WHERE prgmId=?";


}
