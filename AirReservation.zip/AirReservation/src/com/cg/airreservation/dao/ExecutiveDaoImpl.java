package com.cg.airreservation.dao;

/**
 * <AirLine Reservation System>
 * class for implementing IDaoExecutive interface methods for admin and executive operations
 */

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.airreservation.dbutil.DBUtil;
import com.cg.airreservation.dbutil.QueryMapper;
import com.cg.airreservation.dto.AirportBean;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.logger.AirLineLogger;



public class ExecutiveDaoImpl implements IExecutiveDao{

	// creating logger object
		Logger logger = AirLineLogger.getLoggerInstance();

	//declaring variable 
	Connection con=null;
	
	
	/*
	 * defining method, used to get information about seat availability based
	 * on flight number by executive
	 */
	@Override
	public FlightBean flightOccupancyDetails(String flight_num) throws AirlineException {
		// TODO Auto-generated method stub
		FlightBean bean = null;
		con = DBUtil.getInstance().getConnection();

		try
		{
			//String sql = "SELECT * FROM FLIGHT_INFO WHERE FLIGHT_NUM=?";
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.flightOccupacyDetails);
			pstmt.setString(1,flight_num);
			ResultSet result = pstmt.executeQuery();
			if(result.next())
			{
				bean = new FlightBean();
				bean.setFlightNum(result.getString(1));
				bean.setAirlineName(result.getString(2));
				bean.setAirportZip(result.getString(3));
				bean.setSource(result.getString(4));
				bean.setDestination(result.getString(5));
				bean.setBusinessFare(result.getDouble(6));
				bean.setEconomyFare(result.getDouble(7));
				bean.setBusinessSeats(result.getInt(8));
				bean.setEconomySeats(result.getInt(9));
				bean.setDeptDate(result.getDate(10).toLocalDate());
				bean.setArriveDate(result.getDate(11).toLocalDate());
				bean.setArriveTime(result.getString(12));
				bean.setDeptTime(result.getString(13));
				bean.setRemainingBusSeats(result.getInt(14));
				bean.setRemainingEcoSeats(result.getInt(15));
				logger.info("Flight Info is Obtained Successfully for Flight Number "+flight_num);
			}
			else
			{
				logger.info("Failed to Obtain Flight Info for Flight Number "+flight_num);
			}
			
		}
		
		catch(Exception e)
		{
			logger.error("Exception Occured"+e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		
		return bean;
	}
	
	/*
	 * defining method, used to Add new flight information by admin
	 */
	@Override
	public boolean insertFlightInfo(FlightBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		con = DBUtil.getInstance().getConnection();

		boolean flag = false;
		//String insertFInfo = "INSERT INTO FLIGHT_INFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.addFlightInfo);
			pstmt.setString(1, bean.getFlightNum());
			pstmt.setString(2, bean.getAirlineName());
			pstmt.setInt(3, Integer.parseInt(bean.getAirportZip()));
			
			
			pstmt.setString(4, bean.getSource());
			pstmt.setString(5, bean.getDestination());
			pstmt.setDouble(6, bean.getBusinessFare());
			pstmt.setDouble(7, bean.getEconomyFare());
			pstmt.setInt(8, bean.getBusinessSeats());
			pstmt.setInt(9, bean.getEconomySeats());
			
			pstmt.setDate(10, Date.valueOf(bean.getDeptDate()));
			pstmt.setDate(11, Date.valueOf(bean.getArriveDate()));
			pstmt.setString(12, bean.getArriveTime());
			pstmt.setString(13, bean.getDeptTime());
			pstmt.setInt(14, bean.getBusinessSeats());
			pstmt.setInt(15, bean.getEconomySeats());
			
			int row = pstmt.executeUpdate();
			if (row != 0) {
				flag = true;
				logger.info("Flight Info of Flight Number "+bean.getFlightNum()+" is Inserted Successfully.");
			}
			else
			{
				logger.info("Failed to Insert Flight Info of Flight Number "+bean.getFlightNum());
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Exception Occured"+e.getMessage());
			throw new AirlineException("Exception while inserting flight info");

		}
		return flag;
	}
	
	
	/*
	 * defining method, used to fetch all flight information based on date of
	 * journey entered by admin
	 */
	@Override
	public ArrayList<FlightBean> generateFlightList(LocalDate dateJourney)
			throws AirlineException {
		// TODO Auto-generated method stub
		con = DBUtil.getInstance().getConnection();

		ArrayList<FlightBean> flightList = new ArrayList<FlightBean>();
		try
		{
			//String sql = "SELECT * FROM FLIGHT_INFO WHERE SCH_DEPRT_TIME like ?";
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.generateFlightList);
			Date date=Date.valueOf(dateJourney);
			//pstmt.setString(1,"%"+Date.valueOf(dateJourney)+"%");
			//pstmt.setString(1, "%"+date+"%");
			pstmt.setDate(1, date);
			ResultSet result = pstmt.executeQuery();
			while(result.next())
			{
				FlightBean flightBean = new FlightBean();
				flightBean.setFlightNum(result.getString(1));
				flightBean.setAirlineName(result.getString(2));
				flightBean.setAirportZip(result.getString(3));
				flightBean.setSource(result.getString(4));
				flightBean.setDestination(result.getString(5));
				flightBean.setBusinessFare(result.getInt(6));
				flightBean.setEconomyFare(result.getInt(7));
				flightBean.setBusinessSeats(result.getInt(8));
				flightBean.setEconomySeats(result.getInt(9));
				flightBean.setDeptDate(result.getDate(10).toLocalDate());
				flightBean.setArriveDate(result.getDate(11).toLocalDate());
				flightBean.setArriveTime(result.getString(12));
				flightBean.setDeptTime(result.getString(13));
				flightList.add(flightBean);	
				
			}
			if(flightList.size()!=0)
			{
				logger.info("Flight List Generated Successfully for Journey Date "+dateJourney);
			}
			else
			{
				logger.info("Failed to Generate Flight List for Journey Date "+dateJourney);
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occured"+e.getMessage());
			throw new AirlineException(e.getMessage());
			
		}
		return flightList;
	}

	/*
	 * defining method, used to fetch all the passengers list based on flight
	 * number by admin
	 */
	@Override
	public ArrayList<BookingBean> fetchPassengerList(String flightNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		con = DBUtil.getInstance().getConnection();

		ArrayList<BookingBean> passengerList = new ArrayList<BookingBean>();
		
		//String sql = "SELECT * FROM BOOKING_INFO WHERE FLIGHT_NUM=?";
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(QueryMapper.fetchPassengerList);
			pstmt.setString(1, flightNum);
			ResultSet result = pstmt.executeQuery();
			while(result.next())
			{
				BookingBean bean = new BookingBean();
				bean.setPnr(result.getInt(1));
				bean.setFlightNo(result.getString(2));
				bean.setCustId(Integer.parseInt(result.getString(3)));
				bean.setCustMobile(result.getString(4));
				bean.setCustMail(result.getString(5));
				bean.setPassengerNum(result.getInt(6));
				bean.setClassType(result.getString(7));
				bean.setTotalFare(result.getDouble(8));
				bean.setSource(result.getString(9));
				bean.setDest(result.getString(10));
				bean.setDateOfJourney(result.getDate(11).toLocalDate());
				bean.setBookTime(result.getTime(12).toLocalTime());
				passengerList.add(bean);
			}
			if(passengerList.size()!=0)
			{
				logger.info("Passenger List of Flight Number "+flightNum+" is Fetched Successfully.");
			}
			else
			{
				logger.info("Filed to Fetch Passenger List of Flight Number "+flightNum);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		return passengerList;
	}

	@Override
	public ArrayList<AirportBean> fetchAirportList() throws AirlineException {
		// TODO Auto-generated method stub
		ArrayList<AirportBean> zipList=new ArrayList<AirportBean>();
		con = DBUtil.getInstance().getConnection();

		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(QueryMapper.fetchAirportList);
			ResultSet result=pstmt.executeQuery();
			
			while(result.next())
			{
				AirportBean airBean=new AirportBean();
				airBean.setAirportZip(result.getString(1));
				airBean.setAirportName(result.getString(2));
				airBean.setAirportAbbv(result.getString(3));
				airBean.setAirportLocation(result.getString(4));
				zipList.add(airBean);
			}
			if(zipList.size()!=0)
			{
				logger.info("Airport List is Fetched Successfully.");
			}
			else
			{
				logger.info("failed to fetch airport lsit.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());
			throw new AirlineException(e.getMessage());
			
		}
		
		
		return zipList;
	}
	

}
