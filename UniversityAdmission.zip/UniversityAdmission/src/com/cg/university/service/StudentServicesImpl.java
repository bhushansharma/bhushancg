package com.cg.university.service;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.university.dao.StudentDao;
import com.cg.university.entities.Application;
import com.cg.university.entities.ProgramsOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;


@Transactional
@Service
public class StudentServicesImpl implements StudentServices {

	@Autowired
	StudentDao dao;
	
	@Override
	public void insertApplication(Application bean) throws UniversityException {
		// TODO Auto-generated method stub
	dao.insertApplication(bean);
	}

	@Override
	public ArrayList<ProgramsScheduled> getScheduledPrograms()
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getScheduledPrograms();
	}

	@Override
	public ArrayList<ProgramsOffered> getAllPrograms()
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getAllPrograms();
	}

	@Override
	public Application getApplicationStatus(int applicationId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getApplicationStatus(applicationId);
	}

	@Override
	public LocalDate getInterviewDate(int applicationId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateName(String studentName) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateId(int applicationId) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateDob(LocalDate dateOfBirth)
			throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateQualification(String qualification)
			throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateMarks(int marks) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateEmail(String emailId) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateGoals(String goals) throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateScheduledProgramId(String scheduledProgramId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return false;
	}

}
