package com.cg.traineespring.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineespring.bean.Trainee;
import com.cg.traineespring.dao.TraineeDao;
import com.cg.traineespring.exception.TraineException;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao dao;
	
	@Override
	public void insertTrainee(Trainee bean) throws TraineException{
		// TODO Auto-generated method stub
		dao.insertTrainee(bean);
	}

	@Override
	public Trainee removeTrainee(int id) throws TraineException{
		// TODO Auto-generated method stub
		return dao.removeTrainee(id);
	}

	@Override
	public Trainee getTrainee(int id) throws TraineException{
		// TODO Auto-generated method stub
		return dao.getTrainee(id);
	}

	@Override
	public Trainee modifyTrainee(Trainee bean) throws TraineException{
		// TODO Auto-generated method stub
		return dao.modifyTrainee(bean);
	}

	@Override
	public ArrayList<Trainee> getAllTrainee() throws TraineException{
		// TODO Auto-generated method stub
		return dao.getAllTrainee();
	}

}
