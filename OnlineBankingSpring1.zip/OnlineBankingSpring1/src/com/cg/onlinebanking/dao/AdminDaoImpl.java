package com.cg.onlinebanking.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;










import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.Admins1;
import com.cg.onlinebanking.entities.Customer1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.entities.Users1;
import com.cg.onlinebanking.exception.BankException;
import com.cg.onlinebanking.logger.BankLogger;

import org.apache.log4j.Logger;


@Repository
public class AdminDaoImpl implements AdminDao {


	@PersistenceContext
	private EntityManager entityManager;
	
	
	Logger logger = BankLogger.getLoggerInstance();
	

	
	/* 
	 * Description: Validates the admin credentials
	 */
	@Override
	public boolean validateAdmin(String userid, String pass)
			throws BankException 
	{
		
		TypedQuery<Admins1> query = entityManager.createQuery("Select admin FROM Admins1 admin WHERE admin.userId=:uid and admin.password=:pass",Admins1.class);
		query.setParameter("uid", userid);
		query.setParameter("pass", pass);
		logger.info("Admin Login"+this.getClass());
		int queryCount = query.getResultList().size();
		if(queryCount==0)//return false;
			throw new BankException("Invalid Credentials");	
		return true;
	}

	/* 
	 * Description: Displays the transactions of the current date
	 */
	@Override
	public List<Transactions1> showDailyData() throws BankException {
		
		ArrayList<Transactions1> dailyTransactionList=new ArrayList<Transactions1>();
		String qstr="SELECT transaction FROM Transactions1 transaction WHERE"
				+ " EXTRACT(day from dtOfTransaction)=EXTRACT(day from sysdate)"
				+"AND EXTRACT(month from dtOfTransaction)=EXTRACT(month from sysdate)"
				+"AND EXTRACT(year from dtOfTransaction)=EXTRACT(year from sysdate)";
		TypedQuery<Transactions1> query=entityManager.createQuery(qstr, Transactions1.class);
		dailyTransactionList = (ArrayList<Transactions1>) query.getResultList();
		
		return dailyTransactionList;
		
	}

	/* 
	 * Description: Displays the transactions of specified month provided by the admin
	 */
	@Override
	public List<Transactions1> showMonthlyData(int month) throws BankException {
		ArrayList<Transactions1> monthlyTransactionsList = new ArrayList<Transactions1>();
		String qstr="SELECT transaction FROM Transactions1 transaction WHERE "
				+ "EXTRACT(month from dtOfTransaction)=:month AND "
				+ "EXTRACT(year from dtOfTransaction)=EXTRACT(year from sysdate)";
		TypedQuery<Transactions1> query=entityManager.createQuery(qstr, Transactions1.class);
		query.setParameter("month", month);
		monthlyTransactionsList=(ArrayList<Transactions1>) query.getResultList();
		if(monthlyTransactionsList.size()==0)
		{
			
			throw new BankException("No Transactions found for month "+month);
		}
		return monthlyTransactionsList;
	}

	

	/* 
	 * Description: Registers the new account holder
	 */
	@Override
	public long addAccountHolderMaster(AccountMaster1 account)
			throws BankException {
		// TODO Auto-generated method stub
		entityManager.persist(account);
		
		entityManager.flush();
		
		return account.getAccountId();
	}
	@Override
	public void addAccountHolderUser(Users1 user)throws BankException{
		entityManager.persist(user);
		entityManager.flush();
	}
	
	@Override
	public void addAccountHolderCustomer(Customer1 customer) throws BankException {
		entityManager.persist(customer);
		entityManager.flush();
	}


	/* 
	 * Description: Provides the Service details of all the account holder
	 */
	@Override
	public List<ServiceTracker1> getServiceDetails() throws BankException {
		TypedQuery<ServiceTracker1> query = entityManager.createQuery("SELECT request FROM ServiceTracker1 request", ServiceTracker1.class);
		ArrayList<ServiceTracker1> list = (ArrayList<ServiceTracker1>) query.getResultList();
		if(list.size()==0)
		{
			throw new BankException("No Request Found");
		}
		return list;
	}

	
	/* 
	 * Description: Updates the status for the specified account holder
	 */
	@Override
	public boolean updateStatus(long serviceId, String status)
			throws BankException {
		ServiceTracker1 request=entityManager.find(ServiceTracker1.class, serviceId);
		request.setServiceStatus(status);
		entityManager.merge(request);
		entityManager.flush();
		return false;
	}

	@Override
	public long addAccountHolder(Users1 user, Customer1 customer,
			AccountMaster1 account) throws BankException {
		// TODO Auto-generated method stub
		addAccountHolderMaster(account);
		customer.setAccountMaster1(account);
		addAccountHolderCustomer(customer);
		user.setAccountMaster1(account);
		addAccountHolderUser(user);
		return user.getUserId();
	}
	
}
