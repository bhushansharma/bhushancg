package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;


/**
 * The persistent class for the PAYEE1 database table.
 * 
 */
@Component
@Entity
@NamedQuery(name="Payee1.findAll", query="SELECT p FROM Payee1 p")
public class Payee1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PAYEE1_PAYEEID_GENERATOR", sequenceName="PAYEE_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PAYEE1_PAYEEID_GENERATOR")
	@Column(name="PAYEE_ID")
	private long payeeId;

	@Column(name="NICK_NAME")
	private String nickName;

	//bi-directional many-to-one association to AccountMaster1
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private AccountMaster1 accountMaster11;

	//bi-directional many-to-one association to AccountMaster1
	@ManyToOne
	@JoinColumn(name="PAYEE_ACCOUNT_ID")
	private AccountMaster1 accountMaster12;

	public Payee1() {
	}

	public long getPayeeId() {
		return this.payeeId;
	}

	public void setPayeeId(long payeeId) {
		this.payeeId = payeeId;
	}

	public String getNickName() {
		return this.nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public AccountMaster1 getAccountMaster11() {
		return this.accountMaster11;
	}

	public void setAccountMaster11(AccountMaster1 accountMaster11) {
		this.accountMaster11 = accountMaster11;
	}

	public AccountMaster1 getAccountMaster12() {
		return this.accountMaster12;
	}

	public void setAccountMaster12(AccountMaster1 accountMaster12) {
		this.accountMaster12 = accountMaster12;
	}


	
	

}