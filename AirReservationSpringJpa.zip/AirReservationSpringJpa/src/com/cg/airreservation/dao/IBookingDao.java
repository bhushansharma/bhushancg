package com.cg.airreservation.dao;

import java.util.ArrayList;

import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.exception.AirlineException;

public interface IBookingDao {

public boolean confirmBooking(Bookinginfo bookingInfo) throws AirlineException;
	
	public boolean updateBooking(Bookinginfo bookingInfo) throws AirlineException;
	
	public boolean cancelBooking(long id) throws AirlineException;
	
	public Bookinginfo fetchBookingDetails(long id) throws AirlineException;
	
	public ArrayList<Bookinginfo> getBookingDetails(String email) throws AirlineException;
	
	public ArrayList<Bookinginfo> getAllBookingDetails(String email) throws AirlineException;
}
