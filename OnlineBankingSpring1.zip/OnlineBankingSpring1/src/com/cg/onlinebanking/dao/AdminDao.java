package com.cg.onlinebanking.dao;

import java.util.List;
import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.Customer1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.entities.Users1;
import com.cg.onlinebanking.exception.BankException;

public interface AdminDao {

	public boolean validateAdmin(String userid, String pass)
			throws BankException;

	public List<Transactions1> showDailyData() throws BankException;

	public List<Transactions1> showMonthlyData(int month) throws BankException;

	public long addAccountHolderMaster(AccountMaster1 acc) throws BankException;

	public void addAccountHolderUser(Users1 user) throws BankException;

	public void addAccountHolderCustomer(Customer1 customer)
			throws BankException;

	public List<ServiceTracker1> getServiceDetails() throws BankException;

	public boolean updateStatus(long serviceId, String status)
			throws BankException;

	public long addAccountHolder(Users1 user, Customer1 customer,
			AccountMaster1 account) throws BankException;
}
