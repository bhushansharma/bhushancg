package com.loanprocessing.bean;

public class ApprovedLoans {

	private String cust_name;
	private double loan_granted;
	private double monthly_installmnt;
	private int period;
	private double dwnpaymnt=10000;
	private int rate;
	private double total_amount;
	
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public double getLoan_granted() {
		return loan_granted;
	}
	public void setLoan_granted(double loan_granted) {
		this.loan_granted = loan_granted;
	}
	public double getMonthly_installmnt() {
		return monthly_installmnt;
	}
	public void setMonthly_installmnt(double monthly_installmnt) {
		this.monthly_installmnt = monthly_installmnt;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public double getDwnpaymnt() {
		return dwnpaymnt;
	}
	public void setDwnpaymnt(double dwnpaymnt) {
		this.dwnpaymnt = dwnpaymnt;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public double getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(double total_amount) {
		this.total_amount = total_amount;
	}
	
	
}
