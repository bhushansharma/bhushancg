package com.loanprocessing.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class AdminDaoTest {

	@Test
	public void testAdminDAOImpl() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLoanProgramsAdmin() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsValidAdmin() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddLoanProgram() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteLoanProgram() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewLoanApplication() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateROI() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateMinAmt() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateMaxAmt() {
		fail("Not yet implemented");
	}

}
