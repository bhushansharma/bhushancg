package com.cg.airreservation.dbutil;

/**
 * <AirLine Reservation System>
 *	this class contain all the required information to establish connection with database
 */
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

import com.cg.airreservation.exception.AirlineException;

public class DBUtil {

	private static Connection con = null;
	private static DBUtil instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;

	// static Properties prop = new Properties();

	private DBUtil() throws AirlineException {
		try {
			props = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {
			throw new AirlineException(
					" Could not read the database details from properties file ");
		} catch (SQLException e) {
			throw new AirlineException(e.getMessage());
		}

	}

	public static DBUtil getInstance() throws AirlineException {
		synchronized (DBUtil.class) {
			if (instance == null) {
				instance = new DBUtil();
			}
		}
		return instance;
	}

	public Connection getConnection() throws AirlineException {
		try {

			con = dataSource.getConnection();

		} catch (SQLException e) {
			throw new AirlineException(" Database connection problem");
		}
		return con;
	}

	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}

	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("url");
				String username = props.getProperty("user");
				String password = props.getProperty("pass");

				dataSource = new OracleDataSource();

				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}
	

}
