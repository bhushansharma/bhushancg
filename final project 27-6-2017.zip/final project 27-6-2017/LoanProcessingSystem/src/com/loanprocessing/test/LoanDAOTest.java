package com.loanprocessing.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoanDAOTest {

	@Test
	public void testLoanDAOImpl() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLoanProgram() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLoanDescription() {
		fail("Not yet implemented");
	}

	@Test
	public void testInsertLoanApplictaion() {
		fail("Not yet implemented");
	}

	@Test
	public void testInsertCustomerDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testCheckStatus() {
		fail("Not yet implemented");
	}

}
