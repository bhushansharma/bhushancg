package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

import com.sun.istack.internal.NotNull;


/**
 * The persistent class for the CUSTOMER1 database table.
 * 
 */
@Component
@Entity
@NamedQuery(name="Customer1.findAll", query="SELECT c FROM Customer1 c")
public class Customer1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CUSTOMER1_CUSTOMERID_GENERATOR", sequenceName="CUSTOMER_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CUSTOMER1_CUSTOMERID_GENERATOR")
	@Column(name="CUSTOMER_ID")
	private long customerId;

	@Column(name="ACCOUNT_ID")
	private java.math.BigDecimal accountId;

	@NotNull
	@Pattern(regexp="[A-Za-z0-9'\\.\\-\\s\\,]{5,100}", message="Address should be Greater than 5 characters")
	private String address;

	@Pattern(regexp="([A-Z]{1}[a-zA-Z]*)[\\s]?([A-Z]{1}[a-zA-Z]*)?${2,20}", message="Enter correct Name.  It should start with Capital and maximum charracters will be 20")
	@NotNull
	@Column(name="CUSTOMER_NAME")
	private String customerName;

	@Email(message="Email should be in proper format")
	private String email;

	@Pattern(regexp="[7-9]{1}[0-9]{9}", message="Enter correct Mobile Number should start with 7-9 followed by 0-9 digits")
	@Column(name="MOBILE_NUM")
	private String mobileNum;

	@Pattern(regexp="[A-Z]{5}[0-9]{4}[A-Z]{1}", message="Please enter correct pancard details should be first 5 characters/ 4 digits/ 1 character. ALL CHARS IN CAPITAL ")
	private String pancard;

	//bi-directional one-to-one association to AccountMaster1
	@OneToOne(mappedBy="customer1")
	private AccountMaster1 accountMaster1;

	public Customer1() {
	}

	public long getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public java.math.BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(java.math.BigDecimal accountId) {
		this.accountId = accountId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNum() {
		return this.mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getPancard() {
		return this.pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public AccountMaster1 getAccountMaster1() {
		return this.accountMaster1;
	}

	public void setAccountMaster1(AccountMaster1 accountMaster1) {
		this.accountMaster1 = accountMaster1;
	}

}