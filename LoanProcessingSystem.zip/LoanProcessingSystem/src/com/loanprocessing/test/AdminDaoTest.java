package com.loanprocessing.test;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.bean.Users;
import com.loanprocessing.dao.AdminDAOImpl;
import com.loanprocessing.dao.AdminDao;
import com.loanprocessing.exception.LoanProgramException;
import com.loanprocessing.service.LoanAdminServiceImpl;

public class AdminDaoTest {
	
	LoanAdminServiceImpl service;
	AdminDao daoAdmin;

	@Before
	public void init()
	{
		service = new LoanAdminServiceImpl();
		daoAdmin = new AdminDAOImpl();
		service.setDao(daoAdmin);
	}
	

	@Test
	public void testGetLoanProgramsAdmin()throws LoanProgramException{
		
		assertNotNull(service.getLoanProgramsAdmin());
	}

	@Test
	public void testWrongGetLoanProgramsAdmin()throws LoanProgramException{
		
		assertNull(service.getLoanProgramsAdmin());
	}
	
	@Test
	public void testIsValidAdmin() throws LoanProgramException {
		Users userBean = new Users();
		
		userBean.setLoginId("admin");
		userBean.setPassword("admin");
		userBean.setRole("admin");
		
		assertEquals(true, service.isValidAdmin("admin","admin"));
	}
	
	@Test
	public void testWrongIsValidAdmin() throws LoanProgramException {
		Users userBean = new Users();
		
		userBean.setLoginId("abc");
		userBean.setPassword("abc");
		userBean.setRole("abc");
		
		assertEquals(true, service.isValidAdmin("abc","abc"));
	}

	@Test
	public void testAddLoanProgram() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		
		bean.setProgramId(105);
		bean.setProgramName("HomeConstruction");
		bean.setDescriptn("Loan For Home Construction");
		bean.setType("Construction");
		bean.setDuration(9);
		bean.setProof("Adhar Card,Pan Card,Pay Slip");
		bean.setMinAmount(150000);
		bean.setMaxAmount(700000);
		bean.setRate(12.75);
		
		assertEquals(true,service.addLoanProgram(bean));
		
	}

	@Test
	public void testDeleteLoanProgram() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(105);
		
		assertEquals(true,service.deleteLoanProgram(105));
	}
	
	@Test
	public void testWrongDeleteLoanProgram() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(107);
		
		assertEquals(true,service.deleteLoanProgram(107));
	}

	@Test
	public void testViewLoanApplication() throws LoanProgramException {
	
		assertNotNull(service.getLoanProgramsAdmin());
	}

	@Test
	public void testWrongViewLoanApplication() throws LoanProgramException {
	
		assertNull(service.getLoanProgramsAdmin());
	}
	
	@Test
	public void testUpdateROI() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(102);
		bean.setRate(10.5);
		assertEquals(true,service.updateROI(102, 12.75));
	}
	
	@Test
	public void testWrongUpdateROI() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(107);
		bean.setRate(12.75);
		assertEquals(true,service.updateROI(107, 13.75));
	}

	@Test
	public void testUpdateMinAmt() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(105);
		bean.setMinAmount(150000);
		assertEquals(true, service.updateMinAmt(105,200000));
	}

	@Test
	public void testWrongUpdateMinAmt() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(107);
		bean.setMinAmount(200000);
		assertEquals(true, service.updateMinAmt(107,300000));
	}
	
	@Test
	public void testUpdateMaxAmt() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(105);
		bean.setMaxAmount(700000);
		assertEquals(true, service.updateMaxAmt(105, 800000));
	}
	
	@Test
	public void testWrongUpdateMaxAmt() throws LoanProgramException {
		LoanPrograms bean = new LoanPrograms();
		bean.setProgramId(107);
		bean.setMaxAmount(500000);
		assertEquals(true, service.updateMaxAmt(107, 600000));
	}

}
