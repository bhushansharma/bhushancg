package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;


/**
 * The persistent class for the FUND_TRANSFER1 database table.
 * 
 */
@Component
@Entity
@Table(name="FUND_TRANSFER1")
@NamedQuery(name="FundTransfer1.findAll", query="SELECT f FROM FundTransfer1 f")
public class FundTransfer1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="FUND_TRANSFER1_FUNDTRANSFERID_GENERATOR", sequenceName="FUND_TRANSFER_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="FUND_TRANSFER1_FUNDTRANSFERID_GENERATOR")
	@Column(name="FUND_TRANSFER_ID")
	private long fundTransferId;

	@Column(name="DT_OF_TRANSFER")
	private Timestamp dtOfTransfer;

	@Column(name="TRANSFER_AMOUNT")
	private double transferAmount;

	//bi-directional many-to-one association to AccountMaster1
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private AccountMaster1 accountMaster11;

	//bi-directional many-to-one association to AccountMaster1
	@ManyToOne
	@JoinColumn(name="PAYEE_ACCOUNT_ID")
	private AccountMaster1 accountMaster12;

	public FundTransfer1() {
	}

	public long getFundTransferId() {
		return this.fundTransferId;
	}

	public void setFundTransferId(long fundTransferId) {
		this.fundTransferId = fundTransferId;
	}

	public Timestamp getDtOfTransfer() {
		return this.dtOfTransfer;
	}

	public void setDtOfTransfer(Timestamp dtOfTransfer) {
		this.dtOfTransfer = dtOfTransfer;
	}

	public double getTransferAmount() {
		return this.transferAmount;
	}

	public void setTransferAmount(double transferAmount) {
		this.transferAmount = transferAmount;
	}

	public AccountMaster1 getAccountMaster11() {
		return this.accountMaster11;
	}

	public void setAccountMaster11(AccountMaster1 accountMaster11) {
		this.accountMaster11 = accountMaster11;
	}

	public AccountMaster1 getAccountMaster12() {
		return this.accountMaster12;
	}

	public void setAccountMaster12(AccountMaster1 accountMaster12) {
		this.accountMaster12 = accountMaster12;
	}

}