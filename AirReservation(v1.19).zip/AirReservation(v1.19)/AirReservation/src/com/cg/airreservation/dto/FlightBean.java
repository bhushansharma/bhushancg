package com.cg.airreservation.dto;

/**
 * <AirLine Reservation System>
 * All the information after Adding New Flight will be store using this class properties.
 */
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;

//Class Name FlightBean for table FLIGHT_INFO
public class FlightBean {

	// Declaring Properties
	private String flightNum;
	private String airlineName;
	private String airportZip;
	private String source;
	private String destination;
	private double businessFare;
	private double economyFare;
	private int businessSeats;
	private int economySeats;
	private LocalDate deptDate;
	private LocalDate arriveDate;
	private String deptTime; // temp then change to below variable declared
	private String arriveTime;
	private int remainingEcoSeats;
	private int remainingBusSeats;

	// private LocalTime deptTime;
	// private LocalTime arriveTime;

	// Default constructor
	public FlightBean() {
		super();
	}

	// parameterized Constructor
	public FlightBean(String flightNum, String airlineName, String source,
			String destination, LocalDate deptDate, LocalDate arriveDate,
			String deptTime, String arriveTime) {
		super();
		this.flightNum = flightNum;
		this.airlineName = airlineName;
		this.source = source;
		this.destination = destination;
		this.deptDate = deptDate;
		this.arriveDate = arriveDate;

		this.deptTime = deptTime;
		this.arriveTime = arriveTime;
	}

	// Getter and Setter for above properties
	public int getRemainingEcoSeats() {
		return remainingEcoSeats;
	}

	public void setRemainingEcoSeats(int remainingEcoSeats) {
		this.remainingEcoSeats = remainingEcoSeats;
	}

	public int getRemainingBusSeats() {
		return remainingBusSeats;
	}

	public void setRemainingBusSeats(int remainingBusSeats) {
		this.remainingBusSeats = remainingBusSeats;
	}

	public String getFlightNum() {
		return flightNum;
	}

	public void setFlightNum(String flightNum) {
		this.flightNum = flightNum;
	}

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public LocalDate getDeptDate() {
		return deptDate;
	}

	public void setDeptDate(LocalDate deptDate) {
		this.deptDate = deptDate;
	}

	public LocalDate getArriveDate() {
		return arriveDate;
	}

	public void setArriveDate(LocalDate arriveDate) {
		this.arriveDate = arriveDate;
	}

	public String getDeptTime() {
		return deptTime;
	}

	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}

	public String getArriveTime() {
		return arriveTime;
	}

	public void setArriveTime(String arriveTime) {
		this.arriveTime = arriveTime;
	}

	

	
	public String getAirportZip() {
		return airportZip;
	}

	public void setAirportZip(String airportZip) {
		this.airportZip = airportZip;
	}

	public double getBusinessFare() {
		return businessFare;
	}

	public void setBusinessFare(double businessFare) {
		this.businessFare = businessFare;
	}

	public double getEconomyFare() {
		return economyFare;
	}

	public void setEconomyFare(double economyFare) {
		this.economyFare = economyFare;
	}

	public int getBusinessSeats() {
		return businessSeats;
	}

	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}

	public int getEconomySeats() {
		return economySeats;
	}

	public void setEconomySeats(int economySeats) {
		this.economySeats = economySeats;
	}

	// ToString Method for above properties
	@Override
	public String toString() {
		return "FlightBean [flightNum=" + flightNum + ", airlineName="
				+ airlineName + ", source=" + source + ", destination="
				+ destination + ", deptDate=" + deptDate + ", arriveDate="
				+ arriveDate + ", deptTime=" + deptTime + ", arriveTime="
				+ arriveTime + "]";
	}
}
