package com.loanprocessing.logger;

import java.io.IOException;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class MyLogger {

	static Logger logger = Logger.getLogger(MyLogger.class);
	static {
		SimpleLayout layout = new SimpleLayout();
		Appender appender = null;
		try {
		 appender = new FileAppender(layout, "log.txt");
		} catch (IOException e) {

			e.printStackTrace();
		}
		logger.addAppender(appender);
	}

	public static Logger getLoggerInstance() {
		return logger;

	}

}
