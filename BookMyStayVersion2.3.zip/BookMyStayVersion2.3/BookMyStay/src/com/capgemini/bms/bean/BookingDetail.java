package com.capgemini.bms.bean;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.sql.Date;

/**
 * The persistent class for the BOOKING_DETAILS database table.
 * 
 */
@Component
@Entity
@Table(name="BOOKING_DETAILS")
@NamedQuery(name="BookingDetail.findAll", query="SELECT b FROM BookingDetail b")
public class BookingDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="BOOKING_DETAILS_BOOKINGID_GENERATOR", sequenceName="BOOKING_SEQUENCE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BOOKING_DETAILS_BOOKINGID_GENERATOR")
	@Column(name="BOOKING_ID")
	private long bookingId;

	@Column(name="BOOKED_FROM")
	private Date bookedFrom;

	@NotNull(message="Please select date")
	@Column(name="BOOKED_TO")
	private Date bookedTo;
	
	private BigDecimal noOfAdlts;
	
	private BigDecimal noOfChildren;

	@Column(name="TOTAL_AMOUNT")
	private long totalAmount;

	//bi-directional many-to-one association to RoomDetail
	@ManyToOne
	@JoinColumn(name="ROOM_ID")
	private RoomDetail roomDetail;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private User user;

	public BookingDetail() {
	}

	public long getBookingId() {
		return this.bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	public Date getBookedFrom() {
		return this.bookedFrom;
	}

	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public Date getBookedTo() {
		return this.bookedTo;
	}

	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}

	public BigDecimal getNoOfAdlts() {
		return this.noOfAdlts;
	}

	public void setNoOfAdlts(BigDecimal noOfAdlts) {
		this.noOfAdlts = noOfAdlts;
	}

	public BigDecimal getNoOfChildren() {
		return this.noOfChildren;
	}

	public void setNoOfChildren(BigDecimal noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public long getTotalAmount() {
		return this.totalAmount;
	}

	public void setTotalAmount(long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public RoomDetail getRoomDetail() {
		return this.roomDetail;
	}

	public void setRoomDetail(RoomDetail roomDetail) {
		this.roomDetail = roomDetail;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}