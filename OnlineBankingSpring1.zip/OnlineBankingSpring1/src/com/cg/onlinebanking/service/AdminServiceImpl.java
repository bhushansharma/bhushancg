package com.cg.onlinebanking.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinebanking.dao.AdminDao;
import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.Customer1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.entities.Users1;
import com.cg.onlinebanking.exception.BankException;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	AdminDao adminDao;
	
	@Override
	public boolean validateAdmin(String userid, String pass)
			throws BankException {
		return adminDao.validateAdmin(userid, pass);
	}

	@Override
	public List<Transactions1> showDailyData() throws BankException {
		return adminDao.showDailyData();
	}

	@Override
	public List<Transactions1> showMonthlyData(int month) throws BankException {
		return adminDao.showMonthlyData(month);
	}

	@Override
	public long addAccountHolderMaster(AccountMaster1 acc) throws BankException {
		
		return adminDao.addAccountHolderMaster(acc);
	}

	@Override
	public void addAccountHolderUser(Users1 user) throws BankException {
		adminDao.addAccountHolderUser(user);
	}

	@Override
	public void addAccountHolderCustomer(Customer1 customer)
			throws BankException {
		adminDao.addAccountHolderCustomer(customer);
	}

	@Override
	public List<ServiceTracker1> getServiceDetails() throws BankException {
		return adminDao.getServiceDetails();
	}

	@Override
	public boolean updateStatus(long serviceId, String status)
			throws BankException {
		return adminDao.updateStatus(serviceId, status);
	}

	@Override
	public long addAccountHolder(Users1 user, Customer1 customer,
			AccountMaster1 account) throws BankException {
		// TODO Auto-generated method stub
		return adminDao.addAccountHolder(user, customer, account);
	}

	
}
