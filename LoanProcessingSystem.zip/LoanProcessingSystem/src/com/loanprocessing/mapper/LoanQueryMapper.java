package com.loanprocessing.mapper;

public interface LoanQueryMapper {
	
	public static final String getLoanPrgQuery="SELECT prgmId, type FROM loanprogramsoffered";
	
	public static final String getLoanDesc="SELECT * FROM loanprogramsoffered WHERE prgmId=?";
	
	public static final String insertLoanApp="INSERT INTO loanApplication(application_id,application_date,loan_progrm,amt_of_loan,"
			+ "addr_of_property,annual_family_income,proofs_available,guarantee_cover,market_value_of_gc,status,date_of_interview) "
			+ "VALUES(?,sysdate,?,?,?,?,?,?,?,?,null)";
	
	public static final String getLoanId= "SELECT application_id_seq.nextval FROM dual";
	
	public static final String insertCustDetails="INSERT INTO customer_details VALUES(?,?,?,?,?,?,?,?)";
	

	public static final String checkStatus = "SELECT application_date,status,date_of_interview FROM loanapplication WHERE application_id=?";

	public static final String isValidLoanId = "SELECT * FROM loanapplication WHERE application_id =? ";
	
	public static final String isValidPrgId = "SELECT * FROM loanprogramsoffered WHERE prgmId = ?";
	
	
}
