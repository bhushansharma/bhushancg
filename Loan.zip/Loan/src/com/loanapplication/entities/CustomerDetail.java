package com.loanapplication.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.List;


/**
 * The persistent class for the CUSTOMER_DETAILS database table.
 * 
 */
@Component
@Entity
@Table(name="CUSTOMER_DETAILS")
@NamedQuery(name="CustomerDetail.findAll", query="SELECT c FROM CustomerDetail c")
public class CustomerDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CUSTOMER_DETAILS_CUSTOMERID_GENERATOR", sequenceName="CUST_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CUSTOMER_DETAILS_CUSTOMERID_GENERATOR")
	@Column(name="CUSTOMER_ID")
	private long customerId;
	
	
	@Column(name="COUNT_OF_DEPENDENTS")
	private int countOfDependents;

	@NotEmpty(message="Customer Name Should not be Empty")
	@Column(name="CUSTOMER_NAME")
	private String customerName;

//	@Temporal(TemporalType.DATE)
	private Date dob;

	@NotEmpty(message="Email Should not be empty")
	@Email(message="Email Should be in Proper Format")
	@Column(name="EMAIL_ID")
	private String emailId;

	@NotEmpty(message="Please Select an Option")
	@Column(name="MARITAL_STATUS")
	private String maritalStatus;

	@Column(name="MOBILE_NO")
	private long mobileNo;

	//bi-directional many-to-one association to Approvedloan
	@OneToMany(mappedBy="customerDetail")
	private List<Approvedloan> approvedloans;

	//bi-directional many-to-one association to Loanapplication
	@OneToMany(mappedBy="customerDetail")
	private List<Loanapplication> loanapplications;

	public CustomerDetail() {
	}

	public long getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public int getCountOfDependents() {
		return this.countOfDependents;
	}

	public void setCountOfDependents(int countOfDependents) {
		this.countOfDependents = countOfDependents;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMaritalStatus() {
		return this.maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public long getMobileNo() {
		return this.mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public List<Approvedloan> getApprovedloans() {
		return this.approvedloans;
	}

	public void setApprovedloans(List<Approvedloan> approvedloans) {
		this.approvedloans = approvedloans;
	}

	public Approvedloan addApprovedloan(Approvedloan approvedloan) {
		getApprovedloans().add(approvedloan);
		approvedloan.setCustomerDetail(this);

		return approvedloan;
	}

	public Approvedloan removeApprovedloan(Approvedloan approvedloan) {
		getApprovedloans().remove(approvedloan);
		approvedloan.setCustomerDetail(null);

		return approvedloan;
	}

	public List<Loanapplication> getLoanapplications() {
		return this.loanapplications;
	}

	public void setLoanapplications(List<Loanapplication> loanapplications) {
		this.loanapplications = loanapplications;
	}

	public Loanapplication addLoanapplication(Loanapplication loanapplication) {
		getLoanapplications().add(loanapplication);
		loanapplication.setCustomerDetail(this);

		return loanapplication;
	}

	public Loanapplication removeLoanapplication(Loanapplication loanapplication) {
		getLoanapplications().remove(loanapplication);
		loanapplication.setCustomerDetail(null);

		return loanapplication;
	}

}