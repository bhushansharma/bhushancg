package com.loanprocessing.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.loanprocessing.bean.ApplicationDetails;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.dao.AdminDAOImpl;
import com.loanprocessing.dao.AdminDao;
import com.loanprocessing.exception.LoanProgramException;

public class LoanAdminServiceImpl implements LoanAdminService {

	AdminDao daoAdmin;

	public LoanAdminServiceImpl() {

		daoAdmin = new AdminDAOImpl();
	}

	@Override
	public ArrayList<LoanPrograms> getLoanProgramsAdmin()
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.getLoanProgramsAdmin();
	}

	@Override
	public boolean isValidAdmin(String username, String password)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.isValidAdmin(username, password);
	}

	@Override
	public boolean addLoanProgram(LoanPrograms prg) throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.addLoanProgram(prg);
	}

	@Override
	public boolean deleteLoanProgram(int prgId) throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.deleteLoanProgram(prgId);
	}

	@Override
	public ArrayList<ApplicationDetails> viewLoanApplication(LocalDate loanDate)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.viewLoanApplication(loanDate);
	}

	@Override
	public boolean updateROI(int id, double rate) throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.updateROI(id, rate);
	}

	@Override
	public boolean updateMinAmt(int id, int minAmt) throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.updateMinAmt(id, minAmt);
	}

	@Override
	public boolean updateMaxAmt(int id, int maxAmt) throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoAdmin.updateMaxAmt(id, maxAmt);
	}

	@Override
	public boolean isValidateProgramId(int prgId) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String id = String.valueOf(prgId);
		String pattern = "[1-9]{1}[0-9]{2,4}";
		boolean msg = Pattern.matches(pattern, id);
		if (msg == true) {
			flag = true;
		}

		return flag;
	}

	@Override
	public boolean isValidateProgramName(String prgName)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String pattPName = "[A-Z]{1}[A-Za-z\\sA-Za-z]{1,9}";
		boolean msg = Pattern.matches(pattPName, prgName);
		if (msg == true) {
			flag = true;
		}
		return flag;
	}

	@Override
	public boolean isValidateProgramType(String prgType)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String pattType = "[A-Z]{1}[A-Za-z\\sA-Za-z]{1,14}";
		boolean msg = Pattern.matches(pattType, prgType);
		if (msg == true) {
			flag = true;
		}
		return flag;
	}

	@Override
	public boolean isValidateProgramDescription(String description)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String pattDesc = "[A-Z]{1}[A-Za-z\\sA-Za-z]{1,39}";
		boolean msg = Pattern.matches(pattDesc, description);
		if (msg == true) {
			flag = true;
		}
		return flag;
	}

	@Override
	public boolean isValidateProgramDuration(int duration)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String duration1 = String.valueOf(duration);
		String pattern = "[1-9]{1}[0-9]{1}";
		boolean msg = Pattern.matches(pattern, duration1);
		if (msg == true) {
			flag = true;
		}

		return flag;
	}

	@Override
	public boolean isValidateProgramMinAmt(int minAmount)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String min = String.valueOf(minAmount);
		String pattern = "[1-9]{1}[0-9]{1,9}";
		boolean msg = Pattern.matches(pattern, min);
		if (msg == true) {
			flag = true;
		}

		return flag;
	}

	@Override
	public boolean isValidateProgramMaxAmt(int maxAmount)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String max = String.valueOf(maxAmount);
		String pattern = "[1-9]{1}[0-9]{1,9}";
		boolean msg = Pattern.matches(pattern, max);
		if (msg == true) {
			flag = true;
		}

		return flag;
	}

	@Override
	public boolean isValidateProgramRoi(Double prgROI)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String roi = String.valueOf(prgROI);
		String pattern = "[+-]?([0-9]*[.])?[0-9]+";
		boolean msg = Pattern.matches(pattern, roi);
		if (msg == true) {
			flag = true;
		}

		return flag;
	}

	@Override
	public boolean isValidateProgramProofs(String proofs)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String pattProof = "[A-Z]{1}[A-Za-z\\sA-Za-z]{1,49}";
		boolean msg = Pattern.matches(pattProof, proofs);
		if (msg == true) {
			flag = true;
		}
		return flag;
	}

	
}
