package com.loanprocessing.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.loanprocessing.bean.CustomerDetails;
import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.dbutil.DBUtil;
import com.loanprocessing.exception.LoanProgramException;
import com.loanprocessing.logger.MyLogger;
import com.loanprocessing.mapper.LoanQueryMapper;

public class LoanDAOImpl implements LoanDAO {

	Logger logger = MyLogger.getLoggerInstance();
	Connection con;

	public LoanDAOImpl() {
		// TODO Auto-generated constructor stub
		con = DBUtil.getConnection();
		if(con!=null)
		{
			logger.info("Obtained Connection for LoanDaoClass");
		}
	}

	@Override
	public HashMap<Integer, String> getLoanProgram()
			throws LoanProgramException {
		HashMap<Integer, String> loanPrgMap = new HashMap<>();

		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery(LoanQueryMapper.getLoanPrgQuery);
			while (res.next()) {
				loanPrgMap.put(res.getInt(1), res.getString(2));
				logger.info("Program id and type Successfully Retrieved");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Could not Retrieve Program id and type Successfully");
			throw new LoanProgramException(e.getMessage());
		}

		return loanPrgMap;
	}

	@Override
	public LoanPrograms getLoanDescription(int programId)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		LoanPrograms loanProgram = null;
		if (isValideLoanProgramId(programId)) {

			try {
				PreparedStatement pstmt = con
						.prepareStatement(LoanQueryMapper.getLoanDesc);
				pstmt.setInt(1, programId);
				ResultSet res = pstmt.executeQuery();
				while (res.next()) {
					loanProgram = new LoanPrograms();
					loanProgram.setProgramId(res.getInt(1));
					loanProgram.setProgramName(res.getString(2));
					loanProgram.setDescriptn(res.getString(3));
					loanProgram.setType(res.getString(4));
					loanProgram.setDuration(res.getInt(5));
					loanProgram.setMinAmount(res.getInt(6));
					loanProgram.setMaxAmount(res.getInt(7));
					loanProgram.setRate(res.getInt(8));
					loanProgram.setProof(res.getString(9));
					logger.info("Loan Program Descriptions Fetched "+programId);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error("Loan Program with "+programId+" is not found");
				throw new LoanProgramException(e.getMessage());
			}
		}

		return loanProgram;
	}

	@Override
	public boolean insertLoanApplictaion(LoanApplication loanApp)
			throws LoanProgramException {
		boolean flag = false;
		int loanAppId = getLoanAppId();
		loanApp.setLoanAppId(loanAppId);

		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanQueryMapper.insertLoanApp);
			pstmt.setInt(1, loanAppId);
			pstmt.setString(2, loanApp.getLoanProgm());
			pstmt.setDouble(3, loanApp.getAmount());
			pstmt.setString(4, loanApp.getAddress());
			pstmt.setDouble(5, loanApp.getIncome());
			pstmt.setString(6, loanApp.getProof());
			pstmt.setString(7, loanApp.getCover());
			pstmt.setInt(8, loanApp.getMarketValue());
			pstmt.setString(9, loanApp.getStatus());
			System.out.println(loanApp.getInterviewDate());
			// pstmt.setDate(10, null);

			int row = pstmt.executeUpdate();
			if (row == 0)
				throw new LoanProgramException(
						" Loan Application Not Submitted for " + loanAppId);
			else
				logger.info("Loan Application has been Inserted Successfully");
				flag = true;

		} catch (SQLException e) {
			 logger.error("Loan Application Not Submitted for "+loanAppId);			
			 throw new LoanProgramException(e.getMessage());

		}
		return flag;

	}

	private int getLoanAppId() throws LoanProgramException {

		Statement stmt;
		int loanAppId = 0;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery(LoanQueryMapper.getLoanId);
			if (res.next())
				loanAppId = res.getInt(1);
				logger.info("Loan Application id Successfully generated form Sequence");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Could not generate Loan Application id from Sequence");
			throw new LoanProgramException(e.getMessage());
		}
		return loanAppId;
	}

	@Override
	public boolean insertCustomerDetails(CustomerDetails custBean)
			throws LoanProgramException {

		boolean flag = false;
		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanQueryMapper.insertCustDetails);
			pstmt.setInt(1, custBean.getLoanAppId());
			pstmt.setString(2, custBean.getAppName());
			pstmt.setDate(3, Date.valueOf(custBean.getDob()));
			pstmt.setString(4, custBean.getMaritalStatus());
			pstmt.setString(5, custBean.getPhoneNo());
			pstmt.setString(6, custBean.getMobileNo());
			pstmt.setInt(7, custBean.getCount());
			pstmt.setString(8, custBean.getEmail());
			int row = pstmt.executeUpdate();
			if (row == 0) {
				throw new LoanProgramException(
						"Customer Details Not Submitted successfully "
								+ custBean.getAppName());
			} else {
				logger.info("Customer Details has been Inserted Successfully");
				flag = true;

			}

		} catch (SQLException e) {
			logger.error("Customer Details Not Submitted Successfully");
			throw new LoanProgramException(e.getMessage());
		}
		return flag;
	}

	@Override
	public LoanApplication checkStatus(int loanAppId)
			throws LoanProgramException {
		LoanApplication loanAppBean = null;
		if (isValideLoanId(loanAppId)) {

			
			try {
				PreparedStatement pstmt = con.prepareStatement(LoanQueryMapper.checkStatus);
				pstmt.setInt(1, loanAppId);
				ResultSet res = pstmt.executeQuery();

				if (res.next()) {
					loanAppBean = new LoanApplication();
					loanAppBean.setAppDate(res.getDate(1).toLocalDate());
					loanAppBean.setStatus(res.getString(2));
					System.out.println(res.getDate(3));
					if (loanAppBean.getStatus().equals("APPROVED"))
						loanAppBean.setInterviewDate(res.getDate(3)
								.toLocalDate());
					logger.info(" application_date,status,date_of_interview Fetched successfully for "+loanAppId);
				}
			} catch (SQLException e) {
				logger.error("Could not find record with loan Application id:"+loanAppId);
				throw new LoanProgramException(e.getMessage());
			}

		}
		return loanAppBean;
	}

	private boolean isValideLoanId(int loanAppId) throws LoanProgramException {

		boolean flag = false;
		
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(LoanQueryMapper.isValidLoanId);
			pstmt.setInt(1, loanAppId);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				flag = true;
				logger.info("Loan Application Fetched Successfully with application id: "+loanAppId);
			}
		} catch (SQLException e) {
			logger.error("Loan Application with application id "+loanAppId+" not found");
			throw new LoanProgramException(e.getMessage());
		}
		return flag;

	}

	private boolean isValideLoanProgramId(int loanPrgId)
			throws LoanProgramException {

		boolean flag = false;
		
				
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(LoanQueryMapper.isValidPrgId);
			pstmt.setInt(1, loanPrgId);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				flag = true;
				logger.info("Loan Program Fetched Successfully with program id: "+loanPrgId);
			}
		} catch (SQLException e) {
			logger.error("Loan Program with program id "+loanPrgId+" not found");
			throw new LoanProgramException(e.getMessage());
		}
		return flag;

	}

}
