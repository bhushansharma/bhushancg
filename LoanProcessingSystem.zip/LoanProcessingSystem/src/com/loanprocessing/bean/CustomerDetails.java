package com.loanprocessing.bean;
import java.time.LocalDate;


public class CustomerDetails {
	private int loanAppId;
	private String appName;
	private LocalDate dob;
	private String maritalStatus;
	private String phoneNo;
	private String mobileNo;
	private int count;
	private String email;
	public int getLoanAppId() {
		return loanAppId;
	}
	public void setLoanAppId(int loanAppId) {
		this.loanAppId = loanAppId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNum) {
		this.phoneNo = phoneNum;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobNum) {
		this.mobileNo = mobNum;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "CustomerDetails [loanAppId=" + loanAppId + ", appName="
				+ appName + ", dob=" + dob + ", maritalStatus=" + maritalStatus
				+ ", phoneNo=" + phoneNo + ", mobileNo=" + mobileNo
				+ ", count=" + count + ", email=" + email + "]";
	}
	
		
	
}
