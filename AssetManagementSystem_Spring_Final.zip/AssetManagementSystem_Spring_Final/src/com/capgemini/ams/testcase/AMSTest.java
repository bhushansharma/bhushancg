package com.capgemini.ams.testcase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.Test;
import com.capgemini.ams.dao.AMSDaoImpl;
import com.capgemini.ams.exception.AssetException;
import com.capgemini.ams.service.AMSServiceImpl;

public class AMSTest
{
	AMSServiceImpl amsService;
	AMSDaoImpl amsDao;
	
	@Before
	public void init()
	{
		amsService = new AMSServiceImpl();
		amsDao = new AMSDaoImpl();
		amsService.setDao(amsDao);
	}

	@Test
	public void testShowAllAssets() throws AssetException 
	{
		assertNotEquals(0, amsService.showAllAssets().size());
	}
	
	@Test
	public void testShowAllAssetsFail() throws AssetException 
	{
		assertEquals(0, amsService.showAllAssets().size());
	}

	@Test
	public void testShowAllRequests() throws AssetException
	{
		assertNotEquals(0, amsService.showAllRequests().size());
	}
	
	@Test
	public void testShowAllRequestsFail() throws AssetException
	{
		assertEquals(0, amsService.showAllRequests().size());
	}

	@Test
	public void testGetAssetDetailsById() throws AssetException 
	{
		assertNotNull(amsService.getAssetDetailsById(1002));
	}
	
	@Test
	public void testGetAssetDetailsByIdFail() throws AssetException 
	{
		assertNull(amsService.getAssetDetailsById(1223));
	}
}
