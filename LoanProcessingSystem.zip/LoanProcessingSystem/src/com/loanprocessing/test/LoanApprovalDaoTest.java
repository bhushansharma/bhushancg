package com.loanprocessing.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.Users;
import com.loanprocessing.dao.LoanApprovalDAO;
import com.loanprocessing.dao.LoanApprovalDAOImpl;
import com.loanprocessing.exception.LoanProgramException;
import com.loanprocessing.service.LoanApprovalServiceImpl;

public class LoanApprovalDaoTest {
	
	LoanApprovalServiceImpl service;
	LoanApprovalDAO daoLad;
	
	@Before
	public void init()
	{
		service= new LoanApprovalServiceImpl();
		daoLad = new LoanApprovalDAOImpl();
		service.setDao(daoLad);
	}


	@Test
	public void testIsValidLad() throws LoanProgramException {
		Users Bean = new Users();
		
		Bean.setLoginId("lad");
		Bean.setPassword("lad");
		Bean.setRole("lad");
		
		assertEquals(true, service.isValidLad("lad","lad"));
	}
	
	@Test
	public void testWrongIsValidLad() throws LoanProgramException {
		Users Bean = new Users();
		
		Bean.setLoginId("abc");
		Bean.setPassword("abc");
		Bean.setRole("abc");
		
		assertEquals(true, service.isValidLad("abc","abc"));
	}
	
	
	
	@Test
	public void testApprovedLoans() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		
		bean.setLoanAppId(10001);
		bean.setLoanProgm("HomeConstruction");
		bean.setAmount(500000.00);
		bean.setAddress("Pune");
		bean.setIncome(1000000.00);
		bean.setProof("Aadhar Card");
		bean.setStatus("Applied");
		
		assertEquals(true, service.approvedLoans(bean));
	}

	@Test
	public void testGetLoanApplication() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		bean.setAppDate(LocalDate.parse("2017-06-29"));
		
		assertNotNull(service.getLoanApplication(LocalDate.parse("2017-06-29")));
	}
	
	@Test
	public void testWrongGetLoanApplication() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		bean.setAppDate(LocalDate.parse("2017-06-20"));
		
		assertEquals(true,service.getLoanApplication(LocalDate.parse("2017-06-20")));
	}

	@Test
	public void testViewLoanApplicationLAD() throws LoanProgramException {
		LoanApplication bean =new LoanApplication();
		bean.setLoanAppId(10001);
		
		assertNotNull(service.viewLoanApplicationLAD(10001));
	}
	
	@Test
	public void testWrongViewLoanApplicationLAD() throws LoanProgramException {
		LoanApplication bean =new LoanApplication();
		bean.setLoanAppId(10021);
		
		assertEquals(true,service.viewLoanApplicationLAD(10021));
	}

	@Test
	public void testRejectLoans() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		
		bean.setLoanAppId(10001);
		bean.setStatus("Reject");
		
		assertEquals(true, service.rejectLoans(bean));
	}
	
	@Test
	public void tesWrongRejectLoans() throws LoanProgramException {
		LoanApplication bean = new LoanApplication();
		
		bean.setLoanAppId(10001);
		bean.setStatus("Reject");
		
		assertNotEquals(true, service.rejectLoans(bean));
	}

}
