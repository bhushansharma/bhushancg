package com.cg.university.dao;

import java.time.LocalDate;
import java.util.ArrayList;





import com.cg.university.entities.Application;
import com.cg.university.entities.ProgramsOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;

public interface StudentDao {

	public void insertApplication(Application bean)
			throws UniversityException;

	public ArrayList<ProgramsScheduled> getScheduledPrograms()
			throws UniversityException;

	public ArrayList<ProgramsOffered> getAllPrograms()
			throws UniversityException;

	public Application getApplicationStatus(int applicationId)
			throws UniversityException;

	
}
