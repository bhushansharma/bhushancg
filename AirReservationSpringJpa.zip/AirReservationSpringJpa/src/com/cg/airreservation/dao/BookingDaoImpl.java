package com.cg.airreservation.dao;

/**
 * BookingDaoImpl is implementation of IBookingDao Interface,
 *  used to do all the functionality related to booking, for e.g: add new booking or Update booking . 
 */

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.utility.IQueryMapper;
import com.cg.airreservation.utility.Mylogger;

// this class implements IbookingDao interface
@Repository
public class BookingDaoImpl implements IBookingDao {

	Logger logger = Mylogger.getLoggerInstance();
	@PersistenceContext
	EntityManager entityManager;
	/*
	 * this method is used to confirm booking information i.e used to add
	 * booking details into database
	 */
	@Override
	public boolean confirmBooking(Bookinginfo bookInfo) throws AirlineException {
		try {
			entityManager.persist(bookInfo);
		} catch (Exception e) {
			logger.error("Error while confirming booking " +e.getMessage());
			throw new AirlineException(
					"Booking Failed beacause of Server Issue..Please try again after some time.. Thank you..");
		}
		return true;
	}

	/*
	 * this method is used to update booking information
	 */
	@Override
	public boolean updateBooking(Bookinginfo bookingInfo)
			throws AirlineException {
		try {
			Bookinginfo bookUpdate = entityManager.getReference(
					Bookinginfo.class, bookingInfo.getBookingid());
			bookUpdate.setClasstype(bookingInfo.getClasstype());
			bookUpdate.setPassengernum(bookingInfo.getPassengernum());
			bookUpdate.setTotalfare(bookUpdate.getTotalfare());
			entityManager.merge(bookUpdate);
		} catch (Exception e) {
			logger.error("Error While updating booking" +e.getMessage());
			throw new AirlineException(
					"Booking Failed to Upadte beacause of Server Issue..Please try again after some time.. Thank you..");

		}
		return true;
	}

	/*
	 * this method is used to cancel booking information
	 */
	@Override
	public boolean cancelBooking(long id) throws AirlineException {
		Bookinginfo bookInfo = entityManager.find(Bookinginfo.class, id);
		if (bookInfo == null)
		{
			logger.error("In Cancel method,Error while retrieving booking details by id ");

			throw new AirlineException(
					"Such Id doesn't exists.. Please Try again later");
		}
		
		try {

			entityManager.remove(bookInfo);
		} catch (Exception e) {
			logger.error("Error removing record from booking info" +e.getMessage());
			throw new AirlineException(
					"Tickets cannot be cancelled because of Server Issue..Please try again after some time.. Thank you..");
		}
		return true;
	}

	/*
	 * this method is used to fetch booking based on id
	 */
	@Override
	public Bookinginfo fetchBookingDetails(long id) throws AirlineException {
		Bookinginfo bookInfo = entityManager.find(Bookinginfo.class, id);
		if (bookInfo == null)
		{
			logger.error("Error retrieving booking details by id ");

			throw new AirlineException(
					"Such Id doesn't exists.. Please Try again later");
		}
		
		return bookInfo;
	}

	/*
	 * this method is used to get booking details based on customer email
	 */
	@Override
	public ArrayList<Bookinginfo> getBookingDetails(String email)
			throws AirlineException {
		Query qry = entityManager.createQuery(IQueryMapper.bookingDetails);
		qry.setParameter("email", email);
		qry.setParameter("date", Date.valueOf(LocalDate.now()));
		@SuppressWarnings("unchecked")
		ArrayList<Bookinginfo> bookingInfoList = (ArrayList<Bookinginfo>) qry.getResultList();
		if (bookingInfoList.size() == 0)
		{
			logger.error("Booking info list is " +bookingInfoList);
			throw new AirlineException(
					"No booking is done by this customer.. Please Try again later");
		
		}
		return bookingInfoList;
	}
	
	
	@Override
	public ArrayList<Bookinginfo> getAllBookingDetails(String email) throws AirlineException {
		String sql="select book FROM Bookinginfo book where customerinfo.custemail=:email";
		
		Query qry=entityManager.createQuery(sql);
		qry.setParameter("email", email);
		
		@SuppressWarnings("unchecked")
		ArrayList<Bookinginfo> bookingInfoList =  (ArrayList<Bookinginfo>) qry.getResultList();
		if (bookingInfoList.size() == 0)
			throw new AirlineException("No booking is done by this customer.. Please Try again later");
		return bookingInfoList;
	}

}
