package com.capgemini.ams.service;

import java.time.LocalDate;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.exception.AssetException;

public interface IAdminService 
{
	boolean addAsset(Asset asset)throws AssetException;

	boolean allocateAsset(long requestId, LocalDate releaseDate)throws AssetException;
	
	boolean generateReport() throws AssetException;

	boolean modifyAsset(Asset asset)throws AssetException;
}
