package com.cg.airreservation.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.sql.Date;


/**
 * The persistent class for the BOOKINGINFO database table.
 * 
 */
@Component
@Entity
@Table(name="BOOKINGINFO")
@NamedQuery(name="Bookinginfo.findAll", query="SELECT b FROM Bookinginfo b")
public class Bookinginfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=5)
	@SequenceGenerator(name="bookIdSeq",sequenceName="seqBookId", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bookIdSeq")
	private long bookingid;

	@Column(length=10)
	private String classtype;

	//@Temporal(TemporalType.DATE)
	private Date dateofjourney;

	@Column(length=20)
	private String destcity;

	@Column(precision=3)
	private int passengernum;

	@Column(length=20)
	private String sourcecity;

	@Column(precision=8, scale=2)
	private double totalfare;

	//bi-directional many-to-one association to Customerinfo
	@ManyToOne
	@JoinColumn(name="CUSTEMAIL")
	private Customerinfo customerinfo;

	//bi-directional many-to-one association to Flightinfo
	@ManyToOne
	@JoinColumn(name="FLIGHTID")
	private Flightinfo flightinfo;

	public Bookinginfo() {
	}

	public long getBookingid() {
		return this.bookingid;
	}

	public void setBookingid(long bookingid) {
		this.bookingid = bookingid;
	}

	public String getClasstype() {
		return this.classtype;
	}

	public void setClasstype(String classtype) {
		this.classtype = classtype;
	}

	public Date getDateofjourney() {
		return this.dateofjourney;
	}

	public void setDateofjourney(Date dateofjourney) {
		this.dateofjourney = dateofjourney;
	}

	public String getDestcity() {
		return this.destcity;
	}

	public void setDestcity(String destcity) {
		this.destcity = destcity;
	}

	public int getPassengernum() {
		return this.passengernum;
	}

	public void setPassengernum(int passengernum) {
		this.passengernum = passengernum;
	}

	public String getSourcecity() {
		return this.sourcecity;
	}

	public void setSourcecity(String sourcecity) {
		this.sourcecity = sourcecity;
	}

	public double getTotalfare() {
		return this.totalfare;
	}

	public void setTotalfare(double totalfare) {
		this.totalfare = totalfare;
	}

	public Customerinfo getCustomerinfo() {
		return this.customerinfo;
	}

	public void setCustomerinfo(Customerinfo customerinfo) {
		this.customerinfo = customerinfo;
	}

	public Flightinfo getFlightinfo() {
		return this.flightinfo;
	}

	public void setFlightinfo(Flightinfo flightinfo) {
		this.flightinfo = flightinfo;
	}

}