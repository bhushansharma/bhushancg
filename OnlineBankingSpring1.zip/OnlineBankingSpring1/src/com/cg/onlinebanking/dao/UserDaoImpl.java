package com.cg.onlinebanking.dao;



import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

















import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.FundTransfer1;
import com.cg.onlinebanking.entities.Payee1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.entities.Users1;
import com.cg.onlinebanking.exception.BankException;


@Repository
public class UserDaoImpl implements UserDao 
{

	@PersistenceContext
	private EntityManager entityManager;
	
	/* (non-Javadoc)
	 * Description: show recent 10 transaction details
	 * Return Value: Transactions List
	 * @see com.cg.onlinebanking.dao.UserDao#showAllData(long)
	 */
	@Override
	public List<Transactions1> showAllData(long accountNo) throws BankException {
		return null;
	}

	/* (non-Javadoc)
	 * Description: Validate User 
	 * Return Value: int 1: True, other: false 
	 * @see com.cg.onlinebanking.dao.UserDao#showAllData(long)
	 */
	@Override
	public int validateUser(long userid, String pass) throws BankException {
		TypedQuery<Users1> query = entityManager.createQuery("Select user FROM Users1 user WHERE user.userId=:uid and user.loginPassword=:pass",Users1.class);
		query.setParameter("uid", userid);
		query.setParameter("pass", pass);
		int queryCount = query.getResultList().size();
		if(queryCount==0)//return false;
			throw new BankException("Invalid Credentials");	
		return 1;
	}

	/* (non-Javadoc)
	 * Description: Retrieve Account Id
	 * Return Value:long Account Id
	 * @see com.cg.onlinebanking.dao.UserDao#showAllData(long)
	 */
	
	@Override
	public long getAccountId(long userId) throws BankException {
		Users1 user = entityManager.find(Users1.class, userId);
		
		if(user==null)
			throw new BankException("No User Is Present with user Id "+userId);

		long accountId=user.getAccountMaster1().getAccountId();
		return accountId;
	}

	
	@Override
	public long checkbookRequest(long accountId) throws BankException {
		String str="Select service FROM ServiceTracker1 service WHERE accountMaster1.accountId=:accountId";
		TypedQuery<ServiceTracker1> query = entityManager.createQuery(str, ServiceTracker1.class);
		query.setParameter("accountId", accountId);
		ServiceTracker1 request=new ServiceTracker1();
		int requestCount=query.getResultList().size();
		if(requestCount!=0)
			throw new BankException("You have already requested a ChequeBook for account id : "+accountId);

		request.setServiceDescription("chequeBookRequest");
		request.setServiceRaisedDt(Timestamp.valueOf(LocalDateTime.now()));
		request.setServiceStatus("Open");
		AccountMaster1 account=findAccount(accountId);
		request.setAccountMaster1(account);
		
		entityManager.persist(request);
		entityManager.flush();
		return request.getServiceId();
			
	}

	@Override
	public ServiceTracker1 getTrackDetail(long serviceId, long accountId)
			throws BankException {
		String str="Select service FROM ServiceTracker1 service WHERE "
				+ "accountMaster1.accountId=:accountId AND serviceId=:serviceId";
		TypedQuery<ServiceTracker1> query = entityManager.createQuery(str, ServiceTracker1.class);
		query.setParameter("accountId", accountId);
		query.setParameter("serviceId", serviceId);
		int requestCount= query.getResultList().size();
		if(requestCount==0)
			throw new BankException("No Service Request for AccountId "+accountId);
		ServiceTracker1 request = query.getSingleResult();
		return request;
	}

	@Override
	public double getAccountBalance(long userId) throws BankException {
		// TODO Auto-generated method stub
		long accountId = getAccountId(userId);
		AccountMaster1 account = findAccount(accountId);
		
		return account.getAccountBalance();
	}

	@Override
	public void lockAccount(long userId) throws BankException {
		// TODO Auto-generated method stub
		Users1 user=entityManager.find(Users1.class,userId);
		user.setLockStatus("L");
		entityManager.merge(user);
		entityManager.flush();	
	}

	
	@Override
	public ArrayList<Payee1> getPayee(long accountId) throws BankException {
		// TODO Auto-generated method stub

		ArrayList<Payee1> payees;
		TypedQuery<Payee1> query = entityManager.createQuery("SELECT payee FROM Payee1 payee WHERE accountMaster11.accountId=:accountId",Payee1.class);
		query.setParameter("accountId",accountId);
		payees=(ArrayList<Payee1>) query.getResultList();
		if(payees.size()==0)
		{
			throw new BankException("No Payee found for account Id" +accountId);
		}
		
		return payees;
	}


	@Override
	public boolean checkBalance(long accountId, double amount)
			throws BankException {
		// TODO Auto-generated method stub
		AccountMaster1 account=entityManager.find(AccountMaster1.class, accountId);
		double accountBalance = account.getAccountBalance();
		if(accountBalance-amount<=500)
			throw new BankException("account Balance is too low");
		
		return true;
	}
	
	@Override
	public AccountMaster1 findAccount(long accountId) throws BankException
	{
		AccountMaster1 account=entityManager.find(AccountMaster1.class, accountId);
		if(account==null)
		{
			throw new BankException("Account Id "+accountId+" doesn't exists");
		}
		return account;
	}

	@Override
	public long transferFund(Transactions1 transaction,long payeeAccountId)
			throws BankException {
		
		amountCredit(payeeAccountId, transaction.getTransactionAmount());
		amountDebit(transaction.getAccountMaster1().getAccountId(),transaction.getTransactionAmount());
		
		
		transaction.setDtOfTransaction(Timestamp.valueOf(LocalDateTime.now()));
		transaction.setTransactionType("W");
		insertTransaction(transaction);
		
		AccountMaster1 payeeAccount=findAccount(payeeAccountId);
		
		
		Transactions1 payeeTransaction =new Transactions1();
		
		payeeTransaction.setAccountMaster1(payeeAccount);
		payeeTransaction.setDtOfTransaction(transaction.getDtOfTransaction());
		payeeTransaction.setTranactionDescription(transaction.getTranactionDescription());
		payeeTransaction.setTransactionAmount(transaction.getTransactionAmount());
		payeeTransaction.setTransactionType("D");
		insertTransaction(payeeTransaction);
		
		FundTransfer1 fundTransfer = createFundTransfer(transaction, payeeAccount);
		entityManager.persist(fundTransfer);
		entityManager.flush();
		return fundTransfer.getFundTransferId();
		
	}
	
	@Override
	public String getTransactionPassword(long accountId) throws BankException
	{
		String str="Select user FROM Users1 user WHERE accountMaster1.accountId=:accountId";
		TypedQuery<Users1> query=entityManager.createQuery(str, Users1.class);
		query.setParameter("accountId", accountId);
		Users1 user = query.getSingleResult();
		if(user==null)
			throw new BankException("No User with accountId "+accountId);
		String password=user.getTransactionPassword();
		return password;
	}
	
	private void amountDebit(long accountId, double amount) throws BankException
	{

			String update = "UPDATE AccountMaster1 accountmaster SET "
					+ "accountBalance=accountBalance-:amount WHERE accountId=:aId";
			Query query=entityManager.createQuery(update);
			query.setParameter("amount", amount);
			query.setParameter("aId", accountId);
			int row =query.executeUpdate();
			if (row == 0) 
			{
				throw new BankException("Problem in updating "+accountId+" accountid");
			}
	}
	
	private void amountCredit(long payeeAccountId, double amount) throws BankException
	{	
		String update = "UPDATE AccountMaster1 accountmaster SET accountBalance=accountBalance+:amount WHERE accountId=:paId";
		Query query=entityManager.createQuery(update);
		query.setParameter("amount", amount);
		query.setParameter("paId", payeeAccountId);
		int row=query.executeUpdate();
		if (row == 0) 
		{
			throw new BankException("Problem in updating "+payeeAccountId+" accountid");
		}
	}
	
	private void insertTransaction(Transactions1 transaction)
	{
		entityManager.persist(transaction);
		entityManager.flush();
	}
	
	private FundTransfer1 createFundTransfer(Transactions1 transaction,AccountMaster1 payeeAccount)
	{
		FundTransfer1 fundTransfer=new FundTransfer1();
		fundTransfer.setAccountMaster11(transaction.getAccountMaster1());
		fundTransfer.setAccountMaster12(payeeAccount);
		fundTransfer.setDtOfTransfer(transaction.getDtOfTransaction());
		fundTransfer.setTransferAmount(transaction.getTransactionAmount());
		return fundTransfer;
		
	}

}
