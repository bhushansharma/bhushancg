/**
 * 
 */
package com.cg.onlinebanking.controller;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.onlinebanking.entities.AccountMaster1;
import com.cg.onlinebanking.entities.Admins1;
import com.cg.onlinebanking.entities.Customer1;
import com.cg.onlinebanking.entities.ServiceTracker1;
import com.cg.onlinebanking.entities.Transactions1;
import com.cg.onlinebanking.entities.Users1;
import com.cg.onlinebanking.exception.BankException;
import com.cg.onlinebanking.service.IAdminService;

/**
 * Description :
 * 
 * @author pgrover
 *
 */
@Controller
public class AdminController {

	@Autowired
	IAdminService adminService;

	@Autowired
	Admins1 admin;

	@Autowired
	Users1 user;

	@Autowired
	AccountMaster1 accMaster;

	@Autowired
	Customer1 customer;

	ArrayList<String> categoryList;
	ArrayList<String> questionList;

	/**
	 * Description : Switching to the login form with Admin bean object and the
	 * role attribute
	 */
	@RequestMapping(value = "/showAdminLogin")
	public String showLoginForm(@RequestParam("role") String role, Model model) {

		model.addAttribute("role", role);
		model.addAttribute("admin", admin);
		return "login";
	}

	/**
	 * Description : validates admin credentials
	 * 
	 */
	@RequestMapping(value = "/validateAdminlogin.obj")
	public String validateLogin(@ModelAttribute("admin") Admins1 admin,
			@RequestParam("role") String role,
			BindingResult result, Model model, HttpServletRequest request) {
		String userId = admin.getUserId();
		String password = admin.getPassword();
		try {
			if (adminService.validateAdmin(userId, password)) {
				HttpSession session = request.getSession(true);
				session.setAttribute("login", admin);
				session.setMaxInactiveInterval(3*60);
			}

		} catch (BankException e) {
			model.addAttribute("role",role);
			model.addAttribute("admin",admin);
			model.addAttribute("message", e.getMessage());
			return "login";
		}
		return "home";
	}

	@RequestMapping(value = "/addAccount")
	public String showaddAccount(
			@ModelAttribute("customer") Customer1 customer, Model model) {

		model.addAttribute("customer", customer);

		return "addAccount";
	}

	@RequestMapping(value = "/successCustomer.obj")
	public String addCustomer(@ModelAttribute("customer")@Valid Customer1 customer,
			BindingResult result, Model model, HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		model.addAttribute("customer", customer);
		model.addAttribute("masterOne", accMaster);

		if (result.hasErrors()) {
			model.addAttribute("customer", customer);
			model.addAttribute("masterOne", accMaster);
			return "addAccount";
		} else {
			/*try {
				
				adminService.addAccountHolderCustomer(customer);

			} catch (BankException e) {
				model.addAttribute("exception", e.getMessage());
				return "myError";
			}*/
			session.setAttribute("customer", customer);
			categoryList = new ArrayList<String>();
			categoryList.add("Saving");
			categoryList.add("Current");
			model.addAttribute("categoryList", categoryList);

			questionList = new ArrayList<String>();
			questionList.add("Your Pet Name?");
			questionList.add("Your Nick Name?");
			model.addAttribute("questionList", questionList);
			return "masterAccount";
		}
	}

	@RequestMapping(value = "/successMaster")
	public String addMaster(
			@ModelAttribute("masterOne") @Valid AccountMaster1 masterOne,
			BindingResult result, Model model,HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		model.addAttribute("masterOne", masterOne);
		model.addAttribute("user", user);

		if (result.hasErrors()) {
			model.addAttribute("masterOne", masterOne);
			model.addAttribute("user", user);
			categoryList = new ArrayList<String>();
			categoryList.add("Saving");
			categoryList.add("Current");
			model.addAttribute("categoryList", categoryList);
			return "masterAccount";
		} else {
		//	try {
				masterOne.setOpenDt(Timestamp.valueOf(LocalDateTime.now()));
				session.setAttribute("account", masterOne);
			//	adminService.addAccountHolderMaster(masterOne);
			//	model.addAttribute("accountId", masterOne.getAccountId());

			/*} catch (BankException e) {
				model.addAttribute("exception", e.getMessage());
				return "myError";
			}*/
			questionList = new ArrayList<String>();
			questionList.add("Your Pet Name?");
			questionList.add("Your Nick Name?");
			model.addAttribute("questionList", questionList);
			return "userAccount";
		}
	}

	@RequestMapping(value = "/successUser.obj")
	public String addUser(@ModelAttribute("user")@Valid Users1 user,
			BindingResult result, Model model,HttpServletRequest request) {
		model.addAttribute("user", user);
		HttpSession session = request.getSession(false);
		long userId;

		if (result.hasErrors()) {
			model.addAttribute("user", user);
			questionList = new ArrayList<String>();
			questionList.add("Your Pet Name?");
			questionList.add("Your Nick Name?");
			model.addAttribute("questionList", questionList);
			return "userAccount";
		} else {
			try {
				user.setLockStatus("A");
				Customer1 customer=(Customer1) session.getAttribute("customer");
				AccountMaster1 account = (AccountMaster1) session.getAttribute("account");
				userId = adminService.addAccountHolder(user, customer, account );
				//adminService.addAccountHolderUser(user);
				//model.addAttribute("userId", user.getUserId());
			} catch (BankException e) {
				model.addAttribute("exception", e.getMessage());
				return "myError";
			}
		
			model.addAttribute("userId", userId);
			
			return "success";
		}
	}

	/**
	 * Description : Displays daily transaction reports
	 */
	@RequestMapping(value = "/dailyReport.obj")
	public String showDailyReport(
			@ModelAttribute("transaction") Transactions1 transaction,
			Model model) {

		List<Transactions1> trnList = null;
		try {
			trnList = new ArrayList<Transactions1>();
			trnList = adminService.showDailyData();
			model.addAttribute("dailyTransactions", trnList);
			return "dailyReport";

		} catch (BankException e) {
			model.addAttribute("message", e.getMessage());
			return "dailyReport";
		}
	}

	/**
	 * Description : Displays the current status of the account holder
	 */
	@RequestMapping(value = "/updateStatus")
	public String showStatus(Model model) {

		List<ServiceTracker1> serviceList = null;
		try {
			serviceList = new ArrayList<ServiceTracker1>();
			serviceList = adminService.getServiceDetails();
			model.addAttribute("serviceList", serviceList);
			return "updateStatus";

		} catch (BankException e) {
			model.addAttribute("message", e.getMessage());
			return "updateStatus";
		}
	}

	/**
	 * Description : Updates the status of the specified account holder
	 */
	@RequestMapping(value = "/statusUpdate1")
	public String updateStatus(@RequestParam("status") String status,
			@RequestParam("serviceId") long serviceId, Model model) {
		try {
			adminService.updateStatus(serviceId, status);
		} catch (BankException e) {
			model.addAttribute("message", e.getMessage());
			return "updateStatus";
		}
		return "successStatusUpdate";

	}

	/**
	 * Description : Switches to the monthlyReports form
	 */
	@RequestMapping(value = "/monthlyReport")
	public String getMonth(Model model) {
		return "monthlyReport";
	}

	/**
	 * Description : Displays monthly transactions of all the account holders
	 */
	@RequestMapping(value = "/showReport")
	public String viewMonthlyReport(@RequestParam("month") int month,
			Model model) {
		ArrayList<Transactions1> monthlyTransactionsList = null;
		try {
			monthlyTransactionsList = (ArrayList<Transactions1>) adminService
					.showMonthlyData(month);
		} catch (BankException e) {
			model.addAttribute("message", e.getMessage());
			return "monthlyReport";
		}
		model.addAttribute("monthlyList", monthlyTransactionsList);
		return "monthlyReport";
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session= request.getSession(false);
		
		session.invalidate();
		
		return "redirect:/index.jsp";
	}
}
