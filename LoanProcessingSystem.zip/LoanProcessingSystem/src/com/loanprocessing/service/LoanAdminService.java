package com.loanprocessing.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.loanprocessing.bean.ApplicationDetails;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.exception.LoanProgramException;

public interface LoanAdminService {
	//ADMIN
	
		public boolean isValidAdmin(String username,String password) throws LoanProgramException;
		
		public ArrayList<LoanPrograms> getLoanProgramsAdmin() throws LoanProgramException;
		
		public boolean addLoanProgram(LoanPrograms prg) throws LoanProgramException;
		
		public boolean deleteLoanProgram(int prgId)throws LoanProgramException;
		
		public ArrayList<ApplicationDetails> viewLoanApplication(LocalDate loanDate) throws LoanProgramException;
		
		public boolean updateROI(int id,double rate) throws LoanProgramException;
		
		public boolean updateMinAmt(int id,int minAmt) throws LoanProgramException;
		
		public boolean updateMaxAmt(int id,int maxAmt) throws LoanProgramException;

		public boolean isValidateProgramId(int prgId) throws LoanProgramException;

		public boolean isValidateProgramName(String prgName)throws LoanProgramException;

		public boolean isValidateProgramType(String prgType)throws LoanProgramException;

		public boolean isValidateProgramDescription(String description)throws LoanProgramException;

		public boolean isValidateProgramDuration(int duration)throws LoanProgramException;

		public boolean isValidateProgramMinAmt(int minAmount)throws LoanProgramException;

		public boolean isValidateProgramMaxAmt(int maxAmount)throws LoanProgramException;

		public boolean isValidateProgramRoi(Double prgROI)throws LoanProgramException;

		public boolean isValidateProgramProofs(String proofs)throws LoanProgramException;
		
		

}
