package com.loanprocessing.ui;

import java.time.LocalDate;



public class Demo1 {

	public static void main(String[] args) {
		System.out.println("App Id\t "+"App Date\t "+"Loan Program Name\t"+"Amount \t"
				+ "Add Of Property\t"+"Annual Income\t"+"Doc Proofs Aval"
						+ "Guarantee Cover\t"+"Market Value Of GC"
								+ "Status\t"+"Date Of Interview");	
		LocalDate date = null;
		System.out.println(date);
	}

}

