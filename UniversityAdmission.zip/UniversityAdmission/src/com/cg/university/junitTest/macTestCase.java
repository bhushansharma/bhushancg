package com.cg.university.junitTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.university.dao.MacDao;
import com.cg.university.dao.MacDaoImpl;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.service.MacServicesImpl;

public class macTestCase {
	
	
	MacServicesImpl service;
	MacDao dao;
	
	@Before
	public void init()
	{
		service=new MacServicesImpl();
		dao=new MacDaoImpl();
		service.setDao(dao);
	}
	
	
	@Test
	public void testgetScheduledPrograms() {

		ProgramsScheduled bean=new ProgramsScheduled();
		bean.setProgramName("Comp");
		bean.setSessionsPerWeek(4);
		
		
		
		
	}

}









