package com.cg.airreservation.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import oracle.net.aso.f;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.airreservation.dao.IAirlineDao;
import com.cg.airreservation.dao.AirlineDaoImpl;
import com.cg.airreservation.dao.ExecutiveDaoImpl;
import com.cg.airreservation.dao.IExecutiveDao;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.IAirlineService;
import com.cg.airreservation.service.AirlineServiceImpl;
import com.cg.airreservation.service.ExcecutiveServiceImpl;

public class AirlineTest {

	AirlineServiceImpl service;
	ExcecutiveServiceImpl exeService;
	IAirlineDao dao;
	IExecutiveDao exeDao;

	BookingBean book = new BookingBean();
	CustomerInfoBean cust = new CustomerInfoBean();
	FlightBean flight = new FlightBean();

	@Before
	public void init() {
		service = new AirlineServiceImpl();
		exeService = new ExcecutiveServiceImpl();
		dao = new AirlineDaoImpl();
		exeDao = new ExecutiveDaoImpl();
		service.setDao(dao);
		exeService.setDao(exeDao);
	}

	@Test
	public void testInsertDetails() throws AirlineException {

		cust.setCustId(100000);
		cust.setCustName("Allen");
		cust.setPassword("A@123fghj");
		cust.setMobileno("9856325632");
		cust.setEmail("abc@gmail.com");
		cust.setGender("male");
		cust.setDatOfBirth(LocalDate.now());

		assertEquals(true, service.insertdetails(cust));

	}

	@Test
	public void test1InsertDetails() throws AirlineException {

		
		cust.setCustName("Allen");
		cust.setPassword("A@123fghj");
		cust.setMobileno("9856325632");
		cust.setEmail("abc@gmail.com");
		cust.setGender("male");
		cust.setDatOfBirth(LocalDate.now());

		assertNotEquals(true, service.insertdetails(cust));

	}

	@Test
	public void testCheckCredentials() throws AirlineException {
		
		assertNotNull(service.checkcredentials("kis@capg.com", "Kis@12345"));

		

	}

	@Test
	public void test1CheckCredentials() throws AirlineException {
		assertNotNull(service.checkcredentials("abc@capg.com", "abc@12345"));


	}

	@Test
	public void testSearchFlight() throws AirlineException {

		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNotNull(service.searchFlight(date));

	}

	@Test
	public void test1SearchFlight() throws AirlineException {

		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNull(service.searchFlight(date));

	}

	@Test
	public void testInsertPassengerInfo() throws AirlineException {
		// book.setPnr(1006);
		book.setFlightNo("IA435");
		book.setCustId(102);
		book.setCustMobile("8596589656");
		book.setCustMail("abc@gmail.com");
		book.setPassengerNum(6);
		book.setClassType("a");
		book.setTotalFare(654564);
		book.setSource("Mumbai");
		book.setDest("Pune");

		String input = "06/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		book.setDateOfJourney(date);

		String input1 = "03:45:23";
		LocalTime now;
		DateTimeFormatter format1;
		format1 = DateTimeFormatter.ofPattern("HH:mm:ss");
		now = LocalTime.parse(input1, format1);
		book.setBookTime(now);

		assertEquals(true, service.insertPassengerInfo(book, flight));
	}

	@Test
	public void test1InsertPassengerInfo() throws AirlineException {
		// book.setPnr(1006);
		book.setFlightNo("IA435");
		book.setCustId(102);
		book.setCustMobile("8596589656");
		book.setCustMail("abc@gmail.com");
		book.setPassengerNum(6);
		book.setClassType("a");
		book.setTotalFare(654564);
		book.setSource("Mumbai");
		book.setDest("Pune");

		String input = "06/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		book.setDateOfJourney(date);

		String input1 = "03:45:23";
		LocalTime now;
		DateTimeFormatter format1;
		format1 = DateTimeFormatter.ofPattern("HH:mm:ss");
		now = LocalTime.parse(input1, format1);
		book.setBookTime(now);

		assertEquals(false, service.insertPassengerInfo(book, flight));
	}

	@Test
	public void testFlightOccupancyDetails() throws AirlineException {
		
		assertNotNull(exeService.flightOccupancyDetails("I123"));

	}

	@Test
	public void test1FlightOccupancyDetails() throws AirlineException {

		assertNull(exeService.flightOccupancyDetails("I123"));

	}

	@Test
	public void testInsertFlightInfo() throws AirlineException {
		flight.setFlightNum("ABC17");
		flight.setAirlineName("SpiceJet");
		flight.setAirportZip("345001");
		flight.setSource("Delhi");
		flight.setDestination("Pune");
		flight.setBusinessFare(1700);
		flight.setEconomyFare(1300);
		flight.setBusinessSeats(60);
		flight.setEconomySeats(80);
		flight.setArriveDate(LocalDate.now());
		flight.setDeptDate(LocalDate.now());
		flight.setArriveTime("05:25:23");
		flight.setDeptTime("14:22:21");

		assertEquals(true, exeService.insertFlightInfo(flight));

	}

	@Test
	public void testGenerateFlightList() throws AirlineException {

		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNotNull(exeService.generateFlightList(date));
	}

	@Test
	public void test1GenerateFlightList() throws AirlineException {

		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNull(exeService.generateFlightList(date));
	}

	@Test
	public void testFetchPassengerList() throws AirlineException {

		assertNotNull(exeService.fetchPassengerList("IA435"));

	}

	@Test
	public void test1FetchPassengerList() throws AirlineException {
		
		assertNull(exeService.fetchPassengerList("IA435"));

	}

	@After
	public void destroy() {
		service = null;
		exeService = null;
		dao = null;
		exeDao = null;
	}

}
