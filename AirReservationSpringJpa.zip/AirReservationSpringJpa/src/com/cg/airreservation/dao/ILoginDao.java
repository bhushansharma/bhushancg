package com.cg.airreservation.dao;

import com.cg.airreservation.entities.Customerinfo;
import com.cg.airreservation.exception.AirlineException;

public interface ILoginDao {

	public Customerinfo validateCredentials(Customerinfo bean) throws AirlineException;

}
