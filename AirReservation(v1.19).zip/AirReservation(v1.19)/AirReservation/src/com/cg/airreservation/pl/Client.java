package com.cg.airreservation.pl;

/**
 * <AirLine Reservation System>
 *	This class containing the main method and used to provide UI to end users
 */
import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.airreservation.dto.AirportBean;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.IAirlineService;
import com.cg.airreservation.service.AirlineServiceImpl;
import com.cg.airreservation.service.IExecutiveService;
import com.cg.airreservation.service.ExcecutiveServiceImpl;

public class Client {

	static IAirlineService service = new AirlineServiceImpl();
	static IExecutiveService exeService = new ExcecutiveServiceImpl();

	@SuppressWarnings("resource")
	/** main method */
	public static void main(String[] args)
	{
		// declaring variables
		int homeChoice = 0;
		int searchChoice = 0;
		// creating object of scanner
		Scanner scan = new Scanner(System.in);
		// first try(1) with resources
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)))
		{
			// starting of homepage do while(1)
			do
			{
				System.out.println("*********AirLine Reservation***********");
				boolean homeChoiceFlag = false;
				do
				{
					System.out.println("\nPlease Select Your Choice::\n");
					System.out.println("1. SignUp\n2.Login\n3.Exit");
					// Exception handling for input choice?????
					try
					{
						homeChoiceFlag = false;
						homeChoice = Integer.parseInt(reader.readLine());
					}
					catch (Exception e)
					{
						homeChoiceFlag = true;
						
					}
					if(homeChoice!=1 && homeChoice!=2 && homeChoice!=3)
					{
						System.out.println("Please enter valid choice..");
					}
				}
				while (homeChoiceFlag || homeChoice!=1 && homeChoice!=2 && homeChoice!=3);
				// start of homepage switch(1)
				switch (homeChoice)
				{
					case 1:
						signUp();
						break;
					case 2:
						login();
						break;
					case 3:
						System.out.println("Thank you..Exit...");
						System.exit(0);
						break;
					default:
						System.out.println("Not valid choice..Please Enter valid choice");
				} // end of homepage switch(1)

				/*
				 * start of do while(2) for handling any other option in home
				 * page
				 */
				boolean searchChoiceFlag = false;
				do
				{
					System.out.println("\nWant to return,HomePage Press 1-Yes & 0-No");
					try
					{
						searchChoiceFlag = false;
						searchChoice = Integer.parseInt(reader.readLine());
					}
					catch(Exception e)
					{
						searchChoiceFlag = true;
						System.out.println("\nPlease enter a valid choice i.e (1 or 0)");
					}
					if(searchChoice != 1 && searchChoice != 0)
						System.out.println("\nNot valid option.Please select correct option.");
				}while(searchChoice != 1 && searchChoice != 0 || searchChoiceFlag);
				/* end of do while(2) for handling any other option in home page */
				
			}while(searchChoice != 0); // end of do while page(1)
				
		}// end of try
		catch(Exception e)
		{ 
			System.out.println(e.getMessage());
		}
	} // end of main method

	/** SignUp method */
	private static void signUp() throws IOException, AirlineException
	{
		/* start of sign up method for customer */
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Welcome To AirLine Reservation.\n Please Enter Your Details");
		boolean custNameFlag = false;
		String name;	//customer name
		String mail;	//customer email
		boolean dateFlag = false; //declared variable for date of birth validations 
		LocalDate date;		//to store date entered by the customer in the mention format and parse it to local date
		String input;		//variable to store dob by the customer
		DateTimeFormatter format;
		String gender;	//variable to store customer gender when entered
		boolean mobileFlag = false;		//flag to check mobile number entered by the customer is valid or not
		String mobile;		//variable to store mobile number entered by the customer

		do
		{ // start of do while for name exception(3)
			System.out.println("Enter Your Name :");
			name = reader.readLine();
			custNameFlag = service.validateUser(name);
			if (!custNameFlag)
				System.out.println("Invalid User name. First letter should be capital for First Name and Last Name and should have maximum length of 24 for each..");
		}
		while (!custNameFlag); // end of do while(3) for name exception
		
		boolean custMailFlag = false;
		do
		{ // start of do while for mail exception(4)
			System.out.println("Enter Your Mail Id :");
			mail = reader.readLine();
			custMailFlag = service.validateEmail(mail);
			if (!custMailFlag)
				System.out.println("Invalid Email id. please enter valid email (abc@gmail.com)..");
		}
		while (!custMailFlag); // end of do while for mail exception(4)
		
		do
		{ 			// start of do while for date of birth after todays date exception(5)
			boolean checkFlag;
			
			do
			{ 		// start of do while for date of birth not in format exception(6)
				format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				System.out.println("Enter Date of Birth (dd/MM/yyyy) :");
				input = reader.readLine();
				checkFlag = service.checkDate(input);
				if (!checkFlag)
					System.out.println("Enter date in given format");
			}
			while(!checkFlag); // end of do while for date of birth not in format exception(6)
			
			date = LocalDate.parse(input, format);
			dateFlag = service.validateDate(date);
			if (!dateFlag)
				System.out.println("Please Enter Valid Date of Birth. Date Should be before today's Date");
		}
		while (!dateFlag); // end of do while for date of birth after todays date exception(5)
		
		do
		{ 		// start of do while for gender exception(7)
			System.out.println("Enter Gender (Male/Female) :");
			gender = reader.readLine();
			gender = gender.toUpperCase();
			if (!gender.equals("MALE") && !gender.equals("FEMALE"))
				System.out.println("Please enter either Male or Female\n");
		}
		while (!gender.equals("MALE") && !gender.equals("FEMALE"));		/* end of do while for gender exception (7) */
		
		do
		{ 		// start of do while for mobile number exception(8)
			System.out.println("Enter Mobile Number :");
			mobile = reader.readLine();
			mobileFlag = service.validateMobile(mobile);
			if (!mobileFlag)
				System.out.println("Not valid mobile number. Mobile Number must start with 7,8 or 9 and should be 10 digit number");
		}
		while (!mobileFlag); // end of do while for mobile number exception(8)
		
		String password = null;		//password field can not be blank
		boolean flag = false;
		boolean passFlag = false;
		
		while (!flag || !passFlag)
		{ 							/*
									 * start of loop while unless password and
									 * re-enter not match and password is in
									 * given pattern
									 */
			System.out.println("Enter Your Password :");
			password = reader.readLine();
			passFlag = service.validatePass(password);
			
			if (!passFlag)
			{ // check if password is in pattern
				System.out.println("Password Not Match! Your password must contain an uppercase letter, a lowercase letter, a special char and a number.");
				//passFlag = true;
			} // end of if password is in pattern
			else
			{ // if password is in pattern
				//passFlag = false;
				System.out.println("ReEnter Your Password :");
				String rePassword = reader.readLine();
				
				if (password.equals(rePassword))
				{ // if password and repassword
													// match
					flag = true;
				}
				else
					// else if password and repassword not match
					System.out.println("Password mismatch.");
			} // end of else if password is in pattern
		} // end of loop while unless password and re-enter not match and password is in given pattern
		
		CustomerInfoBean custBean = new CustomerInfoBean();
		custBean.setCustName(name);
		custBean.setEmail(mail);
		custBean.setDatOfBirth(date);
		custBean.setGender(gender);
		custBean.setMobileno(mobile);
		custBean.setPassword(password);
		custBean.setUserType("customer");
		
		boolean inserFlag = service.insertdetails(custBean);
		if(inserFlag)
		{ 		// if data inserted successfully
			System.out.println("****Successfully Registered. Thank You!!*****");
		}
		else
		{ 		// else if data not inserted
			System.out.println("Unable to register. Please Register again. Thank You!!");
		}
		
	} // end of sign up method

	/** method for admin, executive and customer login */
	private static void login() throws IOException, AirlineException
	{
		boolean custValidate;
		
		do
		{ // start of do(9) while admin is invalid and want to try again
			custValidate = false;
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("***Login***");
			System.out.println("Enter Your Email :");
			String loginEmail = reader.readLine();
			System.out.println("Enter Password :");
			String loginPass = reader.readLine();
			/*if(console==null)
				System.exit(0);
			String loginPass =console.readPassword().toString();*/
			
			CustomerInfoBean loginBean = service.checkcredentials(loginEmail,loginPass);
			if (loginBean != null)
			{ 		// start of if login is valid
				System.out.println("\nLogin Successful\n");
				switch (loginBean.getUserType()) { // start of switch for
													// different role
				case "customer":

					customer(loginBean);
					break;

				case "admin":
					admin(loginBean);
					break;

				case "executive":
					executive(loginBean);
					break;

				default:
					System.out.println(" Authentication failed");
				} // end of switch for different role
			} // end of if login is valid
			else { // start if login is invalid
				System.out.println("Invalid login..");
				boolean adminChoiceFlag = false;
				boolean invalidChoice = false;
				do
				{	 // start of do while for invalid choice
					int loginChoice = 0;
					System.out.println("1.Login 2.exit");
					try
					{
						invalidChoice = false;
						adminChoiceFlag = false;
						loginChoice = Integer.parseInt(reader.readLine());
					}
					catch (Exception e)
					{
						adminChoiceFlag = true;
					}
					if (loginChoice == 1)
					{
						custValidate = true;
						invalidChoice = true;
						
					}
					else if (loginChoice == 2)
						break;
					
					else
						System.out.println("Please Enter valid choice..");
				} 
				while(!invalidChoice || adminChoiceFlag); // end of do while for invalid choice
			} // end if login is invalid
		} while (custValidate); // end of do(9) while admin is invalid and want to try again
	}

	// after customer login
	private static void customer(CustomerInfoBean loginBean)throws IOException, AirlineException 
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		Scanner scan = new Scanner(System.in);
		int option = 0;
		int logoutOption=0;
		
		do
		{ 	// start of do while if customer want to search another flight
			int count = 1;
			
			System.out.println("Hello " + loginBean.getCustName());
			System.out.println("\nSearch your Flight Here\n");
			
			DateTimeFormatter formatDoj = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate journeyDate;
			String dateJourney;
			boolean checkByDate = false;
			int flightCount = 0;
			boolean validateByDate=false;
			do
			{ 	// start of do while for floghtcount is 0
				do{
				do 
				{ 	// start of do while for wrong date of journey
					System.out.println("Enter date of journey in the form dd/mm/yyyy");
					dateJourney = reader.readLine();
					
					checkByDate = service.checkDate(dateJourney);
					
					if (!checkByDate)
						System.out.println("\nPlease Enter valid Date in format dd/mm/yyyy");
					
				} 
				while(!checkByDate); // end of do while for wrong date of journey
				
				journeyDate = LocalDate.parse(dateJourney, formatDoj);
				
					validateByDate=exeService.validateDate(journeyDate);
					if(!validateByDate)
					{
						System.out.println("\n Date must be today's date or date after today");
					}
				}while(!validateByDate);
				ArrayList<FlightBean> flightList = service.searchFlight(journeyDate);
				ArrayList<FlightBean> noSeatList = new ArrayList<FlightBean>();
				ArrayList<FlightBean> seatList=new ArrayList<FlightBean>();
				if (flightList.size() != 0) 
				{ 	// start of if Flight list is not empty for given date
					
					for (FlightBean flightBean : flightList) 
					{ // start of for loop to display Flights for given date
						
						if (flightBean.getRemainingBusSeats() > 0 || flightBean.getRemainingEcoSeats() > 0) 
						{
							flightCount++;
							
							System.out.print(count++ + ") ");
							System.out.println("\nFlight Number: \t"+ flightBean.getFlightNum());
							System.out.println("Source city: \t\t"+ flightBean.getSource());
							System.out.println("Destination city: \t"+ flightBean.getDestination());
							System.out.println("Departure Time: \t"+ flightBean.getDeptTime());
							seatList.add(flightBean);
						} 
						else 
						{
							noSeatList.add(flightBean);
						}
					}// end of for loop to display Flights for given date
					
					if (flightCount == 0) 
					{ 	// start of if flight is avilable for given date but no seats available
						
						System.out.println(" Not available. Please Select another date of journey..");
						System.out.println("\n Seats Full in below Flights.. Sorry...");
						
						for (FlightBean beanFlight : noSeatList) 
						{
							System.out.println("\nFlight Number: \t"+ beanFlight.getFlightNum());
							System.out.println("Airline Name: \t"+ beanFlight.getAirlineName());
							System.out.println("source city: \t"+ beanFlight.getSource());
							System.out.println("Destination City:\t "+ beanFlight.getDestination());
						}
					} // end of if;flight is available for given date but no seats available
				
					else 
					{ 	// start of else;flight is available for given date and seats also available
						boolean pathFlag = false;
						int path = 0;
						boolean pathChoiceFlag = false;
						
						do
						{ 		// start of do while;if path(flight select) option is not entered correct
							System.out.println("\nSelect your journey path :");
							try
							{
								pathChoiceFlag = false;
								path = Integer.parseInt(reader.readLine());
							}
							catch(Exception e)
							{
								pathChoiceFlag = true;
							}
							if (path < 1 || path > count)
							{
								System.out.println("No such option.. please select valid option..");
								pathFlag = true;
							} 
							else
								pathFlag = false;
						} 
						while (pathFlag); // end of do while if path(flight select) option is not entered correct
						
						FlightBean fBean = seatList.get(path - 1);
						
						System.out.println("Flight Number: \t\t\t\t"+ fBean.getFlightNum());
						System.out.println("Source: \t\t\t\t" + fBean.getSource());
						System.out.println("Destination:\t\t\t\t "+ fBean.getDestination());
						System.out.println("Seats available in Business Class: \t"+ fBean.getRemainingBusSeats());
						System.out.println("Fare for Business Class: \t\t"+ fBean.getBusinessFare());
						System.out.println("Seats available in Economy Class:\t "+ fBean.getRemainingEcoSeats());
						System.out.println("Fare for Economy Class: \t\t"+ fBean.getEconomyFare());
						System.out.println("Date of Departure: \t\t\t"+ fBean.getDeptDate());
						System.out.println("Time of Departure from Source: \t\t"+ fBean.getDeptTime());
						System.out.println("Date of Arrival: \t\t\t"+ fBean.getArriveDate());
						System.out.println("Time of Arrival to Destination: \t"+ fBean.getArriveTime());
						
						System.out.println("\nSelect class in which you want to travel: (A)Business Class  (B)Economy Class ");
						
						boolean typeFlag;
						int seats = 0;
						String classType;	// select class type
						
						do
						{ 	// start of do while;for selecting wrong class type
							typeFlag = false;
							System.out.println("\nEnter your choice: (A/B)");
							classType = scan.next();
							classType = classType.toUpperCase();
							double fare;
							
							if(classType.equals("A"))
							{
								seats = fBean.getRemainingBusSeats();
								fare = fBean.getBusinessFare();
							}
							else if(classType.equals("B")) 
							{
								seats = fBean.getRemainingEcoSeats();
								fare = fBean.getEconomyFare();
							} 
							else
							{
								typeFlag = true;
								System.out.println("Class type not exist");
							}
						} 
						while (typeFlag); // end of do while for selecting wrong classtype
						
						boolean seatCount;
						int numOfSeats = 0;
						boolean seatFlag = false;
						BookingBean bookBean = null;
						// check entered number of seat less than available
						boolean bookSeatFlag = false;
						
						do
						{ 	// start of do while if entered seats are 0 or greater than available seats
							seatCount = false;
							System.out.println("\nEnter Number of seats you want to book: ");
							try
							{
								bookSeatFlag = false;
								numOfSeats = Integer.parseInt(reader.readLine());
							}
							catch (Exception e)
							{
								bookSeatFlag = true;
							}
							
							if (numOfSeats <= seats && numOfSeats > 0) 
							{
								// start of if entered number seats are greater than 0 and more than available
								bookBean = new BookingBean();
								
								bookBean.setFlightNo(fBean.getFlightNum());
								bookBean.setClassType(classType);
								bookBean.setDateOfJourney(fBean.getDeptDate());
								bookBean.setDest(fBean.getDestination());
								bookBean.setSource(fBean.getSource());
								bookBean.setBookTime(LocalTime.now());
								bookBean.setCustId(loginBean.getCustId());
								bookBean.setCustMail(loginBean.getEmail());
								bookBean.setCustMobile(loginBean.getMobileno());
								bookBean.setClassType(classType);
								bookBean.setPassengerNum(numOfSeats);
								double totalFare = service.calFare(bookBean,fBean);
								System.out.println("\n0.12% service tax applied.");
								System.out.println("\nTotal Fare For your Trip is "+ totalFare);
							}// end of if entered number seats are greater than 0 and more than available
							
							else if (numOfSeats > seats)
							{
								seatCount = true;
								System.out.println("\nEntered seats exceeds the no of seats available ");
							}
							else if (numOfSeats == 0) 
							{
								seatCount = true;
								System.out.println("\nAt least one seat need to be booked ");
							} 
							else
							{
								System.out.println("\nPlease enter a valid choice ");
							}
						}
						while (seatCount); // end of do while if entered seats are 0 or greater than available seats
						boolean ConfirmFlag = false;
						boolean logoutFlag=false;
						do
						{ 		// start of do while if selected option is not correct
							System.out.println("Select your option \n (1)Book \n (2)Search another flight \n (3)Logout");
							try 
							{
								ConfirmFlag = false;
								option = Integer.parseInt(reader.readLine());
							}
							catch (Exception e)
							{
								ConfirmFlag = true;
								option=0;
							}
							if (option == 1)
							{		 // start of if book(1) option is selected
								seatFlag = service.insertPassengerInfo(bookBean, fBean);
								if (seatFlag)
								{	 // start of if passenger info inserted
									System.out.println("** Thank You For choosing us.Your Booking Confirmed.**");
									System.out.println("Your PNR Number is: \t"+ bookBean.getPnr());
									System.out.println("Flight Number :\t\t"+ bookBean.getFlightNo());
									System.out.println("Customer Email :\t"+ bookBean.getCustMail());
									System.out.println("Number of seats booked :"+ bookBean.getPassengerNum());
									System.out.println("Total Fare :\t\t"+ bookBean.getTotalFare());
								} // end of if;passenger info inserted
								
								else
								{
									System.out.println("Sorry..Booking not Successful.Please Try Again");
								}
								do{
								System.out.println("\n1.Book another flight\n2.Logout");
								try{
									logoutFlag=false;
								logoutOption=Integer.parseInt(reader.readLine());
								}
								catch(Exception e)
								{
									logoutFlag=true;
								}
								if(logoutOption!=1 && logoutOption!=2)
									System.out.println("Please enter valid choice (1 or 2)");
								}while(logoutOption!=1 && logoutOption!=2 || logoutFlag);
							} // end of if book(1) option is selected
							/* if exit(3) option is selected */
							else if (option == 3)
							{
								System.exit(0);
							}
							else if (option == 2) 
							{
							}
							else
							{
								option = 0;
								System.out.println("Please enter Valid Option (1,2,3).");
							}
						}
						while (option == 0); // end of do while if selected option is not correct
					}// end of else flight is avilable for given date and seats also available
				} // end of if Flight list is not empty for given date
				else 
				{
					System.out.println("Not valid date of journey");
				}
			}
			while (flightCount == 0); // end of do while for flight count is 0
		}while (option == 2 ||logoutOption==1); // end of do while if customer want to search another flight
	}

	// after admin login
	private static void admin(CustomerInfoBean loginBean) throws IOException,AirlineException 
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		Scanner scan = new Scanner(System.in);
		System.out.println("***Welcome To AirLine Rservation***");
		System.out.println("\nHello " + loginBean.getCustName());
		
		int adminChoice = 0;
		boolean adminOptionFlag = false;
		boolean adminChoiceFlag = false;
		
		do
		{ 		// start of do while if admin want to continue
			do
			{ // start of do while if admin enter character choice for given options
				System.out.println("\nEnter your Option :");
				System.out.println("1.Add new Flight\n2.View Flight List By Date\n3.View Booking List By Flight Number\n4.View Passenger List By Flight Number\n5.Logout ");

				try 
				{
					adminOptionFlag = false;
					adminChoice = Integer.parseInt(reader.readLine());
				} 
				catch (Exception e)
				{
					adminOptionFlag = true;
					System.out.println("\nPlease enter valid choice.");
				}
			} 
			while (adminOptionFlag); // end of do while if admin enter character choice for given options
			
			switch (adminChoice)
			{ 	// start of switch for different option

			case 1:
				addNewFlight();
				break;

			case 2:
				viewListByDate();
				break;

			case 3:
				viewBookingList();
				break;

			case 4:
				viewPassengerList();
				break;

			case 5:
				System.exit(0);

			default:
				System.out.println("Not valid value");
			}	// switch end
			do 
			{ 	// start of do while if admin enter wrong choice (entered character)
				System.out.println("\nDo you want to continue 1.yes 0.No");
				try
				{
					adminChoiceFlag = false;
					adminChoice = Integer.parseInt(reader.readLine());
				}
				catch (Exception e)
				{
					adminChoiceFlag = true;
					/* System.out.println("Please enter a valid option"); */
				}
				
				if (adminChoice != 1 && adminChoice != 0)
					System.out.println("\nPlease enter valid choice 1 or 0");
			} 
			while (adminChoice != 1 && adminChoice != 0 || adminChoiceFlag); // end of do while if admin enter wrong choice (entered character)
		}
		while (adminChoice == 1); // end of do while if admin want to continue
	}

	// after executive login
	private static void executive(CustomerInfoBean loginBean)throws AirlineException 
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		Scanner scan = new Scanner(System.in);
		int executiveOption;
		
		System.out.println("***Welcome To AirLine Rservation***");
		System.out.println("\nHello " + loginBean.getCustName());
		
		do
		{ 			// start of do while if executive want to search another flight
			executiveOption = 0;
			boolean exeFlag = false;
			System.out.println("**Check seats availability in flights based on flight number**");
			System.out.println("\nEnter Flight Number : ");
			String flightNumber = scan.next();
			FlightBean flightBean = exeService.flightOccupancyDetails(flightNumber);
			
			if (flightBean != null) 
			{ 			// if entered flight number is available
				System.out.println("\nFlight Number :"+ flightBean.getFlightNum());
				System.out.println("AirLine Name :"+ flightBean.getAirlineName());
				System.out.println("Total Number Of Buisness Seats :"+ flightBean.getBusinessSeats());
				System.out.println("Remaining Number Of Business Seats :"+ flightBean.getRemainingBusSeats());
				System.out.println("Total Number Of Economy Seats :"+ flightBean.getEconomySeats());
				System.out.println("Remaining Number Of Economy Seats :"+ flightBean.getRemainingEcoSeats());
			}
			else
			{ 		// else if flight number not available
				System.out.println("\nFlight Number not exist.. Please enter valid Flight Number");
			}
			do
			{ 		// start of while option is other than 1,2
				System.out.println("\n1.Search another flight \n2.Logout");
				try
				{
					exeFlag = false;
					executiveOption = Integer.parseInt(reader.readLine());
				}
				catch (Exception e) 
				{
					exeFlag = true;
				}
				if (executiveOption != 1 && executiveOption != 2)
					System.out.println("Sorry.. Please Enter correct choice(1 or 2).");
				if(executiveOption==2)
					System.exit(0);
			}
			while (executiveOption != 1 && executiveOption != 2 || exeFlag); // end of while option is other than 1,2
		}
		while (executiveOption == 1); // end of do while if executive want to search another flight
	}


	// add new flight
	private static void addNewFlight() throws IOException, AirlineException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		Scanner scan = new Scanner(System.in);
		int addFlightChoice = 0;
		String flightNum;
		String airName;
		String zipcode;
		Double businessClassFare = 0.0;
		Double economyClassFare = 0.0;
		int businessClassSeats = 0;
		int economyClassSeats = 0;
		do {					//start of do while if admin want to add another flight
			boolean flightNumberFlag = false;
			boolean flightNameFlag = false;
			boolean zipCodeFlag = false;
			boolean bussFareFlag = false;
			boolean ecoFareFlag = false;
			boolean fareFlag = false;
			boolean ecoFlag = false;
			boolean bussSeatFlag = false;
			boolean ecoSeatFlag = false;
			boolean arriveDateFlag = false;
			boolean departDateFlag = false;
			do {		//do loop starts for flight number (for admin)
				System.out.println("Enter Flight Number: ");
				flightNum = scan.next();
				flightNumberFlag = service.validateFlightNumber(flightNum);
				if (!flightNumberFlag)
					System.out
							.println("Invalid flight number! please use only alphanumeric to insert flight number");
			} while (!flightNumberFlag);	//end of do while;when wrong flight number is entered by the admin 
			
			boolean zipFlag=true;
			AirportBean airportZip=null;
		
			ArrayList<AirportBean> airportList=exeService.fetchAirportList();
			System.out.print("Airport Zip\t\t");
			System.out.println("Airport Name");
			for(AirportBean airBean:airportList)
			{
				
				System.out.print(airBean.getAirportZip()+"\t\t");
				System.out.println(airBean.getAirportName()+", "+airBean.getAirportLocation());
			}
			do {			//start of do loop for entering airport zipcode (by admin)
				
				
				System.out.println("Enter Airport Zipcode: ");
				zipcode = reader.readLine();
				
				for(AirportBean airBean:airportList)
				{
					if(zipcode.equals(airBean.getAirportZip()))
					{
						zipFlag=true;
						airportZip=airBean;
						break;
					}
					else
						zipFlag=false;
						
				}
				
				if(!zipFlag)
				{
					System.out.println("Please enter valid zip code from above list");
				}
				
				
				
			} while ( !zipFlag);		//end of do while;when wrong airport zipcode is entered by the admin
			
			
			
			
			
			String destinationCity;
			do{				//do loop starts for entering destination city(by admin)
			System.out.println("Enter Destination City: ");
			 destinationCity = reader.readLine();
			 if(!exeService.validateSource(destinationCity))
				 System.out.println("Please Enter in character");
			}while(!exeService.validateSource(destinationCity));	//end of do while;when wrong destination city is entered by admin
			
			do {		//do loop for entering fare of business class
				System.out.println("Enter the fare for Business Class: ");
				try {							//try block for catching exception when business fare is entered other than digits
					fareFlag = false;
					businessClassFare = Double.parseDouble(reader.readLine());

				} catch (Exception e) {			//catch block for catching exception when above fare is entered other than digits
					fareFlag = true;
					System.out.println("Please enter only digits");
				}
				bussFareFlag = service.validateFlightAmount(businessClassFare);		//method is called for validating business class fare
				if (!bussFareFlag)
					System.out
							.println("Invalid fare amount! please enter valid amount in following format(8,2)");
			} while (!bussFareFlag || fareFlag);	//end of do while;for re-entering business fare 
		
			do {
				System.out.println("Enter the fare for Economy Class: ");
				try {
					ecoFlag = false;
					economyClassFare = Double.parseDouble(reader.readLine());
				} catch (Exception e) {
					ecoFlag = true;
					System.out.println("Please enter only digits");
				}
				ecoFareFlag = service.validateFlightAmount(economyClassFare);
				if (!ecoFareFlag)
					System.out
							.println("Invalid fare amount! please enter valid amount in following format(8,2)");
			} while (!ecoFareFlag || ecoFlag);
			do {		//do loop starts for entering seats of business class
				try {
					bussSeatFlag = false;
					System.out
							.println("Enter the number of seats for Business Class: ");
					businessClassSeats = Integer.parseInt(reader.readLine());
				} catch (Exception e) {
					bussSeatFlag = true;
					System.out
							.println("please enter a valid input(only digits)");
				}
			} while (bussSeatFlag); 		//end of do while;when business seats are entered other than digits
			do {				//do loop starts for entering economy class seats
				try {
					ecoSeatFlag = false;
					System.out
							.println("Enter the number of seats for Economy Class: ");
					economyClassSeats = Integer.parseInt(reader.readLine());
				} catch (Exception e) {
					ecoSeatFlag = true;
					System.out
							.println("please enter a valid input(only digits)");
				}
			} while (ecoSeatFlag);		//end of do while loop;when economy seats are entered other than digits
			LocalDate schDepartureDate1 = null;
			DateTimeFormatter formatDoj = DateTimeFormatter		//scheduled departure date is being formatted in dd/MM/yyyy 
					.ofPattern("dd/MM/yyyy");
			do {		//do loop starts for validating scheduled departure date should after today's date
				do{					//do loop starts for scheduled departure date
				System.out
						.println("Enter Scheduled Departure Date (dd/MM/yyyy): ");
				String schDepartureDate = reader.readLine();
				departDateFlag = service.checkDate(schDepartureDate);
				if (!departDateFlag)
					System.out.println("Please enter valid date format");
				else {
					schDepartureDate1 = LocalDate.parse(schDepartureDate,
							formatDoj);		//when scheduled departure date is entered in the format dd/MM/yyyy is type cast to local date
				}
				}while(!departDateFlag);	//end of do while ;for scheduled departure date
				if(!exeService.validateDate(schDepartureDate1))
					System.out.println("Entered date should be after today's date");
			} while (!exeService.validateDate(schDepartureDate1));	//end of do while loop;when scheduled departure date is todays date
			LocalDate schArrivalDate1 = null;
			do {		//do loop starts for validating scheduled arrival date
				do{		//do loop starts for scheduled arrival date
				System.out
						.println("Enter Scheduled Arrival Date (dd/MM/yyyy): ");
				String schArrivalDate = reader.readLine();
				arriveDateFlag = service.checkDate(schArrivalDate);
				if (!arriveDateFlag)
					System.out.println("Please enter valid date format");
				else {
					schArrivalDate1 = LocalDate
							.parse(schArrivalDate, formatDoj);
				}
				}while(!arriveDateFlag);	//end of do while loop for scheduled arrival date
				if(!exeService.validateDate(schArrivalDate1))
					System.out.println("Entered date should be after today's date");

			} while (!exeService.validateDate(schArrivalDate1));	//end of do while loop when scheduled arrival date is before todays date
			
			boolean timeFlag=true;
			String arrivalTime;
			do{
			System.out.println("Enter Arrival Time in format (hh:mm): ");
			 arrivalTime = reader.readLine();
			timeFlag=exeService.validateTime(arrivalTime);
			if(!timeFlag)
				System.out.println("Please enter valid time in given format");
			}while(!timeFlag);
			String departureTime;
			boolean deptTimeFlag=true;
			do{
			System.out.println("Enter Departure Time in format (hh:mm): ");
			 departureTime = reader.readLine();
			deptTimeFlag=exeService.validateTime(departureTime);
			if(!deptTimeFlag)
				System.out.println("Please enter valid time in given format");
			}while(!deptTimeFlag);
			FlightBean newFlightBean = new FlightBean();
			newFlightBean.setFlightNum(flightNum);
			newFlightBean.setAirlineName(airportZip.getAirportName());
			newFlightBean.setAirportZip(zipcode);
			newFlightBean.setSource(airportZip.getAirportLocation());
			newFlightBean.setDestination(destinationCity);
			newFlightBean.setBusinessFare(businessClassFare);
			newFlightBean.setEconomyFare(economyClassFare);
			newFlightBean.setBusinessSeats(businessClassSeats);
			newFlightBean.setEconomySeats(economyClassSeats);
			newFlightBean.setDeptDate(schDepartureDate1);
			newFlightBean.setArriveDate(schArrivalDate1);
			newFlightBean.setArriveTime(arrivalTime);
			newFlightBean.setDeptTime(departureTime);
			boolean adminFlag = exeService.insertFlightInfo(newFlightBean);
			if (adminFlag) {
				System.out.println(("Flight added successufully.."));
			} else {
				System.out.println("Unable to insert new Flight");
			}
			boolean addFlightFlag = false;
			boolean addFlag = false;
			do {
				System.out
						.println("Do you want to add another flight 1.Yes  0.No");
				try {
					addFlag = false;
					addFlightChoice = Integer.parseInt(reader.readLine());
				} catch (Exception e) {
					addFlag = true;
					System.out
							.println("Invalid choice!please choose a correct option");
				}
				if (addFlightChoice != 0 || addFlightChoice != 1)
					addFlightFlag = false;
				else
					addFlightFlag = true;
			} while (!addFlightFlag && addFlag);
			
		} while (addFlightChoice == 1);		//end of do while if admin want to add another flight
	}

	// List By date
		private static void viewListByDate() throws IOException, AirlineException
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			Scanner scan = new Scanner(System.in);
			DateTimeFormatter listByDate = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			boolean adminListFlag = false;
			LocalDate flightDate;
			String dateJourney;
			int dateListChoice = 0;
			
			do 
			{
				do
				{
					System.out.println("Enter date of journey in the form dd/mm/yyyy");
					dateJourney = reader.readLine();
					adminListFlag = service.checkDate(dateJourney);
					if (!adminListFlag)
						System.out.println("Not valid date..Please enter date in format specified");
				}
				while (!adminListFlag);
				
				flightDate = LocalDate.parse(dateJourney, listByDate);
				ArrayList<FlightBean> flightList = exeService.generateFlightList(flightDate);
				int count = 1;
				
				if (flightList.size() != 0)
				{
					for (FlightBean flightBean : flightList) 
					{
						System.out.println(count++ + ") ");
						System.out.println("Flight Number: "+ flightBean.getFlightNum());
						System.out.println("Source city " + flightBean.getSource());
						System.out.println("Destination city "+ flightBean.getDestination());
						System.out.println("Departure Date :"+ flightBean.getDeptDate());
						System.out.println("Departure Time: "+ flightBean.getDeptTime());
						System.out.println();
					}
				}
				else
					System.out.println("No Flight exist for this date");
				
				boolean dateListFlag = false;
				boolean dateChoiceFlag = false;
				
				do
				{
					System.out.println("Do you want to search another flight 1.Yes  0.No");
					try
					{
						dateChoiceFlag = false;
						dateListChoice = Integer.parseInt(reader.readLine());
					} 
					catch (Exception e) 
					{
						dateChoiceFlag = true;
						System.out.println("please enter a valid option");
					}
					if (dateListChoice != 0 && dateListChoice != 1)
					{
						dateListFlag = false;
						System.out.println("please enter a valid option");
					}
					else
						dateListFlag = true;
				}
				while (!dateListFlag || dateChoiceFlag);
			}
			while (dateListChoice == 1);
		}

		// booking list by flight number
		private static void viewBookingList() throws AirlineException 
		{
			Scanner scan = new Scanner(System.in);
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			FlightBean flightBean = null;
			
			System.out.println("* You can check seats availability in flights based on flight number.");
			int flightListChoice = 0;
			
			do
			{
				//do {
					System.out.println("Enter Flight Number : ");
					String flightNumber = scan.next();
					flightBean = exeService.flightOccupancyDetails(flightNumber);
					if (flightBean != null)
					{
						System.out.println("Flight Number :"+ flightBean.getFlightNum());
						System.out.println("AirLine Name :"+ flightBean.getAirlineName());
						System.out.println("Total Number Of Buisness Seats :"+ flightBean.getBusinessSeats());
						System.out.println("Remaining Number Of Business Seats :"+ flightBean.getRemainingBusSeats());
						System.out.println("Total Number Of Economy Seats :"+ flightBean.getEconomySeats());
						System.out.println("Remaining Number Of Economy Seats :"+ flightBean.getRemainingEcoSeats());
					} 
					else
						System.out.println("No such flight number exist..Please Enter valid Flight number.");
				//} while (flightBean == null);
				boolean flightListFlag = false;
				boolean flightChoiceFlag = false;
				
				do 
				{
					System.out.println("Do you want to search another flight 1.Yes  0.No");
					try
					{
						flightChoiceFlag = false;
						flightListChoice = Integer.parseInt(reader.readLine());
					}
					catch (Exception e) 
					{
						flightChoiceFlag = true;
						System.out.println("please enter a valid option");
					}
					if (flightListChoice != 0 && flightListChoice != 1)
					{
						System.out.println("please enter a valid option");
						flightListFlag = false;
					}
					else
						flightListFlag = true;
				}
				while (!flightListFlag || flightChoiceFlag);
			}
			while (flightListChoice == 1);
		}

		// Passenger list by flight number

		private static void viewPassengerList() throws AirlineException 
		{
			Scanner scan = new Scanner(System.in);
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("* You can check passenger list in flight based on flight number.");
			int passengerListChoice = 0;
			boolean passengerListFlag = false;
			boolean passengerChoiceFlag = false;
			
			do
			{
				System.out.println("Enter Flight Number : ");
				String flyNum = scan.next();
				ArrayList<BookingBean> bookList = exeService.fetchPassengerList(flyNum);
				if (bookList.size() != 0) 
				{
					for (BookingBean bean : bookList) 
					{
						System.out.println("Customer Id :" + bean.getCustId());
						System.out.println("Customer Email :" + bean.getCustMail());
						System.out.println("Customer Mobile :" + bean.getCustMobile());
						System.out.println(("Number of Seats booked :" + bean.getPassengerNum()));
					}
				}
				else
					System.out.println("No Such Flight Exist or There are no passengers for this flight");

				do 
				{
					passengerListFlag=true;
					System.out.println("Do you want to search another flight 1.Yes  0.No");
					try 
					{
						
						passengerChoiceFlag = false;
						passengerListChoice = Integer.parseInt(reader.readLine());
					}
					catch (Exception e) 
					{
						passengerChoiceFlag = true;
						System.out.println("please choose a valid option");
					}
					if (passengerListChoice != 0 && passengerListChoice != 1)
					{
						System.out.println("please choose a valid option");
						passengerListFlag = false;
					}
						
				}
				while (!passengerListFlag || passengerChoiceFlag);
			} 
			while (passengerListChoice == 1);
		}
}
