package com.capgemini.bms.dao;

import java.util.ArrayList;

import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.bean.User;
import com.capgemini.bms.exception.HotelException;

public interface CustomerDao {
	boolean registerUser(User uBean) throws HotelException;
	String validate(String username, String password) throws HotelException;
	ArrayList<Hotel> getHotelList(String city) throws HotelException;
	ArrayList<RoomDetail> searchRooms(String roomTypes, long minPrice,long maxPrice, int hotelId) throws HotelException;
	boolean bookRoom(BookingDetail bdBean) throws HotelException;
	User getUser(String username, String password) throws HotelException;
	ArrayList<BookingDetail> getBookings(int userId) throws HotelException;
	ArrayList<BookingDetail> getAllBookings(int userId) throws HotelException;
	boolean cancelBooking(int bookingId) throws HotelException;
	Hotel getHotelById(int hotelId, String city) throws HotelException;

}
