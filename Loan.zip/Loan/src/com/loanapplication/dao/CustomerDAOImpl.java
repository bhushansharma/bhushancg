package com.loanapplication.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.loanapplication.entities.CustomerDetail;
import com.loanapplication.entities.Loanapplication;
import com.loanapplication.entities.Loanprogramsoffered;
import com.loanapplication.exception.LoanException;
import com.loanapplication.logger.MyLogger;

@Repository
public class CustomerDAOImpl implements CustomerDAO{

	@PersistenceContext
	private EntityManager entityManager;
	
	Logger logger = MyLogger.getLoggerInstance();
	
	
	/* Show all the description of the loan program selected by the customer
	 * @see com.loanapplication.dao.CustomerDAO#getLoanProgramDescription(long)
	 */
	@Override
	public Loanprogramsoffered getLoanProgramDescription(long prgmId)
			throws LoanException {
		// TODO Auto-generated method stub
		Loanprogramsoffered loanDesc=entityManager.find(Loanprogramsoffered.class, prgmId);
		if(loanDesc!=null)
		{
			logger.info("Loan Programs are Successfully Retrieved " + loanDesc);
		}
		else
		{	
			logger.error("Loan Programs cannot be Retrieved on this id " + prgmId);
			throw new LoanException("Loan Programs are not Found");
		}
		return loanDesc;
	}

	
	/* Insert all the details of the customer's loan application
	 * @see com.loanapplication.dao.CustomerDAO#insertLoanApp(com.loanapplication.entities.Loanapplication)
	 */
	@Override
	public long insertLoanApp(Loanapplication loanApp) throws LoanException {
		// TODO Auto-generated method stub
		if(loanApp == null)
		{
			logger.error("Loan Application Details Insertion Failed");
			throw new LoanException("Loan Application details cannot be Inserted");
		}
		else
		{	
			logger.info("Loan Application Details has been Inserted Successfully");
			entityManager.persist(loanApp);
			entityManager.flush();
		}
		return loanApp.getApplicationId();
	}

	
	/* Insert all the personal details of the customer
	 * @see com.loanapplication.dao.CustomerDAO#insertCustDetails(com.loanapplication.entities.CustomerDetail)
	 */
	@Override
	public boolean insertCustDetails(CustomerDetail cust) throws LoanException {
		// TODO Auto-generated method stub
		boolean flag= false;
		entityManager.persist(cust);
		entityManager.flush();
		if(cust == null)
		{	
			flag = false;
			logger.error("Customer Details Insertion Failed");
			throw new LoanException("Customer details cannot be Inserted");
		}
		else
		{	flag= true;
			logger.info("Customer Details has been Inserted Successfully");
		}
		return flag;
	}

	/* get the status of the loan application
	 * @see com.loanapplication.dao.CustomerDAO#getStatus(long)
	 */
	@Override
	public Loanapplication getStatus(long id) throws LoanException {
		// TODO Auto-generated method stub
		Loanapplication app=null;
		app=entityManager.find(Loanapplication.class, id);
		if(app==null)
		{
			logger.error("Your Application Id is invalid,Please insert correct Application Id");
			throw new LoanException("Invalid Id, Enter Correct Application Id");
		}
		else
		{
			logger.info("Your Updated Status for Loan Application" + app);
		}
		return app;
	}

}
