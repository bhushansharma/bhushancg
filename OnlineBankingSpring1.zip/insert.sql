INSERT INTO ADMINS1 VALUES('admin','admin');

INSERT INTO Account_Master1 VALUES(account_Id_Seq.NEXTVAL,'Savings Account',10000,sysdate);


INSERT INTO Account_Master1 VALUES(account_Id_Seq.NEXTVAL,'Current Account',16000,sysdate);

INSERT INTO Account_Master1 VALUES(account_Id_Seq.NEXTVAL,'Savings Account',20000,sysdate);

INSERT INTO Account_Master1 VALUES(account_Id_Seq.NEXTVAL,'Savings Account',20000,sysdate);

INSERT INTO TRANSACTIONS1 VALUES (trans_Id_Seq.nextval,'Bill Payment',sysdate,'S',1200,1000000001);

INSERT INTO USERS1 VALUES (user_Id_Seq.nextval,'formy','your pet name?','formy','A','tommy',1000000001);


insert into Customer1 Values(Customer_Id_Seq.nextval,'formy','formy@abc.com','9664774508','Kurla','ABCD1234ZY',1000000001);

INSERT INTO SERVICE_TRACKER1 VALUES (service_Id_Seq.nextval,'Request for Cheque Book',sysdate,'Open',1000000001);

INSERT INTO PAYEE1 VALUES(Payee_Id_Seq.nextval,'for',1000000001,1000000002);

INSERT INTO PAYEE1 VALUES(Payee_Id_Seq.nextval,'for',1000000001,1000000003);

INSERT INTO PAYEE1 VALUES(Payee_Id_Seq.nextval,'for',1000000001,1000000004);