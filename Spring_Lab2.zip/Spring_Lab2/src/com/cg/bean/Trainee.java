package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Trainee {
	@Id
	private int traineeId;
	@Column(length=20)
	private String traineeName;
	@Column(length=20)
	private String traineeLoc;
	@Column(length=20)
	private String traineeDomain;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeLoc() {
		return traineeLoc;
	}
	public void setTraineeLoc(String traineeLoc) {
		this.traineeLoc = traineeLoc;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	
}
