package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Trainee;
import com.cg.dao.TraineeDao;
import com.cg.exception.TraineeException;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao dao;
	
	@Override
	public boolean insertTrainee(Trainee traineeBean) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.insertTrainee(traineeBean);
	}

	@Override
	public Trainee fetchTraincee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.fetchTraincee(traineeId);
	}

	@Override
	public boolean deleteTrainee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(traineeId);
	}

	@Override
	public boolean modifyTrainee(Trainee bean) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.modifyTrainee(bean);
	}

}
