package com.cg.onlinebanking.logger;

import java.io.IOException;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class BankLogger {
	static Logger logger=Logger.getLogger(BankLogger.class);
	static
	{
		SimpleLayout layout=new SimpleLayout();
		FileAppender appender;
		try {
			appender = new FileAppender(layout,"onlinebanklog.txt");
			logger.addAppender(appender);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static Logger getLoggerInstance(){
		return logger;
	}
}
