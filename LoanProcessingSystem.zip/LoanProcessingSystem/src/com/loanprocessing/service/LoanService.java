package com.loanprocessing.service;

import java.time.LocalDate;

import java.util.HashMap;

import com.loanprocessing.bean.CustomerDetails;
import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.exception.LoanProgramException;

public interface LoanService {

	public HashMap<Integer, String> getLoanProgram() throws LoanProgramException;

	public LoanPrograms getLoanDescription(int loanId)throws LoanProgramException;

	public boolean isValidateLoanAmount(double loanAmount, double minAmt, double maxAmt)throws LoanProgramException;
	
	public boolean insertLoanApplictaion(LoanApplication loanApp) throws LoanProgramException;
	
	public boolean insertCustomerDetails(CustomerDetails custBean)throws LoanProgramException;

	public boolean isValidateCustName(String name) throws LoanProgramException;

	public boolean isValidateCustDOB(LocalDate date) throws LoanProgramException;
	
	public boolean isValidateCustMaritalStatus(String status) throws LoanProgramException;
	
	public boolean isValidateCustPhNo(String phNo) throws LoanProgramException;
	
	public boolean isValidateCustMobNo(String mobNo) throws LoanProgramException;

	public boolean isValidateCustCountOfDependents(int count) throws LoanProgramException;

	public boolean isValidateCustEmailId(String email) throws LoanProgramException;
	
	public LoanApplication checkStatus(int loanAppId)throws LoanProgramException;

	public boolean isValidateAnnualIncome(long annualFamilyIncome, double amount)throws LoanProgramException;
	
	public boolean validateDob(LocalDate dateOfBirth)
			throws LoanProgramException;
}
