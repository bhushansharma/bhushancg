package com.loanprocessing.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.loanprocessing.bean.ApprovedLoans;
import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.Users;
import com.loanprocessing.dbutil.DBUtil;
import com.loanprocessing.exception.LoanProgramException;
import com.loanprocessing.logger.MyLogger;
import com.loanprocessing.mapper.LoanApprovalMapper;

public class LoanApprovalDAOImpl implements LoanApprovalDAO {

	Logger logger = MyLogger.getLoggerInstance();
	Connection con;

	public LoanApprovalDAOImpl() {
		con = DBUtil.getConnection();
		if (con != null) {
			logger.info("Obtained Connection for LoanApprovalDaoClass");
		}
	}

	@Override
	public boolean isValidLad(String username, String password)
			throws LoanProgramException {
		boolean flag = false;
		Users lad = new Users();

		try {

			Statement stmt = con.createStatement();
			ResultSet res = stmt.executeQuery(LoanApprovalMapper.validLad);
			while (res.next()) {

				lad.setLoginId(res.getString(1));
				lad.setPassword(res.getString(2));
				lad.setRole(res.getString(3));
			}

			if (username.equalsIgnoreCase(lad.getLoginId())
					&& password.equals(lad.getPassword())) {
				logger.info("Login Successful");
				flag = true;
			} else
				logger.error("Invalid credentials");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}

		return flag;
	}

	@Override
	public boolean approvedLoans(LoanApplication loanApp)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String custName = getName(loanApp.getLoanAppId());
		double roi = getRoi(loanApp.getLoanProgm());
		double totalAmt = getTotalAmt(roi, loanApp.getAmount());
		ApprovedLoans approvedLoan = new ApprovedLoans();
		totalAmt = totalAmt - approvedLoan.getDwnpaymnt();
		int durInYear = getPeriod(loanApp.getLoanProgm());
		int period = durInYear * 12;
		double monthlyInstallment = totalAmt / period;

		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.insertAprrovedLoan);
			pstmt.setInt(1, loanApp.getLoanAppId());
			pstmt.setString(2, custName);
			pstmt.setDouble(3, loanApp.getAmount());
			pstmt.setDouble(4, monthlyInstallment);
			pstmt.setInt(5, durInYear);
			pstmt.setDouble(6, approvedLoan.getDwnpaymnt());
			pstmt.setDouble(7, roi);
			pstmt.setDouble(8, totalAmt);

			int row = pstmt.executeUpdate();
			if (row != 0) {
				logger.info("Loan Approved Successfully with " + custName);
				flag = true;
				if (updateStaus(loanApp.getLoanAppId())) {

					setInterviewDate(loanApp.getLoanAppId());
					{

					}
				}
			} else
				flag = false;
			logger.error("Approved loan unable to insert");

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}
		return flag;
	}

	private void setInterviewDate(int loanAppId) throws LoanProgramException {
		// boolean flag = false;
		DayOfWeek day = LocalDate.now().plusDays(10).getDayOfWeek();
		LocalDate dateOfInterview;
		if (day.toString().equals("SATURDAY")) {
			dateOfInterview = LocalDate.now().plusDays(12);
		} else if (day.toString().equals("SUNDAY")) {
			dateOfInterview = LocalDate.now().plusDays(11);
		} else
			dateOfInterview = LocalDate.now().plusDays(10);

		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.setInterviewDate);
			pstmt.setDate(1, Date.valueOf(dateOfInterview));
			pstmt.setInt(2, loanAppId);
			int row = pstmt.executeUpdate();
			if (row != 0) {
				// flag = true;
				logger.info("Interview Successfully Scheduled");
			} else
				logger.error("Could not Schedule interview");

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());

		}

	}

	private boolean updateStaus(int loanAppId) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag = false;

		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.updateStatus);
			pstmt.setString(1, "APPROVED");
			pstmt.setInt(2, loanAppId);
			int row = pstmt.executeUpdate();
			if (row != 0) {
				flag = true;
				logger.info("Status updated successfully");
			} else
				logger.info("Status not updated for " + loanAppId);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}

		return flag;
	}

	private int getPeriod(String loanProgm) throws LoanProgramException {
		// TODO Auto-generated method stub

		int durInYear = 0;
		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.getPeriod);
			pstmt.setString(1, loanProgm);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				durInYear = res.getInt(1);
				logger.info("Successfully Retrive Duration of Loan Program");
			} else
				logger.error("Could not get Duration of Loan Program");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}
		return durInYear;
	}

	private double getTotalAmt(double roi, double amount)
			throws LoanProgramException {

		double totalAmt = amount * (1 + (roi / 100));
		return totalAmt;
	}

	private double getRoi(String loanProgm) throws LoanProgramException {

		double roi = 0.0;
		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.getRoi);
			pstmt.setString(1, loanProgm);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				roi = res.getDouble(1);
				logger.info("Successfully retrived ROI of Loan program");
			} else {
				logger.error("Rate of Interest not available for " + loanProgm);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}
		return roi;
	}

	private String getName(int loanAppId) throws LoanProgramException {

		String custName = null;
		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.getCustName);
			pstmt.setInt(1, loanAppId);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				custName = res.getString(1);
				logger.info("Successfully retrived Customer Name " + custName);
			} else
				logger.error("Invalid Application Id " + loanAppId);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}
		return custName;

	}

	@Override
	public HashMap<Integer, String> getLoanApplication(LocalDate date)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		HashMap<Integer, String> applicationPrgMap = new HashMap<>();
		Date appdate = Date.valueOf(date);

		try {
			PreparedStatement stmt = con
					.prepareStatement(LoanApprovalMapper.getLoanPrg);
			stmt.setDate(1, appdate);
			ResultSet res = stmt.executeQuery();
			while (res.next()) {
				applicationPrgMap.put(res.getInt(1), res.getString(2));
				logger.info("Successfully retrived loan id and name for date: "
						+ appdate);
			}

		} catch (SQLException e) {
			logger.info(e.getMessage());
			throw new LoanProgramException(e.getMessage());

		}

		return applicationPrgMap;
	}

	@Override
	public LoanApplication viewLoanApplicationLAD(int appId)
			throws LoanProgramException {

		LoanApplication application = null;
		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.viewLoanApp);
			pstmt.setInt(1, appId);
			ResultSet res = pstmt.executeQuery();

			while (res.next()) {

				application = new LoanApplication();
				application.setLoanAppId(res.getInt(1));
				LocalDate ldate = LocalDate
						.parse(String.valueOf(res.getDate(2)));
				application.setAppDate(ldate);
				application.setLoanProgm(res.getString(3));
				application.setAmount(res.getInt(4));
				application.setAddress(res.getString(5));
				application.setIncome(res.getInt(6));
				application.setProof(res.getString(7));
				application.setCover(res.getString(8));
				application.setMarketValue(res.getInt(9));
				application.setStatus(res.getString(10));
				logger.info("Successfully retrived loan Application for id : "
						+ appId);
				if (application.getStatus().equals("APPROVED")) {
					application
							.setInterviewDate((res.getDate(11).toLocalDate()));
					logger.info("Successfully retrived loan Application for id and Approved: "
							+ appId);
				}
			}

		}

		catch (SQLException e) {
			logger.info(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}
		return application;
	}

	@Override
	public boolean rejectLoans(LoanApplication loanApp)
			throws LoanProgramException {
		boolean flag = false;
		int loanAppId = loanApp.getLoanAppId();

		try {
			PreparedStatement pstmt = con
					.prepareStatement(LoanApprovalMapper.reject);
			pstmt.setString(1, "REJECT");
			pstmt.setInt(2, loanAppId);
			int row = pstmt.executeUpdate();
			if (row == 0)
				logger.error(("Status not updated for " + loanAppId));
			else
				flag = true;
			logger.info("Status Successfully set to Reject");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}
		return flag;

	}

}
