package com.cg.airreservation.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.airreservation.entities.Customerinfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.IFlightService;
import com.cg.airreservation.service.ILoginService;

@Controller
@Scope("session")
public class LoginController {

	@Autowired
	Customerinfo custInfo;

	@Autowired
	ILoginService service;

	@Autowired
	IFlightService flightService;

	/**
	 * this method is used to pass control to login page
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping("/login")
	public String login(Model model) {
		model.addAttribute("checkUser", custInfo);
		return "loginPage";
	}

	/**
	 * this method is used to validate credentials and pass control to
	 * particular page depending upon the for credentials
	 * 
	 * @param customerInfo
	 *            is bean object which store login credentials
	 * @param model
	 * @return
	 */
	@RequestMapping("/check")
	public String checkRole(
			@ModelAttribute("checkUser") Customerinfo customerInfo,HttpSession session, Model model) {
		Customerinfo cust = null;
		try {
			cust = service.validateCredentials(customerInfo);
		} catch (AirlineException e) {
			model.addAttribute("errorMessage", "User not Found");
			model.addAttribute("flag", "login");
			return "loginPage";
		}
		if (cust.getCustpassword().equals(customerInfo.getCustpassword())) {
			session.setAttribute("customerSession", cust);
			model.addAttribute("Customer", cust);
			if (cust.getCusttype().equals("customer")) {
				
				return "customerHome";
			} else if (cust.getCusttype().equals("admin")) {

				return "adminHome";
			} else if (cust.getCusttype().equals("executive")) {

				return "executiveHome";
			} else
				model.addAttribute("message", "Invalid User.");
		} else
			model.addAttribute("message", "Invalid Credentials");
		model.addAttribute("checkUser", custInfo);
		return "loginPage";
	}
}
