package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;


/**
 * The persistent class for the ADMINS1 database table.
 * 
 */
@Component
@Entity
@NamedQuery(name="Admins1.findAll", query="SELECT a FROM Admins1 a")
public class Admins1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USER_ID")
	private String userId;

	private String password;

	public Admins1() {
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}