package com.loanprocessing.bean;

public class LoanPrograms {

	private int programId;
	private String programName;
	private String descriptn;
	private String type;
	private int duration;
	private double minAmount;
	private double maxAmount;
	private double rate;
	private String proof;

	public LoanPrograms() {

	}

	public int getProgramId() {
		return programId;
	}

	public void setProgramId(int programId) {
		this.programId = programId;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getDescriptn() {
		return descriptn;
	}

	public void setDescriptn(String descriptn) {
		this.descriptn = descriptn;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	
	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public String getProof() {
		return proof;
	}

	public void setProof(String proof) {
		this.proof = proof;
	}

	public double getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(double minAmount) {
		this.minAmount = minAmount;
	}

	public double getMaxAmount() {
		return maxAmount;
	}

	public void setMaxAmount(double maxAmount) {
		this.maxAmount = maxAmount;
	}

	@Override
	public String toString() {
		return "LoanPrograms [programId=" + programId + ", programName="
				+ programName + ", descriptn=" + descriptn + ", type=" + type
				+ ", duration=" + duration + ", minAmount=" + minAmount
				+ ", maxAmount=" + maxAmount + ", rate=" + rate + ", proof="
				+ proof + "]";
	}

	
}
