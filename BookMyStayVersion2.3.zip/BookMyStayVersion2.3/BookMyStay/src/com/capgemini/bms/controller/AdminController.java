package com.capgemini.bms.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.exception.HotelException;
import com.capgemini.bms.service.AdminService;
import com.capgemini.bms.service.CustomerService;

/**
 * Description : This class controls the flow of execution of admin operations.
 * @author Bharat Dubey
 * 
 */

@Controller
public class AdminController {
	@Autowired
	Hotel hotelbean;
	@Autowired
	RoomDetail roombean;
	@Autowired
	AdminService adminservice;
	@Autowired
	CustomerService customerservice;
	

	/**
	 * @Description: This method redirects control to HotelManagement.jsp page 
	 * @param model
	 * @return: HotelManagement.jsp
	 */
	
	@RequestMapping(value="/hotelmanagement")
	public String hotelManagement(Model model)
	{
		return "HotelManagement";
	}
	
	/**
	 * @Description: This method redirects control to RoomManagement.jsp page
	 * @param model
	 * @return: RoomManagement.jsp
	 */
	@RequestMapping(value="/roommanagement")
	public String RoomManagement(Model model)
	{
		return "RoomManagement";
	}
	
	/**
	 * @Description This method sets hotel list to model attribute and redirects control to DeleteHotel.jsp page.
	 * @param model
	 * @return DeleteHotel.jsp
	 */
	@RequestMapping(value="/deleteHotelGeneration")
	public String deleteHotelGeneration(Model model)
	{	
			ArrayList<Hotel> hotelList=new ArrayList<Hotel>();
		try
		{
			hotelList=adminservice.generateHotelListReport();
			model.addAttribute("hotelList",hotelList);
		}
		catch(HotelException e)
		{
			model.addAttribute("exception",e.getMessage());
			return "error";
		}
			return "DeleteHotel";	
	}
	
	/**
	 * @Description This method delete hotel information and redirects control to AdminHome.jsp page.
	 * @param model,hotelId
	 * @return AdminHome.jsp
	 */
	
	@RequestMapping(value="/deletehotel")
	public String deleteHotel(@RequestParam("id") int id,Model model)
	{	
		ArrayList<RoomDetail> roomList=new ArrayList<RoomDetail>();
		try
		{	
			roomList=adminservice.viewRoomstoDelete(id);
			if(roomList.size()==0)
			{
				boolean deleteflag = adminservice.deleteHotel(id);
				if(deleteflag)
				{	model.addAttribute("message","Hotel Deleted Successfully");
					return "AdminHome";
				}
				else
				{
					model.addAttribute("exception","Unable to delete hotel");
					return "error";
				}
			}
			else
			{
		for(RoomDetail roomlist:roomList)
		{
			adminservice.deleteBookingOnRoom(roomlist.getRoomId());
		} 
			Hotel hotelbean=adminservice.getHotels(id);
			boolean flag = adminservice.deleteRoomOnHotelId(hotelbean);
			if(flag)
			{
				boolean deleteflag = adminservice.deleteHotel(id);
				if(deleteflag)
				{	model.addAttribute("message","Hotel Deleted Successfully");
					return "AdminHome";
				}
				else
				{
					model.addAttribute("exception","Unable to delete hotel");
					return "error";
				}
			}
			else
			{
				model.addAttribute("exception","Unable to delete hotel");
				return "error"; 
			}
			}
		}
		catch(HotelException e)
		{
		model.addAttribute("exception",e.getMessage());
		return "error";
		}
	}
	
	/**
	 * @Description This method sets hotel list to model attribute redirects control to DeleteHotel.jsp page.
	 * @param model
	 * @return DeleteHotel.jsp
	 */
		
	@RequestMapping(value="/deleteroomGeneration")
	public String deleteroomGeneration(Model model)
	{	ArrayList<Hotel> hotelList=new ArrayList<Hotel>();
	try
	{
		hotelList=adminservice.generateHotelListReport();
		model.addAttribute("hotelList",hotelList);
	}
	catch(HotelException e)
	{
		model.addAttribute("exception",e.getMessage());
		return "error";
	}
		return "SelectHotel";
	}
	
	/**
	 * @Descrption This method used to get Rooms details
	 * @param id
	 * @param model
	 * @return DeleteRoom.jsp
	 */ 
	
	@RequestMapping(value="/getRoomRecords")
	public String getRoomRecords(@RequestParam("id") int id,Model model){	
		ArrayList<RoomDetail> roomList=new ArrayList<RoomDetail>();
		try
		{
			roomList=adminservice.viewRoomstoDelete(id);
			model.addAttribute("roomList",roomList);
		}
		catch(HotelException e)
		{
			model.addAttribute("exception",e.getMessage());
			return "error";
		}
	return "DeleteRoom";	
	}
	
	/**
	 * @Description This method deletes the selected room and return controls to AdminHome.jsp 
	 * @param id
	 * @param model
	 * @return AdminHome.jsp
	 */
	@RequestMapping(value="/deleteroom")
	public String deleteRoom(@RequestParam("id") int id,Model model)
	{	try
		{	
			adminservice.deleteBookingOnRoom(id);
			adminservice.deleteRoom(id);
			model.addAttribute("message","Room Deleted Successfully");
			return "AdminHome";
		}
		catch(HotelException e)
		{
		model.addAttribute("exception",e.getMessage());
		return "error";
		}
	}
	/** 
	 * @param model
	 * @Description This method will navigate to AddHotel page.
	 * @return AddHotel.jsp
	 */
	@RequestMapping(value="/addHotelGeneration")
	public String addHotelGeneration(Model model)
	{	
		ArrayList<String> city=new ArrayList<String>();
		city.add("pune");
		city.add("mumbai");
		city.add("delhi");
		model.addAttribute("cityList", city);
		model.addAttribute("hotelbean", hotelbean);
		return "AddHotel";
	}
	
	/**
	 * @param hotelbean
	 * @param model
	 * @Description This method will add hotel to system. 
	 * @return HotelManagement.jsp
	 */
	@RequestMapping(value="/addhotel")
	public String addHotel(@ModelAttribute("hotelbean")@Valid Hotel hotelbean,BindingResult result, Model model)
	{	
		if(result.hasErrors())
		{
			ArrayList<String> city=new ArrayList<String>();
			city.add("pune");
			city.add("mumbai");
			city.add("delhi");
			model.addAttribute("cityList", city);
			model.addAttribute("hotelbean", hotelbean);
			return "AddHotel";
		}
		try
		{
			boolean flag=adminservice.addHotel(hotelbean);
			if(flag)
			{	
				model.addAttribute("message","Hotel Added Successfully");
				return "HotelManagement";
			}
			else
			{
				model.addAttribute("exception","Unable to add hotel");
				return "error";
			}
				
		}
		catch(HotelException e)
		{
			model.addAttribute("exception",e.getMessage());
			return "error";
		}
	}
	
	/**
	 * @Description This method sets hotel list to model attribute.
	 * @param model
	 * @return SearchHotels.jsp
	 */
	@RequestMapping(value="/addroomGeneration")
	public String addroomGeneration(Model model)
	{	ArrayList<Hotel> hotelList=new ArrayList<Hotel>();
	try
	{
		hotelList=adminservice.generateHotelListReport();
		model.addAttribute("hotelList",hotelList);
	}
	catch(HotelException e)
	{
		model.addAttribute("exception",e.getMessage());
		return "error";
	}
		return "SearchHotels";
	}

	
	/**
	 * @param id
	 * @param model
	 * Description This method will sets room type list to model and redirect to addroom.jsp.
	 * @return AddRoom.jsp
	 */
	@RequestMapping(value="/addroomdetails")
	public String addRoomDetails(@RequestParam("id") int id,Model model)
	{	
		ArrayList<String> type=new ArrayList<String>();
		ArrayList<String> choice=new ArrayList<String>();
		type.add("Delux");
		type.add("Semi-Delux");
		type.add("Pent house");
		choice.add("Y");
		choice.add("N");
		model.addAttribute("typeList", type);
		
		model.addAttribute("availList", choice);
		model.addAttribute("hotelbean", hotelbean);
		model.addAttribute("hotelId",id);
		model.addAttribute("roombean", roombean);
		return "AddRoom";
	}
	/**
	 * @Description This method will add hotel to system.
	 * @param roombean
	 * @param model
	 * @return RoomManagement.jsp
	 */
	@RequestMapping(value="/addroom")
	public String addRoom(@ModelAttribute("roombean")@Valid RoomDetail roombean,BindingResult result, Model model)
	{	
		if(result.hasErrors())
		{
			ArrayList<String> type=new ArrayList<String>();
			ArrayList<String> choice=new ArrayList<String>();
			type.add("Delux");
			type.add("Semi-Delux");
			type.add("Pent house");
			choice.add("Y");
			choice.add("N");
			model.addAttribute("typeList", type);
			
			model.addAttribute("availList", choice);
			model.addAttribute("hotelbean", hotelbean);
			model.addAttribute("roombean", roombean);
			return "AddRoom";
		}
		try
		{
			adminservice.addroom(roombean);
			model.addAttribute("message","Room Added Successfully");
			return "RoomManagement";
		}
		catch(HotelException e)
		{
			model.addAttribute("exception",e.getMessage());
			return "error";
		}
	}
	/**
	 * @Description This method redirects control to GenerateReports.jsp.
	 * @param model
	 * @return GenerateReports.jsp
	 */
	@RequestMapping(value="/generatereport")
	public String generateReport(Model model)
	{
		
		return "GenerateReports";
	}
	/**
	 * @Description This method redirects control to HotelList.jsp.
	 * @param model
	 * @return HotelList.jsp
	 */
	@RequestMapping(value="/hotellist")
	public String listHotel(Model model)
	{	ArrayList<Hotel> hotelList=new ArrayList<Hotel>();
	try
	{
		hotelList=adminservice.generateHotelListReport();
		model.addAttribute("hotelList",hotelList);
	}
	catch(HotelException e)
	{
		model.addAttribute("exception",e.getMessage());
		return "error";
	}
		return "HotelList";
	}
	/**
	 * @Description This method redirects control to SearchHotel.jsp.
	 * @param model
	 * @return SearchHotel.jsp
	 */
	@RequestMapping(value="/getrooms")
	public String getRooms(Model model)
	{	ArrayList<Hotel> hotelList=new ArrayList<Hotel>();
	try
	{
		hotelList=adminservice.generateHotelListReport();
		model.addAttribute("hotelList",hotelList);
	}
	catch(HotelException e)
	{
		model.addAttribute("exception",e.getMessage());
		return "error";
	}
		return "SearchHotel";
	}
	/**
	 * @Description This method sets room list to model and redireccts page to RoomList.jsp
	 * @param roombean
	 * @param model
	 * @return RoomList.jsp
	 */
	@RequestMapping(value="/roomlist")
	public String listRoom(@RequestParam("id") int id,Model model)
	{	ArrayList<RoomDetail> roomList=new ArrayList<RoomDetail>();
	try
	{
		roomList=adminservice.viewRoomstoDelete(id);
		model.addAttribute("roomList",roomList);
	}
	catch(HotelException e)
	{
		model.addAttribute("exception",e.getMessage());
		return "error";
	}
		return "RoomList";
	}
}
