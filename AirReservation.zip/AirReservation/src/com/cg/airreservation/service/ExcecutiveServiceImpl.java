package com.cg.airreservation.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import com.cg.airreservation.dao.ExecutiveDaoImpl;
import com.cg.airreservation.dao.IExecutiveDao;
import com.cg.airreservation.dto.AirportBean;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public class ExcecutiveServiceImpl implements IExecutiveService{

	IExecutiveDao dao;

	public ExcecutiveServiceImpl() {
		// TODO Auto-generated constructor stub
		dao = new ExecutiveDaoImpl();
		
	}
	
	public void setDao(IExecutiveDao dao)
	{
		this.dao=dao;
	}
	
	// This method definition used to add new flight in the system by Admin
	@Override
	public boolean insertFlightInfo(FlightBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.insertFlightInfo(bean);
	}

	// this method definition is used to check seat availability by executive
	@Override
	public FlightBean flightOccupancyDetails(String flight_num)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.flightOccupancyDetails(flight_num);
	}

	/*
	 * This method definition used to fetch flight info based on date entered by
	 * admin
	 */
	@Override
	public ArrayList<FlightBean> generateFlightList(LocalDate dateJourney)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.generateFlightList(dateJourney);
	}

	/*
	 * this method definition is used to fetch all the passengers in a flight by
	 * admin
	 */
	@Override
	public ArrayList<BookingBean> fetchPassengerList(String flightNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.fetchPassengerList(flightNum);
	}
	
	
	@Override
	public boolean validateDate(LocalDate date) {
		// TODO Auto-generated method stub
		LocalDate today = LocalDate.now();
		Period diff = date.until(today);

		if (diff.getDays() >0  || diff.getMonths() > 0 || diff.getYears() > 0) {

			return false;
		}

		
		
		return true;
	}
	
	
	public boolean validateSource(String source)
	{
		
		return source.matches("[a-zA-Z]+");
	}
	
	public boolean validateDestination(String dest)
	{
		
		return dest.matches("[a-zA-Z]+");
	}

	@Override
	public ArrayList<AirportBean> fetchAirportList() throws AirlineException {
		// TODO Auto-generated method stub
		return dao.fetchAirportList();
	}
	

	public boolean validateTime(String time)
	{
		return time.matches("([01][0-9]|2[0-3])\\:([012345][0-9])");	
	}

	@Override
	public boolean validateArrivalDate(LocalDate dept, LocalDate arrival) {
		// TODO Auto-generated method stub
		Period diff = arrival.until(dept);
		
				if (diff.getDays() >0  || diff.getMonths() > 0 || diff.getYears() > 0) {

					return false;
				}
				
				return true;
	}
	
	
}
