package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;


/**
 * The persistent class for the USERS1 database table.
 * 
 */
@Component
@Entity
@NamedQuery(name="Users1.findAll", query="SELECT u FROM Users1 u")
public class Users1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="USERS1_USERID_GENERATOR", sequenceName="USER_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USERS1_USERID_GENERATOR")
	@Column(name="USER_ID")
	private long userId;

	@Column(name="LOCK_STATUS")
	private String lockStatus;
	
	@Pattern(regexp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+_])(?=\\S+$).{8,15}$", message="Enter Login Password Which should be Between 8 to 15 chars and matches small, capital and digits")
	@Column(name="LOGIN_PASSWORD")
	private String loginPassword;

	@Pattern(regexp="([a-zA-Z0-9]*)[\\s]?([a-zA-Z0-9]*){5,50}", message="Secret Question answer Should be Between 5 to 50 chars")
	@Column(name="SECRET_ANSWER")
	private String secretAnswer;

	@Column(name="SECRET_QUESTION")
	private String secretQuestion;

	@Pattern(regexp="[0-9]{4}", message="Transaction Password should be only 4 digits ")
	@Column(name="TRANSACTION_PASSWORD")
	private String transactionPassword;

	//bi-directional many-to-one association to AccountMaster1
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private AccountMaster1 accountMaster1;

	public Users1() {
	}

	public long getUserId() {
		return this.userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getLockStatus() {
		return this.lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public String getLoginPassword() {
		return this.loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getSecretAnswer() {
		return this.secretAnswer;
	}

	public void setSecretAnswer(String secretAnswer) {
		this.secretAnswer = secretAnswer;
	}

	public String getSecretQuestion() {
		return this.secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getTransactionPassword() {
		return this.transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public AccountMaster1 getAccountMaster1() {
		return this.accountMaster1;
	}

	public void setAccountMaster1(AccountMaster1 accountMaster1) {
		this.accountMaster1 = accountMaster1;
	}

}