package com.cg.bean;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity
@Component
public class UserLogin {
	@Id
	@NotEmpty(message="User should not be Empty")
	private String userName;
	@NotEmpty(message="Password Should not be Empty")
	@Pattern(regexp="admin", message="Passord Incorrect")
	private String pass;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
}
