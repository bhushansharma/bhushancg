package com.loanprocessing.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.dao.AdminDao;
import com.loanprocessing.dao.LoanApprovalDAO;
import com.loanprocessing.dao.LoanApprovalDAOImpl;
import com.loanprocessing.exception.LoanProgramException;


public class LoanApprovalServiceImpl implements LoanApprovalService {
	
	LoanApprovalDAO daoLad;
	
	public void setDao(LoanApprovalDAO daoLad)
	{
		this.daoLad = daoLad;
	}

	
	public LoanApprovalServiceImpl() {
		daoLad= new LoanApprovalDAOImpl();
	}
	
	@Override
	public boolean isValidLad(String username, String password)
			throws LoanProgramException {
		
		return daoLad.isValidLad(username,password);
	}

	@Override
	public HashMap<Integer, String> getLoanApplication(LocalDate date)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoLad.getLoanApplication(date);
	}

	@Override
	public LoanApplication viewLoanApplicationLAD(int appId)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoLad.viewLoanApplicationLAD(appId);
	}

	@Override
	public boolean approvedLoans(LoanApplication loanApp)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoLad.approvedLoans(loanApp);
	}

	@Override
	public boolean rejectLoans(LoanApplication loanApp)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		return daoLad.rejectLoans(loanApp);
	}

}
