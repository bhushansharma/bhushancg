package com.loanapplication.dao;

import java.sql.Date;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;














import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.loanapplication.entities.Approvedloan;
import com.loanapplication.entities.CustomerDetail;
import com.loanapplication.entities.Loanapplication;
import com.loanapplication.entities.Loanprogramsoffered;
import com.loanapplication.exception.LoanException;
import com.loanapplication.logger.MyLogger;

@Repository
public class LADDaoImpl implements LADDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	Logger logger = MyLogger.getLoggerInstance();
	
	/* Get all the customer details from the database
	 * @see com.loanapplication.dao.LADDao#getCustomerDetails(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<CustomerDetail> getCustomerDetails(String date)
			throws LoanException {
		// TODO Auto-generated method stub
		Date loanDate=Date.valueOf(date);
 		ArrayList<Loanapplication>loanAppList=new ArrayList<Loanapplication>();
 		ArrayList<Long>custIdList=new ArrayList<Long>();
 		
 		Query query=entityManager.createQuery("SELECT loanapp.customerDetail.customerId FROM Loanapplication loanapp WHERE applicationDate=:loanDate");
 		query.setParameter("loanDate", loanDate);
 		custIdList=(ArrayList<Long>) query.getResultList();
 		ArrayList<CustomerDetail>custList= new ArrayList<CustomerDetail>();
 		Query query1=entityManager.createQuery("SELECT cust FROM CustomerDetail cust where cust.customerId IN (:custIdList)");
 		query1.setParameter("custIdList",custIdList);
 		custList=(ArrayList<CustomerDetail>) query1.getResultList();
 		if(date !=  null)
 		{
 			logger.info("Successfully retrived the Customer Details" + custList);
 		}
 		else
 		{
 			logger.error("Customer Details cannot be Retrived on this date" + date);
 			throw new LoanException("Customer Details cannot be found");
 		}
 		return custList;
	}

	
	
	
	
	/* Get loan application details of a particular customer id
	 * @see com.loanapplication.dao.LADDao#getLoanApplication(long)
	 */
	@Override
	public Loanapplication getLoanApplication(long custid)
			throws LoanException {
		Loanapplication loan=null;
		TypedQuery<Loanapplication> query = entityManager.createQuery("SELECT loan from Loanapplication loan WHERE customerDetail.customerId=:custid",Loanapplication.class);
 		query.setParameter("custid", custid);
 		loan = (Loanapplication)query.getSingleResult();
			
		if(loan==null)
		{
			logger.error("Loan Application Details Not found on this id" + custid);
			throw new LoanException("Customer Id not found");
		}
		else
			logger.info("Loan Application Details Found" + loan);
		return loan;
	}

	
	
	
	/* Approval of loan
	 * @see com.loanapplication.dao.LADDao#approveLoan(long)
	 */
	@Override
	public boolean approveLoan(long id) throws LoanException {
		// TODO Auto-generated method stub
		Loanapplication loan=null;
		CustomerDetail cust=null;
		Loanprogramsoffered prg=null;
		Approvedloan approved=new Approvedloan();
		long amount=0;
		long duration=0;
		double roi=0.0;
		long premiumAmnt=0;
		long monthInstal=0;
		long monthIncome=0;
		long annualIncome=0;
		long finalAmt=0;
		boolean flag=false;
		
		
		loan=entityManager.find(Loanapplication.class, id);
		
		
		if(loan.getStatus().equals("Applied")){
		cust=loan.getCustomerDetail();
		
		amount=loan.getAmtOfLoan();
		prg=loan.getLoanprogramsoffered();
		duration=prg.getDurationInYrs();
		roi=prg.getRoi();
		annualIncome=loan.getAnnualFamilyIncome();
		
		premiumAmnt=(long) (amount*(1+(roi/100)*duration));
		monthInstal=(premiumAmnt/(12*duration));
		monthIncome=(annualIncome/12);
		finalAmt=(monthIncome*50);
		
		if(finalAmt>amount)
		{
			approved.setAmountOfLoan(amount);
			approved.setMonthlyInstallment(monthInstal);
			approved.setPremium(premiumAmnt);
			approved.setTimePeriod((int) duration);
			approved.setRoi(roi);
			approved.setCustomerDetail(cust);
			entityManager.persist(approved);
			entityManager.flush();
			flag=true;
			
			DayOfWeek day = LocalDate.now().plusDays(10).getDayOfWeek();
			LocalDate dateOfInterview;
			if (day.toString().equals("SATURDAY")) {
				dateOfInterview = LocalDate.now().plusDays(12);
			} else if (day.toString().equals("SUNDAY")) {
				dateOfInterview = LocalDate.now().plusDays(11);
			} else
				dateOfInterview = LocalDate.now().plusDays(10);
			
			loan.setDateOfInterview(Date.valueOf(dateOfInterview));
			loan.setStatus("Accepted");
			entityManager.merge(loan);
			
			if(id == 0)
			{
				flag = false;
				logger.error("Id Not Found" + id + "Status cannot be updated");
				throw new LoanException("Status cannot be updated Please enter correct id");
			}
			else
			{
				flag=true;
				logger.info("Status updated successfully for this id = " + id);
			}
			
		}
		else
		{
			loan.setStatus("Rejected Due to Low Family Income");
			
		}
		}
		else
			throw new LoanException("Approval of this loan application is already done");
	
		return flag;
	}

	

}
