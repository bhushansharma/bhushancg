package com.loanprocessing.dao;


import java.util.HashMap;

import com.loanprocessing.bean.CustomerDetails;
import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.exception.LoanProgramException;

public interface LoanDAO {

	public HashMap<Integer,String> getLoanProgram() throws LoanProgramException;

	public LoanPrograms getLoanDescription(int programId)
			throws LoanProgramException;

	
	
	public boolean insertLoanApplictaion(LoanApplication loanApp) throws LoanProgramException;
	
	public boolean insertCustomerDetails(CustomerDetails custBean)throws LoanProgramException;
	
	public LoanApplication checkStatus(int loanAppId)throws LoanProgramException;

	
}
