package com.cg.airreservation.dao;

/**
 * <AirLine Reservation System>
 * class for implementing AirlineDao interface methods for customer operations
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.airreservation.dbutil.DBUtil;
import com.cg.airreservation.dbutil.QueryMapper;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.logger.AirLineLogger;

public class AirlineDaoImpl implements IAirlineDao {

	// creating logger object
	Logger logger = AirLineLogger.getLoggerInstance();

	// Creating instance of Connection interface
	Connection con = null;

	// defualt constructor
	public AirlineDaoImpl() {
		// TODO Auto-generated constructor stub
		con = DBUtil.getConnection();
		if (con != null) {
			logger.info("Connection is Obtained");
		} else {
			logger.info("Connection is failed to Obtained");
		}
	}

	public int getSequence() throws AirlineException {
		int sequence = 0;
		
		Statement stmt=null;
		try {
			stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(QueryMapper.getPnrSequence);
			if (result.next()) {
				sequence = result.getInt(1);

				logger.info("Sequence " + sequence + " is created");
			} else {
				logger.info("Failed to get Sequence");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured" + e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		return sequence;
	}

	/*
	 * defining method, this is used to insert customer and flight info after
	 * confirming booking
	 */
	@Override
	public boolean insertPassengerInfo(BookingBean bean, FlightBean fBean)
			throws AirlineException {

		/* Inserting into Booking table */
		boolean flag = false;
		int sequenceNum = getSequence();
		bean.setPnr(sequenceNum);
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.insertpassengerInfo);
			pstmt.setInt(1, sequenceNum);
			pstmt.setString(2, bean.getFlightNo());
			pstmt.setInt(3, bean.getCustId());
			pstmt.setString(4, bean.getCustMobile());
			pstmt.setString(5, bean.getCustMail());
			pstmt.setInt(6, bean.getPassengerNum());
			pstmt.setString(7, bean.getClassType());

			pstmt.setDouble(8, bean.getTotalFare());

			pstmt.setString(9, bean.getSource());
			pstmt.setString(10, bean.getDest());
			pstmt.setDate(11, Date.valueOf(bean.getDateOfJourney()));
			pstmt.setTime(12, Time.valueOf(LocalTime.now()));

			int row = pstmt.executeUpdate();
			if (row != 0) {
				logger.info("Passenger Info Inserted of Passenger Id: "+bean.getCustId());
				flag = true;
				updateFlight(bean.getPassengerNum(), bean.getClassType(),
						bean.getFlightNo());
			}

		} catch (SQLException e) {

			logger.error("Exception Occured"+e.getMessage());
			throw new AirlineException("Exception while inserting flight info");

		}
		return flag;

	}

	/*
	 * defining method, used to update flight information after successful
	 * booking
	 */
	public void updateFlight(int number, String classType, String flightNum)
			throws AirlineException {
		if (classType.equals("A")) {
			try {
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.updateFlightInfoBuss);
				pstmt.setInt(1, number);
				pstmt.setString(2, flightNum);
				int row = pstmt.executeUpdate();

				// record is updted or not is not checked
				logger.info("Flight Info Updated for Class Type A");

			} catch (SQLException e) {

				logger.error("Exception Occured" + e.getMessage());
				throw new AirlineException(e.getMessage());
			}
		} else if (classType.equals("B")) {

			try {
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.updateFlightInfoEco);
				pstmt.setInt(1, number);
				pstmt.setString(2, flightNum);
				int row = pstmt.executeUpdate();
				// record is updted or not is not checked
				logger.info("Flight Info Updated for Class Type B");

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error("Exception Occured" + e.getMessage());
				throw new AirlineException(e.getMessage());
			}

		}

	}

	/*
	 * defining method, used to calculate total amount (including service tax
	 * and seat fare based on type)
	 */
	@Override
	public double calFare(BookingBean bean, FlightBean fBean)
			throws AirlineException {
		double fare = 0;
		double tax = 0;
		if (bean.getClassType().equals("A")) {
			fare = (bean.getPassengerNum()) * (fBean.getBusinessFare());
			tax = fare * 0.12;
		} else if (bean.getClassType().equals("B")) {
			fare = (bean.getPassengerNum()) * (fBean.getEconomyFare());

			tax = fare * 0.12;
		}
		double totalFare = fare + tax;
		bean.setTotalFare(totalFare);
		return totalFare;
	}

	/*
	 * defining method, used to insert customer details after successful
	 * registration
	 */
	@Override
	public boolean insertdetails(CustomerInfoBean bean) throws AirlineException {
		boolean flag = false;
		try {
			PreparedStatement pstate = con.prepareStatement(QueryMapper.insertCustomerDetails);
			pstate.setString(1, bean.getCustName());
			pstate.setDate(2, Date.valueOf(bean.getDatOfBirth()));
			pstate.setString(3, bean.getPassword());
			pstate.setString(4, bean.getMobileno());
			pstate.setString(5, bean.getEmail());
			pstate.setString(6, bean.getGender());

			int row = pstate.executeUpdate();
			if (row == 0) {
				logger.info("Failed to insert Info of Customer "+bean.getCustName());
			} else {
				logger.info("Info Inserted Successfully for Customer "+bean.getCustName());
				flag = true;
			}

		} catch (SQLException e) {
			logger.error("Exception Occured" + e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		return flag;
	}

	/*
	 * defining method, used to authenticate customer, admin and executive
	 * information during login
	 */
	@Override
	public CustomerInfoBean checkcredentials(String email, String password)
			throws AirlineException {
		CustomerInfoBean bean = null;
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.checkCredentials);
			pstmt.setString(1, email);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				bean = new CustomerInfoBean();
				bean.setCustId(result.getInt(1));
				bean.setCustName(result.getString(2));
				bean.setDatOfBirth((result.getDate(3)).toLocalDate());
				bean.setPassword(result.getString(4));
				bean.setMobileno(result.getString(5));
				bean.setEmail(result.getString(6));
				bean.setGender(result.getString(7));
				bean.setUserType(result.getString(8));
				if (!bean.getPassword().equals(password)) {
					logger.info("Failed to LogIn.Invalid Credentials. User Name: "+email);
					return null;
				} else
					logger.info("LogIn Successfully. User Name: "+email);
			}

		} catch (SQLException e) {
			logger.error("Exception Occured" + e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		return bean;
	}

	/*
	 * defining method, used to fetch all flight information based on date of
	 * journey entered by customer
	 */
	@SuppressWarnings("unused")
	@Override
	public ArrayList<FlightBean> searchFlight(LocalDate dateJourney)
			throws AirlineException {
		ArrayList<FlightBean> flightList = null;
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.searchFlightByDate);
			Date date = Date.valueOf(dateJourney);
			pstmt.setDate(1, date);
			ResultSet result = pstmt.executeQuery();
			flightList=new ArrayList<FlightBean>();
			while (result.next()) {
				FlightBean flightBean = new FlightBean();
				flightBean.setFlightNum(result.getString(1));
				flightBean.setAirlineName(result.getString(2));
				flightBean.setAirportZip(result.getString(3));
				flightBean.setSource(result.getString(4));
				flightBean.setDestination(result.getString(5));
				flightBean.setBusinessFare(result.getInt(6));
				flightBean.setEconomyFare(result.getInt(7));
				flightBean.setBusinessSeats(result.getInt(8));
				flightBean.setEconomySeats(result.getInt(9));
				flightBean.setDeptDate(result.getDate(10).toLocalDate());
				flightBean.setArriveDate(result.getDate(11).toLocalDate());
				flightBean.setArriveTime(result.getString(12));
				flightBean.setDeptTime(result.getString(13));
				flightBean.setRemainingBusSeats(result.getInt(14));
				flightBean.setRemainingEcoSeats(result.getInt(15));
				flightList.add(flightBean);
			}

			if (flightList != null) {
				logger.info("Flight Search is successfully completed for Journey Date "+dateJourney);
			}
			else 
			{
				
				logger.info("Failed to Search Flight for Journey Date "+dateJourney);
			}

		} catch (Exception e) {
			logger.error("Exception Occured" + e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		return flightList;
	}

}
