package com.capgemini.bms.controller;
import java.sql.Date;
import java.time.Period;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.bean.User;
import com.capgemini.bms.exception.HotelException;
import com.capgemini.bms.service.AdminService;
import com.capgemini.bms.service.CustomerService;

	/**
	 * @author Swapnil Shedge
	 *
	 */
	@Controller
	public class CustomerController {

		@Autowired
		BookingDetail bBean;

		@Autowired
		Hotel hBean;

		@Autowired
		RoomDetail rBean;

		@Autowired
		User uBean;

		@Autowired
		CustomerService service;
		
		
		@Autowired
		AdminService adminservice;
		int userId;
		
		ArrayList<String>cityList;
		/**
		 * @Description This method redirects control to Login.jsp
		 * @param model
		 * @return Login
		 */
		@RequestMapping("/loginpage")
		public String login(Model model) {
			model.addAttribute("User", uBean);
			return "Login";
		}
		
		/**
		 * @Description This method redirects control to signup.jsp
		 * @param model
		 * @return signup.jsp
		 */
		@RequestMapping("/signuppage")
		public String signUpForm(Model model)
		{
			model.addAttribute("User", uBean);
			return "SignUp";
		}
		
		/**
		 * @Description This method validates control to WelcomePage.jsp
		 * @param username
		 * @param password
		 * @param model
		 * @return WelcomePage 
		 */
		@RequestMapping("/login")
		public String loginForm(@RequestParam("username")String username,@RequestParam("password")String password,Model model) 
		{
			try 
			{
				String role = service.validate(username, password);
				if(role.equalsIgnoreCase("customer"))
				{	uBean=service.getUser(username, password);
					userId=(int) uBean.getUserId();
					model.addAttribute("UserName", username);
					return "WelcomePage";
				}
				else if(role.equalsIgnoreCase("admin"))
				{
					return "AdminHome";
				}
				else
				{
					model.addAttribute("User", uBean);
					return "Login";
				}
			} catch (HotelException e) 
			{
				model.addAttribute("User", uBean);
				model.addAttribute("message", e.getMessage());
				return "Login";
			}
		}
		

		/**
		 * @Description This method Create a user and redirects control to Login.jsp
		 * @param uBean
		 * @param result
		 * @param model
		 * @return SignUp
		 */
		@RequestMapping("/signup")
		public String signUp(@ModelAttribute("User") @Valid User uBean,BindingResult result, Model model) {
			try 
			{
				if (result.hasErrors()) 
				{
					return "SignUp";
				}
				else 
				{
					service.registerUser(uBean);
					model.addAttribute("message","Congratulations you are now a registered customer");
					model.addAttribute("User", uBean);
					return "Login";
				}
			} 
			catch (HotelException e) 
			{
				model.addAttribute("message", e.getMessage());
				return "Error";
			}
		}
		
		/**
		 * @Description This method sets city list to model and redirects control to BookHotel.jsp
		 * @param model
		 * @return BookHotel
		 */
		@RequestMapping("/bookhotel")
		public String bookHotel(Model model)
		{
			cityList = new ArrayList<String>();
			cityList.add("pune");
			cityList.add("mumbai");
			cityList.add("delhi");
			model.addAttribute("cityList", cityList);
			model.addAttribute("Hotel", hBean);
			return "BookHotel";
		}
		
		/**
		 * @Description This method returns hotel list and redirects control to showHotels.jsp
		 * @param hBean
		 * @param model
		 * @return showHotels
		 */
		@RequestMapping("/showhotels")
		public String showHotel(Hotel hBean,Model model)
		{
			try 
			{
				ArrayList<Hotel> list  = service.getHotelList(hBean.getHotelCity());
				model.addAttribute("Hotel", hBean);
				model.addAttribute("list", list);
				return "showHotels";
			} 
			catch (HotelException e) 
			{
				model.addAttribute("exception", e.getMessage());
				return "error";
			}
		}
		/**
		 * @Description This method redirects control to showRooms.jsp
		 * @param id
		 * @param model
		 * @return showRooms
		 */
		@RequestMapping("/searchrooms")
		public String searchRooms(@RequestParam ("id") int id,Model model)
		{
			try 
			{
				ArrayList<RoomDetail> list  = adminservice.viewRooms(id);
				System.out.println(list);
				model.addAttribute("rBean", rBean);
				model.addAttribute("list", list);
				return "showRooms";
			} 
			catch (HotelException e) 
			{
				model.addAttribute("exception", e.getMessage());
				return "error";
			}
		}
		
		/**
		 * @Description This method redirects control to bookroom.jsp
		 * @param roomid
		 * @param model
		 * @return AddBookingInfo
		 */ 
		@RequestMapping("/bookroom")
		public String bookroom(@RequestParam ("roomid") int roomid, Model model)
		{
			model.addAttribute("bookingDetail",bBean);
			model.addAttribute("roomid",roomid);
			model.addAttribute("userId",userId);
			return "AddBookingInfo";
		}
				
		/**
		 * @Description This method calculates final amount and redirects control to AmountDetail.jsp
		 * @param checkin
		 * @param checkout
		 * @param bBean
		 * @param model
		 * @return AmountDetail
		 */
		@RequestMapping("/confirmbooking")
		public String confirmbooking(@RequestParam ("checkin") Date checkin,@RequestParam ("checkout") Date checkout,BookingDetail bBean, Model model) 
		{
			try 
			{	
				bBean.setBookedFrom(checkin);
				bBean.setBookedTo(checkout);
				rBean=adminservice.getRoom(bBean.getRoomDetail().getRoomId());
				Period diff=checkin.toLocalDate().until(checkout.toLocalDate());
				long total=rBean.getPerNightRt() *diff.getDays();
				hBean=adminservice.getHotels(rBean.getHotel().getHotelId());
				bBean.setTotalAmount(total);
				model.addAttribute("bookingDetail",bBean);
				model.addAttribute("roomid",rBean.getRoomId());
				model.addAttribute("userId",userId);
				 return "AmountDetail";
			}
			catch (HotelException e) 
			{
				model.addAttribute("exception", e.getMessage());
				return "error";
			}
		}
		
		/**
		 * @Description This method calculates final amount, book room and redirects control to ShowBookingDetails.jsp
		 * @param checkin
		 * @param checkout
		 * @param bBean
		 * @param model
		 * @return ShowBookingDetails
		 */
		@RequestMapping("/payamount")
		public String payamount(@RequestParam("checkin") Date checkin, @RequestParam ("checkout") Date checkout,BookingDetail bBean, Model model)
		{
			try
			{
				bBean.setBookedFrom(checkin);
				bBean.setBookedTo(checkout);
				rBean=adminservice.getRoom(bBean.getRoomDetail().getRoomId());
			
				hBean=adminservice.getHotels(rBean.getHotel().getHotelId());
			
				boolean flag = service.bookRoom(bBean);
				adminservice.updateRoom(bBean.getRoomDetail().getRoomId());
			
				model.addAttribute("bBean",bBean);
				model.addAttribute("hBean",hBean);
				model.addAttribute("rBean",rBean);
				
				if(flag)
				{
					return "ShowBookingDetails";
				}
				else
				{
					return "error";
				}
			}
			catch (HotelException e) 
			{
				model.addAttribute("exception", e.getMessage());
				return "error";
			}
		}
		/**
		 * @Description This method displays final booking details and redirects control to MyBookings.jsp
		 * @param model
		 * @return
		 */
		@RequestMapping("/showbooking.obj")
		public String showBooking(Model model)
		{
			try 
			{
				ArrayList<BookingDetail> bookingList= service.getBookings(userId);
				model.addAttribute("bookingList", bookingList);
			} 
			catch (HotelException e) 
			{
				e.printStackTrace();
			}
			return "MyBookings";
		}
		
		
	}
