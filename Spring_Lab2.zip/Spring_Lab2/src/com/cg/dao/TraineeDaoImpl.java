package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bean.Trainee;
import com.cg.exception.TraineeException;
@Repository
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
	EntityManager emanager;
	@Override
	public boolean insertTrainee(Trainee traineeBean) throws TraineeException {
		// TODO Auto-generated method stub
		emanager.persist(traineeBean);
		return true;
	}
	@Override
	public Trainee fetchTraincee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		Trainee traineeBean= emanager.find(Trainee.class, traineeId);
//		System.out.println("MOdify Bean"+traineeBean.getTraineeName());
		if(traineeBean==null)
		{
			throw new TraineeException("Failed to Fetch Trainee details for Id "+traineeId);
		}
		return traineeBean;
	}
	@Override
	public boolean deleteTrainee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
//		boolean flag=false;
		Trainee traineeBean= emanager.find(Trainee.class, traineeId);
		emanager.remove(traineeBean);
		return true;
	}
	@Override
	public boolean modifyTrainee(Trainee bean) throws TraineeException {
		// TODO Auto-generated method stub
		Trainee traineeBean= emanager.find(Trainee.class, bean.getTraineeId());
		traineeBean.setTraineeId(bean.getTraineeId());
		traineeBean.setTraineeDomain(bean.getTraineeDomain());
		traineeBean.setTraineeLoc(bean.getTraineeLoc());
		traineeBean.setTraineeName(bean.getTraineeName());
		emanager.persist(traineeBean);
		emanager.flush();
		return true;
	}

}
