package com.capgemini.bms.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.exception.HotelException;
import com.capgemini.bms.logger.HotelLogger;

@Repository
public class AdminDaoImpl implements AdminDao {
	@PersistenceContext
	private EntityManager entityManager;
	
	Logger logger = HotelLogger.getLoggerInstance();
	
	
	/****************************************************************************************
	 * @Function Name : addHotel
	 * @Input Parameters : hotel
	 * @Return Type : boolean
	 * @Throws : HotelException
	 * @Description : Adding the Hotel to database
	 ****************************************************************************************/
	@Override
	public boolean addHotel(Hotel hotel) throws HotelException {
		boolean flag=true;
		try
		{
			entityManager.persist(hotel);
			logger.info("INFO: Hotel Bean Persisted successfully");
		}
		catch(Exception e)
		{
			flag=false;
			logger.error("ERROR: Unable to Add Hotel");
			throw new HotelException("Unable to Add Hotel. Please Try Again");
		}
		return flag;
	}

	@Override
	public ArrayList<Hotel> getHotelList() throws HotelException {
		return null;
	}
	
	/****************************************************************************************
	 * @Function Name : getHotels
	 * @Input Parameters : hotelId
	 * @Return Type : Hotel
	 * @Throws : HotelException
	 * @Description : Getting the Hotel using hotelId
	 ****************************************************************************************/
	@Override
	public Hotel getHotels(int hotelId) throws HotelException {
		Hotel hotelbean=null;
		try
		{
			hotelbean=entityManager.find(Hotel.class,hotelId);
			logger.info("INFO: Fetched Hotel data successfully");
		}
		catch(Exception e)
		{
			logger.error("ERROR: Hotel Not Found");
			throw new HotelException("Hotel Not Found");
		}
		return hotelbean;
	}

	/****************************************************************************************
	 * @Function Name : deleteHotel
	 * @Input Parameters : hotelId
	 * @Return Type : boolean
	 * @Throws : HotelException
	 * @Description : Delete the Hotel using hotelId
	 ****************************************************************************************/
	@Override
	public boolean deleteHotel(int hotelId) throws HotelException {
		boolean flag = false;
		try
		{
			Hotel hotelbean=entityManager.find(Hotel.class,hotelId);
			entityManager.remove(hotelbean);
			flag = true;
			logger.info("INFO: Deleted the Hotel using hotelId");
		}
		catch(Exception e)
		{
			logger.error("ERROR: Unable to delete Hotel");
			throw new HotelException("Unable to delete Hotel. Please try again");
		}
		return flag;
	}

	@Override
	public boolean updateHotel(Hotel hotelNew) throws HotelException {
		
		
		return false;
	}
	/****************************************************************************************
	 * @Function Name : addroom
	 * @Input Parameters : room
	 * @Return Type : boolean
	 * @Throws : HotelException
	 * @Description : Adding the room
	 ******************************************************************************************/
	@Override
	public boolean addroom(RoomDetail room) throws HotelException {
		boolean flag=true;
		try
		{
			logger.info("INFO: RoomBean Persisted into database");
			entityManager.persist(room);
		}
		catch(Exception e)
		{
			flag=false;
			logger.error("ERROR: Unable to add room");
			throw new HotelException("Unable to Add room. Please Try Again");
		}
		return flag;
	}

	@Override
	public boolean updateRoom(int roomId) throws HotelException {
		boolean flag= false;
		try
		{	
			flag=true;
			RoomDetail rBean=entityManager.find(RoomDetail.class,roomId);
			rBean.setAvailability("N");
			entityManager.merge(rBean);
			logger.info("INFO: RoomBean Persisted into database");
		}
		catch(Exception e)
		{
			logger.error("ERROR: Unable to book room");
			throw new HotelException("Unable to Book room");
		}
		return flag;
	}
	/****************************************************************************************
	 * @Function Name : deleteRoom
	 * @Input Parameters : roomId
	 * @Return Type : boolean
	 * @Throws : HotelException
	 * @Description : deletes room by using roomId
	 ******************************************************************************************/
	@Override
	public boolean deleteRoom(int roomId) throws HotelException {
		boolean flag=false;
		try
		{
			RoomDetail bean=entityManager.find(RoomDetail.class,roomId);
			entityManager.remove(bean);
			flag=true;
			logger.info("INFO: deletes room by using roomId");
		}
		catch(Exception e)
		{
			logger.error("ERROR:Cannot delete Room as bookings are available for room");
			throw new HotelException("Cannot delete Room as bookings are available for room");
		}
		return flag;
	}
	/****************************************************************************************
	 * @Function Name : generateHotelList
	 * @Return Type : ArrayList
	 * @Throws : HotelException
	 * @Description : generate Report of list of Hotel
	 ******************************************************************************************/
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Hotel> generateHotelListReport() throws HotelException {
		try
		{
			ArrayList<Hotel>list=new ArrayList<Hotel>();
			Query query = entityManager.createNamedQuery("Hotel.findAll");
			list = (ArrayList<Hotel>) query.getResultList();
			logger.info("INFO: Generate Report of list of Hotel");
			return list;
		}
		catch(Exception e)
		{
			logger.error("ERROR: Unable to get Generate Hotel List");
			throw new HotelException("Unable to Generate Hotel List");
		}
	}

	@Override
	public ArrayList<BookingDetail> generateSpecificDateBookingReport(LocalDate startDate, LocalDate endDate) throws HotelException {
		return null;
	}

	@Override
	public ArrayList<BookingDetail> generateSpecificHotelBookingReport(int hotelId) throws HotelException {
		return null;
	}
	/****************************************************************************************
	 * @Function Name : viewRooms
	 * @Input Parameters : hotelId
	 * @Return Type : ArrayList
	 * @Throws : HotelException
	 * @Description : shows rooms by hotel id
	 ******************************************************************************************/
	@Override
	public ArrayList<RoomDetail> viewRooms(int hotelId) throws HotelException {
		try
		{
			String avaString = "Y";
			ArrayList<RoomDetail>list=new ArrayList<RoomDetail>();
			String qStr = "SELECT room FROM RoomDetail room WHERE room.hotel=:bean AND room.availability=:avaString";
			Hotel bean=entityManager.find(Hotel.class, hotelId);
			TypedQuery<RoomDetail> query = entityManager.createQuery(qStr, RoomDetail.class);
			query.setParameter("bean", bean);
			query.setParameter("avaString", avaString);
			list=(ArrayList<RoomDetail>) query.getResultList();
			if(list.size()!=0)
			{
				logger.info("INFO: Show Room By hotel id");
			}
			else
			{
				logger.error("ERROR: Unable to show rooms");
			}
			return list;
		}
		catch(Exception e)
		{
			throw new HotelException("Unable to show rooms.Please Try Again");
		}
	}
	/****************************************************************************************
	 * @Function Name : getRoom
	 * @Input Parameters : roomId
	 * @Return Type : Room
	 * @Throws : HotelException
	 * @Description : view room by using roomId
	 ******************************************************************************************/
	@Override
	public RoomDetail getRoom(int roomId) throws HotelException {
		try
		{
			RoomDetail bean=entityManager.find(RoomDetail.class, roomId);
			logger.info("INFO: Fetched room details by roomid");
			return bean;
		}
		catch(Exception e)
		{
			logger.error("ERROR: Unable to fetch room data");
			throw new HotelException("Unable to fetch room data");
		}
	}
	/****************************************************************************************
	 * @Function Name : deleteRoomOnHotelId
	 * @Input Parameters : hotelId
	 * @Return Type : boolean
	 * @Throws : HotelException
	 * @Description : Delete all rooms of a particular hotel
	 ******************************************************************************************/
	@Override
	public boolean deleteRoomOnHotelId(Hotel bean) throws HotelException {
		boolean flag=false;
		String qStr = "Delete FROM RoomDetail room WHERE room.hotel=:bean";
		Query query = entityManager.createQuery(qStr);
		query.setParameter("bean",bean);
		int row=query.executeUpdate();
		if(row>0)
		{
			flag=true;
			logger.info("INFO: Fetched room details and delete room");
			return flag;
		}
		else
		{
			logger.error("ERROR: Unable to delete room");
			throw new HotelException("Unable to delete room");
		}
	}
	/****************************************************************************************
	 * @Function Name : deleteBookingOnRoom
	 * @Input Parameters : hotelId
	 * @Return Type : boolean
	 * @Throws : HotelException
	 * @Description : Delete all booking of specific rooms.
	 ******************************************************************************************/
	@Override
	public boolean deleteBookingOnRoom(int roomId) throws HotelException {
		boolean flag=true;
		String qStr = "Delete FROM BookingDetail booking WHERE booking.roomDetail=:bean";
		RoomDetail bean=entityManager.find(RoomDetail.class,roomId);
		Query query = entityManager.createQuery(qStr);
		query.setParameter("bean",bean);
		query.executeUpdate();
		return flag;
	}
	/****************************************************************************************
	 * @Function Name : viewRooms
	 * @Input Parameters : hotelId
	 * @Return Type : ArrayList
	 * @Throws : HotelException
	 * @Description : shows rooms by hotel id
	 ******************************************************************************************/
	@Override
	public ArrayList<RoomDetail> viewRoomstoDelete(int hotelId) throws HotelException {
		try
		{
			ArrayList<RoomDetail>list=new ArrayList<RoomDetail>();
			String qStr = "SELECT room FROM RoomDetail room WHERE room.hotel=:bean";
			Hotel bean=entityManager.find(Hotel.class, hotelId);
			TypedQuery<RoomDetail> query = entityManager.createQuery(qStr, RoomDetail.class);
			query.setParameter("bean", bean);
			list=(ArrayList<RoomDetail>) query.getResultList();
			if(list.size()!=0)
			{
				logger.info("INFO: Show Room By hotel id");
			}
			else
			{
				logger.error("ERROR: Unable to show rooms");
			}
			return list;
		}
		catch(Exception e)
		{
			throw new HotelException("Unable to show rooms.Please Try Again");
		}
	}
}
