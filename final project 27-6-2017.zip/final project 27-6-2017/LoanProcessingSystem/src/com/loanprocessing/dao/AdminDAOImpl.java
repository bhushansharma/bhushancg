package com.loanprocessing.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.loanprocessing.bean.ApplicationDetails;
import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.bean.Users;
import com.loanprocessing.dbutil.DBUtil;
import com.loanprocessing.exception.LoanProgramException;
import com.loanprocessing.logger.MyLogger;
import com.loanprocessing.mapper.AdminQueryMapper;

public class AdminDAOImpl implements AdminDao{

	Logger logger = MyLogger.getLoggerInstance();
	Connection con;
	
	public AdminDAOImpl() {
		// TODO Auto-generated constructor stub
		con=DBUtil.getConnection();
		if(con!=null)
		{
			logger.info("Obtained Connection for AdminDaoClass");
		}
	}

	
	
	@Override
	public ArrayList<LoanPrograms> getLoanProgramsAdmin()
			throws LoanProgramException {
		ArrayList<LoanPrograms>list = null;
		try
		{
			
			Statement stmt = 
					con.createStatement();
			ResultSet res = 
					stmt.executeQuery(AdminQueryMapper.getLoanPrgs);
			list = new ArrayList<LoanPrograms>();
			while(res.next())
			{
				LoanPrograms loanProgram = new LoanPrograms();
				loanProgram.setProgramId(res.getInt(1));
				loanProgram.setProgramName(res.getString(2));
				loanProgram.setDescriptn(res.getString(3));
				loanProgram.setType(res.getString(4));
				loanProgram.setDuration(res.getInt(5));
				loanProgram.setMinAmount(res.getInt(6));
				loanProgram.setMaxAmount(res.getInt(7));
				loanProgram.setRate(res.getDouble(8));
				loanProgram.setProof(res.getString(9));
				list.add(loanProgram);
			}
			logger.info("Fetched Record"+list);
			return list;
			
		}
		catch(SQLException e)
		{
			logger.error("Record not available"+e.getMessage());
			throw new LoanProgramException(e.getMessage());
		}
		
	}
	
	@Override
	public boolean isValidAdmin(String username, String password) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		Users admin=new Users();
		
		try {
	
			Statement stmt = 
					con.createStatement();
			ResultSet res = 
					stmt.executeQuery(AdminQueryMapper.validAdmin);
			while(res.next())
			{
				
				admin.setLoginId(res.getString(1));
				admin.setPassword(res.getString(2));
				admin.setRole(res.getString(3));
			}
			
			if(username.equalsIgnoreCase(admin.getLoginId()) && password.equals(admin.getPassword()))
			{
				logger.info("Login Successful");
				flag=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Invalid Credentials");
			throw new LoanProgramException(e.getMessage());
		}
		
		return flag;
	}



	@Override
	public boolean addLoanProgram(LoanPrograms prg) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try{
		
		PreparedStatement pstmt=con.prepareStatement(AdminQueryMapper.addLoanPrg);
		pstmt.setInt(1, prg.getProgramId());
		pstmt.setString(2, prg.getProgramName());
		pstmt.setString(3, prg.getDescriptn());
		pstmt.setString(4, prg.getType());
		pstmt.setInt(5, prg.getDuration());
		pstmt.setDouble(6,prg.getMinAmount());
		pstmt.setDouble(7, prg.getMaxAmount());
		pstmt.setDouble(8, prg.getRate());
		pstmt.setString(9, prg.getProof());
		
		int res=pstmt.executeUpdate();
		if(res>0)
		{
			logger.info("Loan Program Successfully Inserted");
			flag=true;
		}
		
		
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Loan Program Not Inserted");
			throw new LoanProgramException(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public boolean deleteLoanProgram(int prgId) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try {
			
			
			PreparedStatement pstmt=con.prepareStatement(AdminQueryMapper.deleteLoanProg);
			pstmt.setInt(1, prgId);
			
			int row=pstmt.executeUpdate();
			if(row>0)
			{
				logger.info("Loan Program Successfully Deleted with Program id " +prgId);
				flag=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Loan Program with" +prgId+ "Id not found");
			throw new LoanProgramException(e.getMessage());
		}
		return flag;
	}



	@Override
	public ArrayList<ApplicationDetails> viewLoanApplication(LocalDate loanDate)
			throws LoanProgramException {
		// TODO Auto-generated method stub
		ArrayList<ApplicationDetails>list =new ArrayList<ApplicationDetails>();;
		
		Date date=Date.valueOf(loanDate);
		try{
			
			PreparedStatement stmt = 
					con.prepareStatement(AdminQueryMapper.viewLoanApp);
			stmt.setDate(1, date);
			ResultSet res = 
					stmt.executeQuery();
			while(res.next())
			{
				
				ApplicationDetails application=new ApplicationDetails();
				application.setApplicationId(res.getInt(1));
				LocalDate ldate=LocalDate.parse(String.valueOf(res.getDate(2))); 
				application.setAppDate(ldate);
				application.setLoanProgm(res.getString(3));
				application.setAmount(res.getInt(4));
				application.setAddress(res.getString(5));
				application.setIncome(res.getInt(6));
				application.setProof(res.getString(7));
				application.setCover(res.getString(8));
				application.setMarketValue(res.getInt(9));
				application.setStatus(res.getString(10));
				application.setInterviewDate(res.getDate(11));
				application.setName(res.getString(12));
				list.add(application);
			}
			logger.info("Fetched Applicant's Details "+list);
			return list;	
		}
	
		catch (SQLException e) {
			logger.error("No Record Found for Date "+date);
			throw new LoanProgramException(e.getMessage());
		}
}



	@Override
	public boolean updateROI(int id,double rate) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try
		{
		
			PreparedStatement pstmt=con.prepareStatement(AdminQueryMapper.updateROI);
			pstmt.setDouble(1, rate);
			pstmt.setInt(2, id);
			
			int row=pstmt.executeUpdate();
			if(row>0)
			{
				logger.info("ROI Updated Successfully for Loan Program with id "+id);
				flag=true;
			}
			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			logger.error("Loan Program Id "+id+" Not Found");
			throw new LoanProgramException(e.getMessage());
		}
		return flag;
	}



	@Override
	public boolean updateMinAmt(int id, int minAmt) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try
		{
			
			PreparedStatement pstmt=con.prepareStatement(AdminQueryMapper.updateMinAmt);
			pstmt.setInt(1, minAmt);
			pstmt.setInt(2, id);
			
			int row=pstmt.executeUpdate();
			if(row>0)
			{
				logger.info("Minimum Amount Updated Successfully for Loan Program with id "+id);
				flag=true;
			}
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Loan Program Id "+id+" Not Found");
			throw new LoanProgramException(e.getMessage());
		}	
		return flag;
	}


	@Override
	public boolean updateMaxAmt(int id, int maxAmt) throws LoanProgramException {
		// TODO Auto-generated method stub
		boolean flag=false;
		try
		{
			
			PreparedStatement pstmt=con.prepareStatement(AdminQueryMapper.updateMaxAmt);
			pstmt.setInt(1, maxAmt);
			pstmt.setInt(2, id);
			
			int row=pstmt.executeUpdate();
			if(row>0)
			{
				logger.info("Maximum Amount Updated Successfully for Loan Program with id "+id);
				flag=true;
			}
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Loan Program Id "+id+" Not Found");
			throw new LoanProgramException(e.getMessage());
		}
		return flag;
	}

}

