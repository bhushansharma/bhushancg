package com.loanapplication.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loanapplication.dao.CustomerDAO;
import com.loanapplication.entities.CustomerDetail;
import com.loanapplication.entities.Loanapplication;
import com.loanapplication.entities.Loanprogramsoffered;
import com.loanapplication.exception.LoanException;

@Transactional
@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDAO custDao;
	
	public void setDao(CustomerDAO dao)
	{
		this.custDao=dao;
	}
	
	@Override
	public Loanprogramsoffered getLoanProgramDescription(long prgmId)
			throws LoanException {
		// TODO Auto-generated method stub
		return custDao.getLoanProgramDescription(prgmId);
	}

	@Override
	public long insertLoanApp(Loanapplication loanApp) throws LoanException {
		// TODO Auto-generated method stub
		return custDao.insertLoanApp(loanApp);
	}

	@Override
	public boolean insertCustDetails(CustomerDetail cust) throws LoanException {
		// TODO Auto-generated method stub
		return custDao.insertCustDetails(cust);
	}

	@Override
	public Loanapplication getStatus(long id) throws LoanException {
		// TODO Auto-generated method stub
		return custDao.getStatus(id);
	}

}
