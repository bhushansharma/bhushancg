package com.loanprocessing.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.loanprocessing.bean.LoanApplication;
import com.loanprocessing.exception.LoanProgramException;

public interface LoanApprovalService {

	// Lad

	public boolean isValidLad(String username, String password)
			throws LoanProgramException;

	public HashMap<Integer, String> getLoanApplication(LocalDate date)
			throws LoanProgramException;

	public LoanApplication viewLoanApplicationLAD(int appId)
			throws LoanProgramException;

	public boolean approvedLoans(LoanApplication loanApp)
			throws LoanProgramException;

	public boolean rejectLoans(LoanApplication loanApp)
			throws LoanProgramException;

}
