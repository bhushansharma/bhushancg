package com.loanapplication.exception;

public class LoanException extends Exception {

	String message;
	public LoanException(String message) {
		this.message=message;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}
	
	
}
