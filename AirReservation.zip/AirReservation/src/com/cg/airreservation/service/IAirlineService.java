package com.cg.airreservation.service;

/**
 * <AirLine Reservation System>
 * Interface for declaring service class methods i.e AirlineServiceImpl class 
 */
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public interface IAirlineService {

	// This method used to book tickets using flight information by Customer
	public boolean insertPassengerInfo(BookingBean bean, FlightBean fBean)
			throws AirlineException;

	// This method used to register a new Customer
	public boolean insertdetails(CustomerInfoBean bean) throws AirlineException;

	// This method used to fetch flight info based on date entered by customer

	public ArrayList<FlightBean> searchFlight(LocalDate dateJourney)
			throws AirlineException;

	// This method used to authenticate customer,admin and executive
	public CustomerInfoBean checkcredentials(String email, String password)
			throws AirlineException;

	// this method is used to calculate total amount for booked tickets
	public double calFare(BookingBean bean, FlightBean fBean)
			throws AirlineException;

	// this is used to validate customer name
	boolean validateUser(String name);

	// this is used to validate Flight Number
	boolean validateFlightNumber(String flightNumber);

	// this is used to validate Flight Name
	boolean validateFlightName(String flightName);

	// this is used to validate Flight Amount
	boolean validateFlightAmount(double flightAmount);
	
		
	// this is used to validate email id of customer
	boolean validateEmail(String email);

	// this is used to validate customer mobile number
	boolean validateMobile(String mobile);

	// this is used to validate date
	public boolean validateDate(LocalDate date);

	// this is used to validate customer password
	public boolean validatePass(String password);

	// this is used to check date pattern
	public boolean checkDate(String date);

	// this method to check input choice patter
	public boolean checkChoice(int choice);
	
	public boolean validateGender(String gender);
}
