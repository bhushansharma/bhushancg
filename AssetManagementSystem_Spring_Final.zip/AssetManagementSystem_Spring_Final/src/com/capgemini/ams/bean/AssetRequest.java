package com.capgemini.ams.bean;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;


/**
 * The persistent class for the ASSETREQUEST database table.
 * 
 */
@Entity
@Component
@NamedQuery(name="Assetrequest.findAll", query="SELECT a FROM AssetRequest a")
public class AssetRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ASSETREQUEST_REQUESTID_GENERATOR", sequenceName="SEQ_REQUESTID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ASSETREQUEST_REQUESTID_GENERATOR")
	private long requestid;

	private String assetdes;

	private String assetname;

	private BigDecimal quantity;

	private String status;

	//bi-directional many-to-one association to Asset
	@ManyToOne
	@JoinColumn(name="ASSETID")
	private Asset asset;

	//bi-directional many-to-one association to Employee
	@ManyToOne
	@JoinColumn(name="EMPNUM")
	private Employee employee1;

	//bi-directional many-to-one association to Employee
	@ManyToOne
	@JoinColumn(name="MGRCODE")
	private Employee employee2;

	public AssetRequest() {
	}

	public long getRequestid() {
		return this.requestid;
	}

	public void setRequestid(long requestid) {
		this.requestid = requestid;
	}

	public String getAssetdes() {
		return this.assetdes;
	}

	public void setAssetdes(String assetdes) {
		this.assetdes = assetdes;
	}

	public String getAssetname() {
		return this.assetname;
	}

	public void setAssetname(String assetname) {
		this.assetname = assetname;
	}

	public BigDecimal getQuantity() {
		return this.quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Asset getAsset() {
		return this.asset;
	}

	public void setAsset(Asset asset) {
		this.asset = asset;
	}

	public Employee getEmployee1() {
		return this.employee1;
	}

	public void setEmployee1(Employee employee1) {
		this.employee1 = employee1;
	}

	public Employee getEmployee2() {
		return this.employee2;
	}

	public void setEmployee2(Employee employee2) {
		this.employee2 = employee2;
	}

}