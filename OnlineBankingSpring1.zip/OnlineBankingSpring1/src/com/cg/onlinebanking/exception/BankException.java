package com.cg.onlinebanking.exception;

@SuppressWarnings("serial")
public class BankException extends Exception{
	
	String message;

	public BankException(String msg) 
	{
		message = msg;
		// TODO Auto-generated constructor stub
	} 
	
	@Override
	public String getMessage() 
	{
		// TODO Auto-generated method stub
		return message;
	}
	
}
