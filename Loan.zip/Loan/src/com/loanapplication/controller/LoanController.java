package com.loanapplication.controller;



import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.loanapplication.entities.CustomerDetail;
import com.loanapplication.entities.Loanapplication;
import com.loanapplication.entities.Loanprogramsoffered;
import com.loanapplication.exception.LoanException;
import com.loanapplication.service.CustomerService;
import com.loanapplication.service.LADService;

/**
 * @author bhushsha
 *
 */
/**
 * @author bhushsha
 *
 */
@Controller
public class LoanController {
	
	
	
	@Autowired
	LADService service;
	
	@Autowired
	Loanapplication loanApplication;
	
	@Autowired
	CustomerService custService;
	
	@Autowired
	CustomerDetail customer;
	
	Loanprogramsoffered LoanProgram;
	
	Loanapplication loan;
	@RequestMapping(value="/home")
	public String getHome(Model model){
		return "index";
	}
	
	//LOAN APPROVAL DEPARTMENT
	
	/**
	 * LAD Login
	 * @param model
	 * @return 
	 */
	@RequestMapping(value="/login")
	public String getLogin(Model model){
		return "login";
	}
	
	
	/**LAD Home Page 
	 * @param userId
	 * @param password
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/ladhome")
	public String getLadHome(@RequestParam("userId")String userId, @RequestParam("password")String password,Model model)
	{
		if(userId.equals("lad")&&password.equals("lad")){
			LocalDate date=LocalDate.now();
			model.addAttribute("date", date);
			return "ladloanapplication";
		}
		else
		{
			model.addAttribute("msg", "Invalid Credential");
			return "login";
		}
	}
	
	
	/** Show list of Customers applied on the selected date
	 * @param loanDate
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/ladloan")
	public String getLoanApplication(@RequestParam("loandate")String loanDate,Model model)
	{
		ArrayList<CustomerDetail> custList=new ArrayList<CustomerDetail>();
		try {
			custList = service.getCustomerDetails(loanDate);
			
			model.addAttribute("custList", custList);
			
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			model.addAttribute("message", e.getMessage());
			return "laderror";
		}
		if(custList.size()>0)
		return "loanlist";
		else
		{
		model.addAttribute("msg", "No Application Applied for this date");
		return "ladloanapplication";
		}
	}
	
	
	/** Loan Approval Method
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/approve")
	public String approveLoanLad(@RequestParam("applicationId")long id,Model model)
	{
		System.out.println(id);
		try {
			boolean flag=service.approveLoan(id);
			if(flag)
			{
				model.addAttribute("msg","You have approved the loan application Successfully");
			}
			else
			{
				model.addAttribute("msg","You have rejected the loan application  Due To Low Family Income");
				
			}
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			model.addAttribute("message", e.getMessage());
			return "laderror";

		}
		return "approval";
	}
	
	
	/**
	 * @param custId
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/showLoan")
	public String approveLoan(@RequestParam("custId")long custId, Model model)
	{
		
		try {
			customer.setCustomerId(custId);
			loan=service.getLoanApplication(custId);
			model.addAttribute("ApplicationList", loan);
//			System.out.println(loan);
			
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		return "showloandetails";
	}
	
	/** Go to LAD Home Page
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/back")
	public String goToLadHome(Model model)
	{
		LocalDate date=LocalDate.now();
		model.addAttribute("date", date);
		return "ladloanapplication";
	}

	
	
	//CUSTOMER
	
	/** View Loan Programs Offered to the Customer
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/customer")
	public String viewLoan(Model model){
		return "viewLoan";
	}

	
	/** Show Loan Description of the program selected by the customer
	 * @param prgmId
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/LoanDescription")
	public String getLoanDescription(@RequestParam("prgmId")long prgmId,Model model)
	{
		try {
			LoanProgram=custService.getLoanProgramDescription(prgmId);
			model.addAttribute("LoanProgram", LoanProgram);
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			model.addAttribute("message", e.getMessage());
			return "error";

		}
		
		return "loanDescription";
	}
	
	
	/** Display Customer Details Form 
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/customerdetails")
	public String gotoCustomer( Model model)
	{
		model.addAttribute("cust",new CustomerDetail());
		return "customerdetails";
	}
	
	
	/** Display Loan Application to the customer
	 * @param cust
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/applyLoan")
	public String applyLoan(@ModelAttribute("cust")@Valid CustomerDetail cust,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			model.addAttribute("cust", cust);
			return "customerdetails";
		}
		else
		{
		try {
			if(custService.insertCustDetails(cust))
			{
				customer=cust;
				model.addAttribute("proofs", new String[]{"Aadhar Card","Pan Card","Passport","Pay Slip"});
				model.addAttribute("loanApp", new Loanapplication());
				model.addAttribute("LoanProgram", LoanProgram);
				return "applyloan";
			}
				
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		model.addAttribute("error", "Not Submitted Successfully");
		return "customerdetails";
		}
	}
	
	
	/** Submit the Loan Application
	 * @param loanApp
	 * @param model
	 * @return
	 */
	@RequestMapping(value="submitapp")
	public String submitApplication(Loanapplication loanApp, Model model)
	{
		loanApp.setCustomerDetail(customer);
		loanApp.setStatus("Applied");
		loanApp.setApplicationDate(Date.valueOf(LocalDate.now()));
		loanApp.setLoanprogramsoffered(LoanProgram);
		loanApp.setPrgmname(LoanProgram.getPrgmname());
		try {
			long applicationId=custService.insertLoanApp(loanApp);
			System.out.println(applicationId);
			model.addAttribute("applicationId",applicationId);
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			model.addAttribute("message", e.getMessage());
			return "error";

		}
		return "success";
	}
	
	
	
	
	/** Go to check status page
	 * @param loan
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/check")
	public String checkStatus(Loanapplication loan,Model model)
	{
		model.addAttribute("status",loan);
		return "checkStatus";
	}
	
	
	/** display status of the loan application
	 * @param loan
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/getStatus")
	public String showStatus(Loanapplication loan,Model model)
	{
		long id;
		id=loan.getApplicationId();
		try {
			loan=custService.getStatus(id);
			model.addAttribute("application",loan);
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			model.addAttribute("message", e.getMessage());
			return "error";

			
		}
		return "checkStatus";
	}
	
	
}
