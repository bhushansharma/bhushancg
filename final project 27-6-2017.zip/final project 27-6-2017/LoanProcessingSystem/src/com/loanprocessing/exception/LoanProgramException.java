package com.loanprocessing.exception;

@SuppressWarnings("serial")
public class LoanProgramException extends Exception {

	String msg;

	public LoanProgramException(String msg) {
		this.msg = msg;
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		// return super.getMessage();
		return msg;
	}

}
