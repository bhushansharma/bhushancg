package com.capgemini.bms.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bms.bean.BookingDetail;
import com.capgemini.bms.bean.Hotel;
import com.capgemini.bms.bean.RoomDetail;
import com.capgemini.bms.bean.User;
import com.capgemini.bms.dao.CustomerDao;
import com.capgemini.bms.exception.HotelException;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerDao dao;

	public void setDao(CustomerDao dao)
	{
		this.dao = dao;
	}
	
	@Override
	public boolean registerUser(User uBean) throws HotelException {
		return dao.registerUser(uBean);
	}

	@Override
	public String validate(String username, String password)throws HotelException {
		return dao.validate(username, password);
	}

	@Override
	public ArrayList<Hotel> getHotelList(String city) throws HotelException {
		return dao.getHotelList(city);
	}

	@Override
	public ArrayList<RoomDetail> searchRooms(String roomTypes, long minPrice, long maxPrice, int hotelId) throws HotelException {
		return dao.searchRooms(roomTypes, minPrice, maxPrice, hotelId);
	}

	@Override
	public boolean bookRoom(BookingDetail bdBean) throws HotelException {
		return dao.bookRoom(bdBean);
	}

	@Override
	public User getUser(String username, String password) throws HotelException {
		return dao.getUser(username, password);
	}

	@Override
	public ArrayList<BookingDetail> getBookings(int userId) throws HotelException {
		return dao.getBookings(userId);
	}

	@Override
	public ArrayList<BookingDetail> getAllBookings(int userId) throws HotelException {
		return dao.getAllBookings(userId);
	}

	@Override
	public boolean cancelBooking(int bookingId) throws HotelException {
		return dao.cancelBooking(bookingId);
	}

	@Override
	public Hotel getHotelById(int hotelId, String city) throws HotelException {
		return dao.getHotelById(hotelId, city);
	}

	
}
