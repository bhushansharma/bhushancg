package com.cg.airreservation.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.utility.IQueryMapper;
import com.cg.airreservation.utility.Mylogger;

@Repository
public class FlightDaoImpl implements IFlightDao {

	Logger logger = Mylogger.getLoggerInstance();

	@PersistenceContext
	EntityManager entityManager;

	// retrieving airport details
	public ArrayList<String> fetchAirlineList() throws AirlineException {
		Query qry = entityManager.createQuery(IQueryMapper.fetchAirportInfo);
		@SuppressWarnings("unchecked")
		ArrayList<String> airlineList = (ArrayList<String>) qry.getResultList();
		if (airlineList.size() == 0)
		{
			logger.error("Airport info list is null "+airlineList);

			throw new AirlineException(
					"No Airline name found to add a new flight");
		
		}
		return airlineList;
	}

	// retrieving flight details by flight number and departure date
	@Override
	public ArrayList<Flightinfo> searchFlight(Flightinfo flight)
			throws AirlineException {

		Query qry = entityManager
				.createQuery(IQueryMapper.searchFlightbyNumberandDate);
		qry.setParameter("date", flight.getDeptdate());
		qry.setParameter("flightNum", flight.getFlightnum());

		@SuppressWarnings("unchecked")
		ArrayList<Flightinfo> list = (ArrayList<Flightinfo>) qry
				.getResultList();
		if (list.size() == 0)
		{
			logger.error("Flight list for entered date and flight number is "+list);

			throw new AirlineException(
					"No Flight exist for entered Date and Flight number");
		}
		return list;
	}

	// adding new flight details into flightinfo table
	@Override
	public boolean addNewFlight(Flightinfo flightinfo) throws AirlineException {

		try {
			entityManager.persist(flightinfo);
			logger.info("Flight added successfully. " +flightinfo);

		} catch (Exception e) {
			logger.error("Error while adding new flight by admin. " +e.getMessage());

			throw new AirlineException(
					"Failed to add new Flight.Please try again after some time.. Thank you..");
		}

		return true;
	}

	@Override
	public ArrayList<Flightinfo> getListOfFlight(Bookinginfo bookingInfo,
			String classType) {
		// flight search on the basis of departure date, source city,
		// destination city and filter by remaining business seats
		if (classType.equals("Business")) {
			Query qry = entityManager
					.createQuery(IQueryMapper.listFlightByBusiness);
			qry.setParameter("date", bookingInfo.getDateofjourney());
			qry.setParameter("source", bookingInfo.getSourcecity());
			qry.setParameter("destination", bookingInfo.getDestcity());
			qry.setParameter("seats", bookingInfo.getPassengernum());
			@SuppressWarnings("unchecked")
			ArrayList<Flightinfo> list = (ArrayList<Flightinfo>) qry
					.getResultList();
			logger.info("Customer search flight by business class.  " +list);

			return list;
		}

		// flight search on the basis of departure date, source city,
		// destination city and filter by remaining economy seats
		if (classType.equals("Economy")) {

			Query qry = entityManager
					.createQuery(IQueryMapper.listFlightByEconomy);
			qry.setParameter("date", bookingInfo.getDateofjourney());
			qry.setParameter("source", bookingInfo.getSourcecity());
			qry.setParameter("destination", bookingInfo.getDestcity());
			qry.setParameter("seats", bookingInfo.getPassengernum());
			@SuppressWarnings("unchecked")
			ArrayList<Flightinfo> list = (ArrayList<Flightinfo>) qry
					.getResultList();
			logger.info("Customer search flight by economy class." +list);

			return list;
		}
		return null;
	}

	// retrieving flight details by flight id
	@Override
	public Flightinfo fetchFlightDetails(long id) throws AirlineException {

		Flightinfo flightInfo = entityManager.find(Flightinfo.class, id);
		if (flightInfo == null)
		{
			logger.error("Flight retrieval is " +flightInfo);;

			throw new AirlineException(
					"Such Id doesn't exists..Please try again later");
		}
		return flightInfo;
	}

	@SuppressWarnings("unchecked")
	// retrieving list of distinct source city for drop down list
	@Override
	public ArrayList<String> fetchSourceCity() throws AirlineException {
		ArrayList<String> sourceList = new ArrayList<String>();
		Query qry = entityManager.createQuery(IQueryMapper.distinctSourceCity);
		sourceList = (ArrayList<String>) qry.getResultList();
		if (sourceList.size() == 0)
		{
			logger.error("Retrieve flight list for dropdown list by distinct source city " +sourceList);

			throw new AirlineException(
					"Sorry no flight exist .. please try again later");
		
		}return sourceList;
	}

	// retrieving list of distinct destination city for drop down list
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<String> fetchDestinationCity() throws AirlineException {
		ArrayList<String> destinationList = new ArrayList<String>();
		Query qry = entityManager
				.createQuery(IQueryMapper.distinctDestinationCity);
		destinationList = (ArrayList<String>) qry.getResultList();
		if (destinationList.size() == 0)
		{
			logger.error("Retrieve flight list for dropdown list by distinct destination city " +destinationList);

			throw new AirlineException(
					"Sorry no flight exist .. please try again later");
		
		}
		return destinationList;
	}

	@Override
	public int updateFlightSeats(Bookinginfo bookingDetail)
			throws AirlineException {

		String classType1 = "Business";
		String classType2 = "Economy";
		int flag = 0;
		// update business class seats after booking
		if (classType1.equals(bookingDetail.getClasstype())) {
			Query query = entityManager
					.createQuery(IQueryMapper.updateBusinessSeatsAfterBooking);
			query.setParameter("bookSeat", bookingDetail.getPassengernum());
			query.setParameter("flightId", bookingDetail.getFlightinfo()
					.getFlightid());
			flag = query.executeUpdate();
			logger.info("Customer,Seats updated for business class after booking. ");

		}
		// update economy class seats after booking
		else if (classType2.equals(bookingDetail.getClasstype())) {
			Query query = entityManager
					.createQuery(IQueryMapper.updateEconomySeatsAfterBooking);
			query.setParameter("bookSeat", bookingDetail.getPassengernum());
			query.setParameter("flightId", bookingDetail.getFlightinfo()
					.getFlightid());
			flag = query.executeUpdate();
			logger.info("Customer,Seats updated for economy class after booking. ");

		}

		return flag;
	}

	@Override
	public int modifyFlightAfterCancel(Bookinginfo bookingDetail)
			throws AirlineException {

		String classType1 = "Business";
		String classType2 = "Economy";
		int flag = 0;
		// update business class seats after booking is cancel
		if (classType1.equals(bookingDetail.getClasstype())) {

			Query query = entityManager
					.createQuery(IQueryMapper.updateBusinessSeatsAfterCancel);
			query.setParameter("bookSeat", bookingDetail.getPassengernum());
			query.setParameter("flightId", bookingDetail.getFlightinfo()
					.getFlightid());
			flag = query.executeUpdate();
			logger.info("Business seats updated after canceling the booking. ");

		}
		// update economy class seats after booking is cancel
		else if (classType2.equals(bookingDetail.getClasstype())) {
			Query query = entityManager
					.createQuery(IQueryMapper.updateEconomySeatsAfterCancel);
			query.setParameter("bookSeat", bookingDetail.getPassengernum());
			query.setParameter("flightId", bookingDetail.getFlightinfo()
					.getFlightid());
			flag = query.executeUpdate();
			logger.info("Economy seats updated after canceling the booking. ");

		}

		return flag;
	}

	@Override
	public int modifyFlightAfterUpdate(Bookinginfo newBookingDetail,
			Bookinginfo oldBookingDetail) throws AirlineException {

		int flag = 0;
		if (newBookingDetail.getClasstype().equals(
				oldBookingDetail.getClasstype())) {
			// modify business class seats only after booking
			if (newBookingDetail.getClasstype().equals("Business")) {
				Query query = entityManager
						.createQuery(IQueryMapper.updateBusinessSeatsWhileModify);
				query.setParameter("oldBookSeat",
						oldBookingDetail.getPassengernum());
				query.setParameter("newBookSeat",
						newBookingDetail.getPassengernum());

				query.setParameter("flightId", newBookingDetail.getFlightinfo()
						.getFlightid());
				flag = query.executeUpdate();
				logger.info("Business seats updated while modifying the booking. ");

			}
			// modify economy class seats only after booking
			else if (newBookingDetail.getClasstype().equals("Economy")) {

				Query query = entityManager
						.createQuery(IQueryMapper.updateEconomySeatsWhileModify);
				query.setParameter("oldBookSeat",
						oldBookingDetail.getPassengernum());
				query.setParameter("newBookSeat",
						newBookingDetail.getPassengernum());

				query.setParameter("flightId", newBookingDetail.getFlightinfo()
						.getFlightid());
				flag = query.executeUpdate();
				logger.info("Economy seats updated while modifying the booking. ");

			}
		}

		else {
			/*
			 * update seats when customer booked economy class seats and wants
			 * to book business class seats
			 */
			if (newBookingDetail.getClasstype().equals("Business")) {
				Query query = entityManager
						.createQuery(IQueryMapper.updateBusinessSeat);
				query.setParameter("oldBookSeat",
						oldBookingDetail.getPassengernum());
				query.setParameter("newBookSeat",
						newBookingDetail.getPassengernum());

				query.setParameter("flightId", newBookingDetail.getFlightinfo()
						.getFlightid());
				flag = query.executeUpdate();
				logger.info("Customer booked economy class seats but want to book business class seats.");

			}
			/*
			 * update seats when customer booked business class seats and wants
			 * to book economy class seats
			 */
			else if (newBookingDetail.getClasstype().equals("Economy")) {
				Query query = entityManager
						.createQuery(IQueryMapper.updateEconomySeat);
				query.setParameter("oldBookSeat",
						oldBookingDetail.getPassengernum());
				query.setParameter("newBookSeat",
						newBookingDetail.getPassengernum());

				query.setParameter("flightId", newBookingDetail.getFlightinfo()
						.getFlightid());
				flag = query.executeUpdate();
				logger.info("Customer booked business class seats but want to book economy class seats.");

			}

		}

		return flag;
	}

}
