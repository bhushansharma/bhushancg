package com.cg.onlinebanking.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;


/**
 * The persistent class for the TRANSACTIONS1 database table.
 * 
 */
@Component
@Entity
@NamedQuery(name="Transactions1.findAll", query="SELECT t FROM Transactions1 t")
public class Transactions1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TRANSACTIONS1_TRANSACTIONID_GENERATOR", sequenceName="TRANS_ID_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TRANSACTIONS1_TRANSACTIONID_GENERATOR")
	@Column(name="TRANSACTION_ID")
	private long transactionId;

	@Column(name="DT_OF_TRANSACTION",length=20)
	private Timestamp dtOfTransaction;

	@Column(name="TRANACTION_DESCRIPTION",length=30)
	private String tranactionDescription;

	@Column(name="TRANSACTION_AMOUNT")
	private double transactionAmount;

	@Column(name="TRANSACTION_TYPE")
	private String transactionType;

	//bi-directional many-to-one association to AccountMaster1
	@ManyToOne
	@JoinColumn(name="ACCOUNT_NUM")
	private AccountMaster1 accountMaster1;

	public Transactions1() {
	}

	public long getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public Timestamp getDtOfTransaction() {
		return this.dtOfTransaction;
	}

	public void setDtOfTransaction(Timestamp dtOfTransaction) {
		this.dtOfTransaction = dtOfTransaction;
	}

	public String getTranactionDescription() {
		return this.tranactionDescription;
	}

	public void setTranactionDescription(String tranactionDescription) {
		this.tranactionDescription = tranactionDescription;
	}

	public double getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public AccountMaster1 getAccountMaster1() {
		return this.accountMaster1;
	}

	public void setAccountMaster1(AccountMaster1 accountMaster1) {
		this.accountMaster1 = accountMaster1;
	}

}