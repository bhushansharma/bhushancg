package com.loanprocessing.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.loanprocessing.bean.ApplicationDetails;

import com.loanprocessing.bean.LoanPrograms;
import com.loanprocessing.exception.LoanProgramException;

public interface AdminDao {

	
	public ArrayList<LoanPrograms> getLoanProgramsAdmin()
			throws LoanProgramException;

	public boolean isValidAdmin(String username, String password)
			throws LoanProgramException;
	
	public boolean addLoanProgram(LoanPrograms prg) throws LoanProgramException;
	
	public boolean deleteLoanProgram(int prgId)throws LoanProgramException;
	
	public ArrayList<ApplicationDetails> viewLoanApplication(LocalDate loanDate)
			throws LoanProgramException;
	
	public boolean updateROI(int id,double rate) throws LoanProgramException;
	
	public boolean updateMinAmt(int id,int minAmt) throws LoanProgramException;
	
	public boolean updateMaxAmt(int id,int maxAmt) throws LoanProgramException;
	
	
}
